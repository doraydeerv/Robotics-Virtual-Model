#include "zerom.h"
NxVec3 vel_lin_act[19];
NxVec3 ace_lin[18];
NxVec3  num2actual[19];
NxVec3   num1[19];
NxVec3   num2[19];
NxVec3   num[19];
NxVec3 CMVelact;
NxReal den;
NxMat33 TensorInercia[19];
NxVec3 w[19];
NxVec3 zmp;
extern NxVec3 posicionCM;
extern NxVec3 posicionZMP;
void masatotal()
{
	for (int g=0;g<=18;g++)
		MasaTotal+=Segmento[g]->PESO;

}
void calcularzmp()
{
	NUM=NxVec3(0,0,0);
	CMact=NxVec3(0,0,0);
	/*********Aceleraciones de cada segmento**********/
	/* Derivar Velocidad Lineal*/
	for (int e=0;e<=18;e++)
	{
		vel_lin_act[e]=Segmento[e]->actor->getLinearVelocity();
		ace_lin[e]=(vel_lin_act[e] - vel_lin_ant[e])/(1.0/20.0);
		vel_lin_ant[e]=vel_lin_act[e];

	}
	
	/**** Numeradores 1 y 2 de la ecuaci�n del zmp*****  Sumatoria del Centro de Masa Actual**** Masa Total***/
for (int d=0;d<=18;d++)
{
	ace_lin[d]-=NxVec3(0,-9810,0);
	ace_lin[d]*= Segmento[d]->PESO;
	num1[d].cross(Segmento[d]->actor->getCMassGlobalPosition(),ace_lin[d] );
	TensorInercia[d]= Segmento[d]->actor->getGlobalInertiaTensor();
	w[d]=Segmento[d]->actor->getAngularVelocity();
	num2actual[d]=w[d];
	num2[d]=(num2actual[d]-num2anterior[d])/(1.0/20.0);
	num2[d]=TensorInercia[d]*num2[d];
	num[d]=num1[d]+num2[d];
	num2anterior[d]=num2actual[d];

	NUM+=num[d];
	CMact+=	Segmento[d]->actor->getCMassGlobalPosition() * Segmento[d]->PESO;
	
}
   /* Centro de Masa Actual*/
	
	CMact/=MasaTotal;
	printf("\nEl centro de masa total es %.2f, %.2f,%.2f", CMact.x, CMact.y, CMact.z);
	posicionCM= CMact;
	/* Velocidad del Centro de Masa*/
	CMVelact	=(CMact-CMant)/(1.0/20.0);
	CMant=CMact;
	/* Aceleraci�n del cetro de masa*/
	CMacel= (CMVelact-CMVelant)/(1.0/20.0);
	CMVelant=CMVelact;
	/* Denominador***/
	den = MasaTotal*(CMacel.y+9810);

	ZMPx= NUM.z/den;
	ZMPz=NUM.x/den;
	posicionZMP=NxVec3(ZMPx, 0, -ZMPz);
	printf("\nEl ZMP %.2f, %.2f", -ZMPx, ZMPz);
	

}