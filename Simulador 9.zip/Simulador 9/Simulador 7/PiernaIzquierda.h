#include "Physic_VRSHAPE.h" 
#include "NxPhysics.h"
extern NxScene*          gScene;
void declarar_INI(Physic_VRShape *Eslabon, NxScene* gScene);
void	declarar_CaI1(Physic_VRShape *Eslabon, NxScene* gScene);
void	declarar_CaI2(Physic_VRShape *Eslabon, NxScene* gScene);
void	declarar_RI(Physic_VRShape *Eslabon, NxScene* gScene);
void	declarar_TI1(Physic_VRShape *Eslabon, NxScene* gScene);
void	declarar_TI2(Physic_VRShape *Eslabon, NxScene* gScene);
/*
void declarar_INI(Physic_VRShape *Eslabon)
{
	
    Eslabon->shapes[0]= new MeshActor("Shape_F5",   0,    1, 0, 0, 0,    0, 1, 0, 0, 0, 0, 1, 0,NxVec3(0.7,0.7,0.7), 0.00135);
	Eslabon->shapes[1]=new MeshActor("Shape_AX-12_Rotor",0,   0,0,-1,0,   1,0,0,37, 0,1,0,-10, NxVec3(1,0,0), 0.00135);
	Eslabon->crearsegmento(gScene);
}


void	declarar_CaI1(Physic_VRShape *Eslabon)
{
	
	Eslabon->shapes[0]=new MeshActor("shape_AX-12",0,1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, NxVec3(0,0,0), 0.00135);
    Eslabon->shapes[1]=new MeshActor("Shape_F6",0,0, 1, 0, -16, 0, 0, 1, 5, 1, 0, 0, 4, NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[2]=new MeshActor("Shape_F6",0,0, -1, 0, 16, 0, 0, -1, 5, 1, 0, 0, 4, NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[3]=new MeshActor("shape_AX-12",0,0, 0, 1, -3, 0, 1, 0, 0, -1, 0, 0, -29, NxVec3(0,0,0), 0.00135);
    Eslabon->shapes[4]=new MeshActor("Shape_F7",3,0, -1, 0, 15.5, 1, 0, 0, 7.5, 0, 0, 1, 3, NxVec3(0.7,0.7,0.7), 0.00135);
	Eslabon->shapes[5]=new MeshActor("Shape_AX-12_Rotor", 0,   0,0,-1,19,   0,1,0,15, 1,0,0,-29,   NxVec3(1,0,0), 0.00135);
	Eslabon->crearsegmento(gScene);
}



void	declarar_CaI2(Physic_VRShape *Eslabon)
{
	
	Eslabon->shapes[0]=new MeshActor( "Shape_F4", 0, 1, 0, 0, 00,  0, 1, 0, 0, 0, 0, 1, 0,  NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[1]=new MeshActor("Shape_F1", 0, -1, 0, 0, 0, 0, 1, 0, -8, 0, 0, -1, 44,  NxVec3(0.7,0.7,0.7), 0.00135);
	Eslabon->shapes[2]=new MeshActor( "Shape_AX-12_Rotor", 0,  0,0,-1,-19,   0,1,0,-15, 1,0,0,52.5,  NxVec3(1,0,0), 0.00135); 
	Eslabon->crearsegmento(gScene);
}



void	declarar_RI(Physic_VRShape *Eslabon)
{
	
    Eslabon->shapes[0]=new MeshActor("shape_AX-12",0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0,  NxVec3(0,0,0), 0.00135);
    Eslabon->shapes[1]=new MeshActor("Shape_F3", 0, 0, 1, 0, -16, 1, 0, 0, 5, 0, 0, -1, 2,  NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[2]=new MeshActor("Shape_F10",1, 0, 0, -1, 0, 0, -1, 0, -6, -1, 0, 0, 0,  NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[3]=new MeshActor("Shape_F4", 2, 1, 0, 0, 0, 0, 0, -1, 32, 0, 1, 0, 0,  NxVec3(0.7,0.7,0.7), 0.00135);
	Eslabon->shapes[4]=new MeshActor( "Shape_AX-12_Rotor",3, 0,0,-1,19,  0,1,0,0,  1,0,0,-23,  NxVec3(1,0,0), 0.00135);
	Eslabon->crearsegmento(gScene);
}


void	declarar_TI1(Physic_VRShape *Eslabon)
{
	
	Eslabon->shapes[0]=new MeshActor( "shape_AX-12",0,1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0,  NxVec3(0,0,0), 0.00135);
    Eslabon->shapes[1]=new MeshActor( "Shape_F7",0,0, 1, 0, -15.5, 1, 0, 0, 7.5, 0, 0, -1, 3,  NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[2]=new MeshActor( "shape_AX-12",0,0, 0, 1, 29, 0, 1, 0, 0, -1, 0, 0, 3,  NxVec3(0,0,0), 0.00135);
    Eslabon->shapes[3]=new MeshActor( "Shape_F6",2,   0, 1, 0, -16,   0, 0, 1, .5,    1, 0, 0, 4,  NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[4]=new MeshActor( "Shape_F6",2,   0, -1, 0, 16,   0, 0, -1, .5,   1, 0, 0, 4,  NxVec3(0.7,0.7,0.7), 0.00135);
	Eslabon->shapes[5]=new MeshActor( "Shape_AX-12_Rotor", 2,  1,0,0,0,  0,1,0,15,  0,0,1,20,  NxVec3(1,0,0), 0.00135);
	Eslabon->crearsegmento(gScene);
}


void	declarar_TI2(Physic_VRShape *Eslabon)
{
    
    Eslabon->shapes[0]=new MeshActor("Shape_F5",0,   1, 0, 0, 0,   0, 1, 0, 0,  0,  0, 1, 0, NxVec3(0.7,0.7,0.7), 0.00135);
    Eslabon->shapes[1]=new MeshActor("Shape_F12",0,  0, 0, 1, 0, 1, 0, 0, -9, 0, 1, 0, 19.5, NxVec3(0.7,0.7,0.7), 0.00135);
	Eslabon->crearsegmento(gScene);
}
*/
