
#include "NxPhysics.h"
#include "Physic_VRSHAPE.h" 
extern NxScene*          gScene;
extern NxVec3            gDefaultGravity;
extern Physic_VRShape *Segmento[19];
extern NxShape* CMT;
extern NxShape* ZMP;


extern NxVec3  CMact,CMant,CMacel,CMVelant, CM;
extern float MasaTotal;
extern NxVec3 vel_lin_ant[19];	
extern NxVec3  num2anterior[19];	
extern NxVec3   NUM;
extern NxReal ZMPx, ZMPz;	
void calcularzmp();

void masatotal();