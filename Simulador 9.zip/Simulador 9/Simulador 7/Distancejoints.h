extern Physic_VRShape *Segmento[19];
extern Physic_VRShape *SegmentoC[19];
//extern NxDistanceJoint *DistanceJoint[19];
//NxSpringAndDamperEffector * Resorte[19];
//NxSpringAndDamperEffectorDesc Resortedes;

//#include "Physic_VRSHAPE.h"
//#include "NxPhysics.h"


void ResorteL( NxActor* ActorC, NxVec3 PosicionC, NxActor* ActorD,NxVec3 PosicionD);
void BorstIndugula();
/*void ResorteAmortiguador(NxSpringAndDamperEffector *Resorte, NxActor* Actor1, NxVec3 Posicion1, NxActor* Actor2,NxVec3 Posicion2)
{

	 NxSpringAndDamperEffectorDesc Resortedes;  
/*	/***************Damper*******************************/
/*	NxReal maxDamperCompressForce = 10000;
	NxReal velDamperCompressSaturate = 200;
	NxReal maxDamperStretchForce = 10000;
	NxReal velDamperStretchSaturate = 200;
	/***********************************************/
	
	/****************Spring***************************/
/*	NxVec3 springVec = NxVec3(Posicion1 - Posicion2);
	NxReal distSpringRelaxed = springVec.magnitude();
	NxReal maxSpringCompressForce = 200000;
	NxReal distSpringCompressSaturate = 1.25*distSpringRelaxed;
	NxReal maxSpringStretchForce = 200000;
	NxReal distSpringStretchSaturate = 2.0*distSpringRelaxed;
	/*********************************************************/
/*	Resorte = gScene->createSpringAndDamperEffector(Resortedes);
	Resorte->setLinearSpring(distSpringCompressSaturate, distSpringRelaxed, distSpringStretchSaturate,
                        maxSpringCompressForce, maxSpringStretchForce);
	Resorte->setLinearDamper(velDamperCompressSaturate, velDamperStretchSaturate,
                        maxDamperCompressForce, maxDamperStretchForce);
	Resorte->setBodies(Actor1,Posicion1, Actor2, Posicion2);
}*/
void ResorteL( NxActor* ActorC, NxVec3 PosicionC, NxActor* ActorD,NxVec3 PosicionD)
{
	NxVec3 Fuerza= NxVec3(PosicionC.x-PosicionD.x, PosicionC.y-PosicionD.y, PosicionC.z-PosicionD.z);
	ActorD->addLocalForceAtLocalPos(Fuerza, ActorD->getCMassGlobalPosition(), NX_FORCE); 

}
void BorstIndugula()
{
	ResorteL(SegmentoC[0]->actor, SegmentoC[0]->actor->getCMassGlobalPosition(),Segmento[0]->actor, Segmento[0]->actor->getCMassGlobalPosition());
	/*ResorteAmortiguador(Resorte[0], Segmento[0]->actor,Segmento[0]->shapes[2]->Ti.t, SegmentoC[0]->actor, SegmentoC[0]->shapes[2]->Ti.t);
	ResorteAmortiguador(Resorte[1], Segmento[1]->actor,Segmento[1]->shapes[1]->Ti.t, SegmentoC[1]->actor, SegmentoC[1]->shapes[1]->Ti.t);
	ResorteAmortiguador(Resorte[3], Segmento[3]->actor,Segmento[3]->shapes[3]->Ti.t, SegmentoC[3]->actor, SegmentoC[3]->shapes[3]->Ti.t);
	ResorteAmortiguador(Resorte[5], Segmento[5]->actor,Segmento[5]->shapes[5]->Ti.t, SegmentoC[5]->actor, SegmentoC[5]->shapes[5]->Ti.t);
	
	ResorteAmortiguador(Resorte[2], Segmento[2]->actor,Segmento[2]->shapes[1]->Ti.t, SegmentoC[2]->actor, SegmentoC[2]->shapes[1]->Ti.t);
	ResorteAmortiguador(Resorte[4], Segmento[4]->actor,Segmento[4]->shapes[3]->Ti.t, SegmentoC[4]->actor, SegmentoC[4]->shapes[3]->Ti.t);
	ResorteAmortiguador(Resorte[6], Segmento[6]->actor,Segmento[6]->shapes[5]->Ti.t, SegmentoC[6]->actor, SegmentoC[6]->shapes[5]->Ti.t);
	
	ResorteAmortiguador(Resorte[7], Segmento[7]->actor,Segmento[7]->shapes[1]->Ti.t, SegmentoC[7]->actor, SegmentoC[7]->shapes[1]->Ti.t);
	ResorteAmortiguador(Resorte[9], Segmento[9]->actor,Segmento[9]->shapes[5]->Ti.t, SegmentoC[9]->actor, SegmentoC[9]->shapes[5]->Ti.t);
	ResorteAmortiguador(Resorte[11], Segmento[11]->actor,Segmento[11]->shapes[1]->Ti.t, SegmentoC[11]->actor, SegmentoC[11]->shapes[2]->Ti.t);
	ResorteAmortiguador(Resorte[13], Segmento[13]->actor,Segmento[13]->shapes[4]->Ti.t, SegmentoC[13]->actor, SegmentoC[13]->shapes[4]->Ti.t);
	ResorteAmortiguador(Resorte[15], Segmento[15]->actor,Segmento[15]->shapes[5]->Ti.t, SegmentoC[15]->actor, SegmentoC[15]->shapes[5]->Ti.t);
	ResorteAmortiguador(Resorte[15], Segmento[17]->actor,Segmento[17]->shapes[1]->Ti.t, SegmentoC[17]->actor, SegmentoC[17]->shapes[1]->Ti.t);

	ResorteAmortiguador(Resorte[8], Segmento[8]->actor,Segmento[8]->shapes[1]->Ti.t, SegmentoC[8]->actor, SegmentoC[8]->shapes[1]->Ti.t);
	ResorteAmortiguador(Resorte[10], Segmento[10]->actor,Segmento[10]->shapes[5]->Ti.t, SegmentoC[10]->actor, SegmentoC[10]->shapes[5]->Ti.t);
	ResorteAmortiguador(Resorte[12], Segmento[12]->actor,Segmento[12]->shapes[1]->Ti.t, SegmentoC[12]->actor, SegmentoC[12]->shapes[2]->Ti.t);
	ResorteAmortiguador(Resorte[14], Segmento[14]->actor,Segmento[14]->shapes[4]->Ti.t, SegmentoC[14]->actor, SegmentoC[14]->shapes[4]->Ti.t);
	ResorteAmortiguador(Resorte[16], Segmento[16]->actor,Segmento[16]->shapes[5]->Ti.t, SegmentoC[16]->actor, SegmentoC[16]->shapes[5]->Ti.t);
	ResorteAmortiguador(Resorte[18], Segmento[18]->actor,Segmento[18]->shapes[1]->Ti.t, SegmentoC[18]->actor, SegmentoC[18]->shapes[1]->Ti.t);
*/
}


