
extern float frame[517][25];
int framest= 517;

void Lectura()
{
FILE *fp = fopen("slowwalk517.txt","r");
 if (fp == NULL)
  { 
    fprintf(stderr,"mov: Couldn't open \n"); 
    exit(-1); 
  }

for (int ss=1; ss<framest; ss++)
	{
      fscanf(fp,"%f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f ",
		  &frame[ss][1],&frame[ss][2],&frame[ss][3],&frame[ss][4], 
		  &frame[ss][7],&frame[ss][8],&frame[ss][9],&frame[ss][10],&frame[ss][11],&frame[ss][12],
		  &frame[ss][13],&frame[ss][14],&frame[ss][15],&frame[ss][16],&frame[ss][17],&frame[ss][18],
		  &frame[ss][19],&frame[ss][20],&frame[ss][21],&frame[ss][22],&frame[ss][23],&frame[ss][24]);
	}
}



