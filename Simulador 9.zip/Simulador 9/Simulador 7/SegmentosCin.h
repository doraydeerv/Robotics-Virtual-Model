#include <stdio.h>
#include "NxPhysics.h"
#include <math.h>

NxMat34 Idc;
NxMat34 ROT;
NxMat34 ROT1;
float ang_rad[19];
float pi=3.1416;

extern NxPhysicsSDK*     gPhysicsSDK;
extern NxScene*          gScene2;
extern NxVec3            gDefaultGravity;
extern NxActor*          SegmentoC[19];

NxActor* CreateSegC(const NxVec3& pos, const NxVec3& boxDim, const NxReal density)
{
	// Add a single-shape actor to the scene
	NxActorDesc actorDesc;
	NxBodyDesc bodyDesc;

	// The actor has one shape, a box
	NxBoxShapeDesc boxDesc;
	boxDesc.dimensions.set(boxDim.x,boxDim.y,boxDim.z);
	boxDesc.localPose.t = NxVec3(0,boxDim.y,0);
	actorDesc.shapes.pushBack(&boxDesc);

	if (density)
	{
		actorDesc.body = &bodyDesc;
		actorDesc.density = density;
	}
	else
	{
		actorDesc.body = NULL;
	}
	actorDesc.globalPose.t = pos;
	return gScene2->createActor(actorDesc);	
}
void SegmentosCin()
{
ang_rad[1]=0;
ang_rad[2]=0;
ang_rad[3]=0;
ang_rad[4]=0;
ang_rad[5]=0;
ang_rad[6]=0;

ang_rad[7]= -pi - pi/4 - pi/2;
ang_rad[8]= pi/4 + pi/2;

ang_rad[9]= -pi/2;
ang_rad[10]=-pi/2;

ang_rad[11]= pi/2;
ang_rad[12]= pi/2;
 SegmentoC[0] = CreateSegC(NxVec3(0,350,0),  NxVec3(50,50,5),  NxReal(10));
 SegmentoC[0]->raiseBodyFlag(NX_BF_KINEMATIC);
 
 SegmentoC[1] = CreateSegC(NxVec3(-75,430,0),  NxVec3(25,10,5),  NxReal(10));
 SegmentoC[1]->raiseBodyFlag(NX_BF_KINEMATIC);
 SegmentoC[1]->setGlobalOrientation(NxMat33(NxVec3(1,0,0),NxVec3(0,cos(ang_rad[1]),-sin(ang_rad[1])),NxVec3(0,sin(ang_rad[1]),cos(ang_rad[1]))));
 
 SegmentoC[2] = CreateSegC(NxVec3(75,430,0),  NxVec3(25,10,5),  NxReal(10));
 SegmentoC[2]->raiseBodyFlag(NX_BF_KINEMATIC);
 SegmentoC[2]->setGlobalOrientation(NxMat33(NxVec3(1,0,0),NxVec3(0,cos(ang_rad[2]),-sin(ang_rad[2])),NxVec3(0,sin(ang_rad[2]),cos(ang_rad[2]))));
 
 
  
 SegmentoC[3] = CreateSegC(NxVec3(-125,430,0),  NxVec3(25,10,5),  NxReal(10));
 SegmentoC[3]->raiseBodyFlag(NX_BF_KINEMATIC);
 ROT= NxMat34(NxMat33(NxVec3(cos(ang_rad[3]),0,sin(ang_rad[3])),NxVec3(0,1,0),NxVec3(-sin(ang_rad[3]),0,cos(ang_rad[3]))), NxVec3(-50,0,0));
 ROT1.multiply(SegmentoC[1]->getGlobalPose(), ROT);
 //SegmentoC[3]->getGlobalPose().multiply(SegmentoC[1]->getGlobalPose(), ROT1);

 SegmentoC[3]->setGlobalPose(ROT1);
 
 
 SegmentoC[4] = CreateSegC(NxVec3(125,430,0),  NxVec3(25,10,5),  NxReal(10));
 SegmentoC[4]->raiseBodyFlag(NX_BF_KINEMATIC);
 ROT= NxMat34(NxMat33(NxVec3(cos(ang_rad[4]),0,sin(ang_rad[4])),NxVec3(0,1,0),NxVec3(-sin(ang_rad[4]),0,cos(ang_rad[4]))), NxVec3(50,0,0));
 ROT1.multiply(SegmentoC[2]->getGlobalPose(), ROT);
 //SegmentoC[4]->getGlobalPose().multiply(SegmentoC[2]->getGlobalPose(), ROT1);
 SegmentoC[4]->setGlobalPose(ROT1);
 SegmentoC[5] = CreateSegC(NxVec3(-175,430,0),  NxVec3(25,10,5),  NxReal(10));
 SegmentoC[5]->raiseBodyFlag(NX_BF_KINEMATIC);
 ROT= NxMat34(NxMat33(NxVec3(cos(ang_rad[5]),0,sin(ang_rad[5])),NxVec3(0,1,0),NxVec3(-sin(ang_rad[5]),0,cos(ang_rad[5]))), NxVec3(-50,0,0));
 ROT1.multiply(SegmentoC[3]->getGlobalPose(), ROT);
 SegmentoC[5]->setGlobalPose(ROT1);
 
 SegmentoC[6] = CreateSegC(NxVec3(175,430,0),  NxVec3(25,10,5),  NxReal(10));
 SegmentoC[6]->raiseBodyFlag(NX_BF_KINEMATIC);
 ROT= NxMat34(NxMat33(NxVec3(cos(ang_rad[6]),0,sin(ang_rad[6])),NxVec3(0,1,0),NxVec3(-sin(ang_rad[6]),0,cos(ang_rad[6]))), NxVec3(50,0,0));
 ROT1.multiply(SegmentoC[4]->getGlobalPose(), ROT);
 SegmentoC[6]->setGlobalPose(ROT1);
}