
#include "BrazoIzquierdo.h"


void declarar_HI1(Physic_VRShape *Eslabon, NxScene* gScene)
{
 
 Eslabon->shapes[0]=new MeshActor("Shape_F1",      0,  1, 0, 0, 0,   0, 1, 0, 0,    0, 0, -1, 0,   NxVec3(0.7,0.7,0.7), 0.00135);
 Eslabon->shapes[1]=new MeshActor("Shape_AX-12_Rotor", 0,  0,0,1,19,  0,1,0,-5,  1,0,0,8,   NxVec3(1,0,0), 0.00135);
 Eslabon->crearsegmento(gScene);
}


void declarar_HI2(Physic_VRShape *Eslabon, NxScene* gScene)
{

Eslabon->shapes[0]=new MeshActor("shape_AX-12", 0,   1, 0, 0, 0, 0, 1, 0, 0,   0, 0, 1, 0,   NxVec3(0,0,0), 0.00135);
Eslabon->shapes[1]=new MeshActor("Shape_F3", 0,   -1, 0, 0, 0,    0, 1, 0, -22.5,   0, 0, -1,2,   NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->shapes[2]=new MeshActor("Shape_F2", 1,   0 ,-1, 0, 0,    0, 0, 1, -23.5,  -1, 0, 0, 0,   NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->shapes[3]=new MeshActor("Shape_AX-12_Rotor",0,  1,0,0,0,   0,1,0,-54, 0,0,1,21,  NxVec3(1,0,0), 0.00135);
Eslabon->crearsegmento(gScene);
}



void declarar_CI(Physic_VRShape *Eslabon, NxScene* gScene)
{

Eslabon->shapes[0]=new MeshActor("shape_AX-12",0,   1 ,0, 0, 0,    0, 1, 0, 0,    0, 0, 1, 0, NxVec3(0,0,0), 0.00135);
Eslabon->shapes[1]=new MeshActor("Shape_F3",0,-1, 0, 0, 0,  0, 1, 0, -22.5,   0, 0, -1,2, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->shapes[2]=new MeshActor("Shape_F10",1,0, 0, -1, 0,  0, -1, 0, -7, -1, 0, 0, 0, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->shapes[3]=new MeshActor("Shape_F10",2,-1, 0, 0, 0, 0, -1, 0, 4, 0, 0, 1, 0, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->shapes[4]=new MeshActor("Shape_F9",3,0, 1, 0,  0,     0, 0, 1, -17+5,    1, 0, 0, 5, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->shapes[5]=new MeshActor("f11",4,0, 1, 0, -19, 1, 0, 0, -15,  0, 0, -1, -15+25, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon->crearsegmento(gScene);
}
