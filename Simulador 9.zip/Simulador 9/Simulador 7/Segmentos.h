#include <stdio.h>
#include "NxPhysics.h"
#include "Torso.h"
#include "BrazoIzquierdo.h"
#include "BrazoDerecho.h"
#include "PiernaIzquierda.h"
#include "PiernaDerecha.h"

NxMat34 Id;
extern NxPhysicsSDK*     gPhysicsSDK;
extern NxScene*          gScene;
extern NxVec3            gDefaultGravity;
extern Physic_VRShape *Segmento[19];
extern float frame[517][25];
extern NxActor* Esfera2;
extern NxReal offsetd;
NxRevoluteJoint*   revJoints[19];
NxFixedJoint*   fixed[19];
extern NxActor* Pelvis;
NxVec3 PelvisP;
NxMat33 Rot[18];
void Segmentos()
{	
/************************************/	
	 
	 
	
	//gPhysicsSDK->setParameter(NX_DYN_FRICT_SCALING, 2);
	//gPhysicsSDK->setParameter(NX_STA_FRICT_SCALING, 2);
/***********************************/
	Segmento[0]=new Physic_VRShape(25,   0,   1,0,0, frame[2][19],   0,1,0,frame[2][20]+offsetc,   0,0,1,frame[2][21], 553 ); 
		Segmento[0]->setTransformT(Id,Segmento[0]->H);
		declarar_Torso(Segmento[0], gScene);
		Segmento[0]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		PelvisP= NxVec3(frame[2][19]+ 42, (frame[2][20]+offsetc)-45 ,frame[2][21]+10);
		fixed[0]= CreateFixedJoint(Segmento[0]->actor,Pelvis,PelvisP ,NxVec3(0,-1,0));
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(992393, -2073, -1276),NxVec3(-2073, 560882,76222),NxVec3(-1276, 76222,1132970)), NxVec3( 992393, 560882,1132970),  Rot[0]);
		Segmento[0]->setCOMpose(NxMat34(Rot[0],(PelvisP + NxVec3(0,58,-7))));
		Segmento[0]->setPMInertia(NxVec3(992393, 560882,1132970));
		Segmento[0]->actor->clearBodyFlag(NX_BF_KINEMATIC);
		


/************************Brazo Derecho**************************************/
	Segmento[1]=new Physic_VRShape(1,   0,  0,-1, 0, 9,  1,0, 0, 0,  0, 0, 1, 17,  11.38 );
		Segmento[1]->setTransformT(Segmento[0]->shapes[22]->Ti, Segmento[1]->H);
		declarar_HD1(Segmento[1], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(5057, -0, -448),NxVec3(0, 2105,0),NxVec3(-448, 0,4935)), NxVec3(5057, 2105, 4935),  Rot[1]);
		Segmento[1]->setCOMpose(NxMat34(Rot[1],(PelvisP + NxVec3(-60.6,89.63,4.63))));
		Segmento[1]->setPMInertia(NxVec3(5057, 2105, 4935));
		revJoints[1]= CreateRevoluteJoint(Segmento[0]->actor,Segmento[1]->actor, (Segmento[0]->shapes[22]->Ti.t),NxVec3(-1,0,0));
		//Segmento[1]->fixShape();	
		
	Segmento[3]=new Physic_VRShape(3,   1,   0,0,1, -14,  0,1,0, 0,    1, -0.00001,0, -21, 76.72); 	
		Segmento[3]->setTransformT(Segmento[1]->shapes[1]->Ti, Segmento[3]->H);
		declarar_HD2(Segmento[3], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(7800, 367, 0),NxVec3(367, 19126,0),NxVec3(0, 0,23979)), NxVec3(7800,19126,23979),  Rot[3]);
		Segmento[3]->setCOMpose(NxMat34(Rot[3],(PelvisP + NxVec3(-97.45,90.38,16.63))));
		Segmento[3]->setPMInertia(NxVec3( 7800,19126,23979));		
		revJoints[3]= CreateRevoluteJoint(Segmento[1]->actor,Segmento[3]->actor, (Segmento[1]->shapes[1]->Ti.t),NxVec3(0,1,0));
		
		//Segmento[3]->fixShape();
	
   Segmento[5]=new Physic_VRShape(5,   3,   0, 1, 0, 50,     1,  0, 0, 00,    0, 0, -1,83, 77.35); 
		Segmento[5]->setTransformT(Segmento[3]->shapes[3]->Ti, Segmento[5]->H);
		declarar_CD(Segmento[5], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(5522, 552, 3273),NxVec3(522, 27123,35),NxVec3(3273, 35,28867)), NxVec3(5522, 27123,28867),  Rot[5]);
		Segmento[5]->setCOMpose(NxMat34(Rot[5],(PelvisP + NxVec3(-167,90,15))));
		Segmento[5]->setPMInertia(NxVec3( 5522, 27123,28867));
		//revJoints[5] = CreateRevoluteJoint(Segmento[3]->actor,Segmento[5]->actor, (Segmento[5]->shapes[0]->Ti.t+NxVec3(12,0,0)),NxVec3(0,1,0));
		fixed[5] = CreateFixedJoint(Segmento[3]->actor,Segmento[5]->actor, (Segmento[5]->shapes[0]->Ti.t),NxVec3(0,0,1));
		//Segmento[5]->fixShape();
		
		
/****************************Brazo Izquierdo*********************************/
	Segmento[2]=new Physic_VRShape(1,   0,   0,-1, 0, 7,    1,0, 0, 0,     0, 0, 1, -18, 11.38);
		Segmento[2]->setTransformT(Segmento[0]->shapes[23]->Ti, Segmento[2]->H);
		declarar_HI1(Segmento[2], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(5057, 0, 448),NxVec3(0, 2105,0),NxVec3(448, 0,4935)), NxVec3(5057, 2105, 4935),  Rot[2]);
		Segmento[2]->setCOMpose(NxMat34(Rot[2],(PelvisP + NxVec3(60.94,89,4))));
		Segmento[2]->setPMInertia(NxVec3(5057, 2105, 4935));
		revJoints[2] = CreateRevoluteJoint(Segmento[0]->actor,Segmento[2]->actor, (Segmento[0]->shapes[23]->Ti.t),NxVec3(1,0,0));
		//Segmento[2]->fixShape();
		
		
	Segmento[4]=new Physic_VRShape(3,   2,   0, 0, 1, 15,      0,  1, 0, 0,     1, 0, 0, -22, 76.72); 
		Segmento[4]->setTransformT(Segmento[2]->shapes[1]->Ti, Segmento[4]->H);
		declarar_HI2(Segmento[4], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(7800, -367, 0),NxVec3(-367, 19126,0),NxVec3(0, 0,23979)), NxVec3(7800,19126,23979),  Rot[4]);
		Segmento[4]->setCOMpose(NxMat34(Rot[4],(PelvisP + NxVec3(97,90,16))));
		Segmento[4]->setPMInertia(NxVec3(7800,19126,23979));
		revJoints[4] = CreateRevoluteJoint(Segmento[2]->actor,Segmento[4]->actor, (Segmento[2]->shapes[1]->Ti.t),NxVec3(0,1,0));
		//Segmento[4]->fixShape();
		
		
	Segmento[6]=new Physic_VRShape(5,   4,   1, 0, 0, 0,   0,  1, 0, 50,    0, 0, 1,47, 77.35); 
		Segmento[6]->setTransformT(Segmento[4]->shapes[3]->Ti, Segmento[6]->H);
		declarar_CI(Segmento[6], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(5522, -552, -3273),NxVec3(-522, 27123,35),NxVec3(-3273, 35,28867)), NxVec3(5522, 27123,28867),  Rot[6]);
		Segmento[6]->setCOMpose(NxMat34(Rot[6],(PelvisP + NxVec3(166,90,15))));
		Segmento[6]->setPMInertia(NxVec3(5522, 27123,28867));
		//revJoints[6] = CreateRevoluteJoint(Segmento[4]->actor,Segmento[6]->actor, (Segmento[6]->shapes[0]->Ti.t+NxVec3(-15,0,-5)),NxVec3(0,1,0));	
		fixed[6] = CreateFixedJoint(Segmento[4]->actor,Segmento[6]->actor, (Segmento[6]->shapes[0]->Ti.t),NxVec3(0,1,0));
		//Segmento[6]->fixShape();
	
		
		/****************************************Pierna Derecha*************************************/

	Segmento[7]=new Physic_VRShape(2,   0,   0,-1,0,-15,   -1,0,0,0,  0,0,-1,21, 14.88); 
		Segmento[7]->setTransformT(Segmento[0]->shapes[24]->Ti, Segmento[7]->H);
		
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(13799, 0, 0),NxVec3(0, 13185,110),NxVec3(0, 110,2746)), NxVec3(13799.23, 13185,  2746),  Rot[7]);
		declarar_IND(Segmento[7], gScene);
		Segmento[7]->setCOMpose(NxMat34(Rot[7],(PelvisP + NxVec3(-38.31,-12,-15.23))));
		Segmento[7]->setPMInertia(NxVec3(13799.23, 13185,  2746));
		revJoints[7] = CreateRevoluteJoint(Segmento[0]->actor,Segmento[7]->actor, (Segmento[0]->shapes[24]->Ti.t),NxVec3(0,-1,0));
		//Segmento[7]->fixShape();
	
	
	Segmento[9]=new Physic_VRShape(6,   7,   0, 0, 1,-21,      0,1,0, -15,     1, 0,0,0, 137.05);
		Segmento[9]->setTransformT(Segmento[7]->shapes[1]->Ti, Segmento[9]->H);
		declarar_CaD1(Segmento[9], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(52973, -114, 1010),NxVec3(-110, 54243,1444),NxVec3(1010, 1444,11067)), NxVec3( 52973,  54243, 11067),  Rot[9]);
		//NxDiagonalizeInertiaTensor(NxMat33(NxVec3(52973,114, -1010),NxVec3(110,  54243,1444),NxVec3(-1010, 1444,11067)), NxVec3(52973,  54243, 11067),  Rot[10]);
		Segmento[9]->setCOMpose(NxMat34(Rot[9],(PelvisP + NxVec3(-38.35, -46.10,-14.72))));
		Segmento[9]->setPMInertia(NxVec3(52973,  54243, 11067));
		revJoints[9] = CreateRevoluteJoint(Segmento[7]->actor,Segmento[9]->actor, (Segmento[7]->shapes[0]->Ti.t+NxVec3(0,-10,0)),NxVec3(0,0,1));
		//Segmento[9]->fixShape();
	


	Segmento[11]=new Physic_VRShape( 3,   9,    0, -1, 0, 0,    0, 0,-1, -23,    1,0, 0, -19, 30.62);
		Segmento[11]->setTransformT(Segmento[9]->shapes[5]->Ti, Segmento[11]->H);
		declarar_CaD2(Segmento[11], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(16624, 0, 0),NxVec3(0, 13579,1342),NxVec3(0, 1342,24938)), NxVec3(16624,13579,   24938),  Rot[11]);
		Segmento[11]->setCOMpose(NxMat34(Rot[11],(PelvisP + NxVec3(-38.81, -75.14,0))));
		Segmento[11]->setPMInertia(NxVec3(16624,13579,   24938));
		revJoints[11] = CreateRevoluteJoint(Segmento[9]->actor,Segmento[11]->actor, (Segmento[9]->shapes[5]->Ti.t),NxVec3(-1,0,0));
		//Segmento[11]->fixShape();
	
	Segmento[13]=new Physic_VRShape(5,   11,    1,0, 0, 0,  0, -1, 0, 15,   0, 0, -1,22, 86.65);
		Segmento[13]->setTransformT(Segmento[11]->shapes[2]->Ti, Segmento[13]->H);
		declarar_RD(Segmento[13], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(37213,702, 101),NxVec3(702, 13545,124),NxVec3(101,124,43536)), NxVec3( 37213, 13545,   43536),  Rot[13]);
		Segmento[13]->setCOMpose(NxMat34(Rot[13],(PelvisP + NxVec3(-38.08, -117.65,1.47))));
		Segmento[13]->setPMInertia(NxVec3(  37213, 13545,   43536));
		revJoints[13] = CreateRevoluteJoint(Segmento[13]->actor,Segmento[11]->actor, (Segmento[11]->shapes[2]->Ti.t),NxVec3(1,0,0));
		//Segmento[13]->fixShape();
		
		
	Segmento[15]=new Physic_VRShape(5,   13,  0, -1, 0, 15,   1, 0, 0, 0,   0,0, 1, -22,137.05  );
		Segmento[15]->setTransformT(Segmento[13]->shapes[4]->Ti, Segmento[15]->H);
		declarar_TD1(Segmento[15], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(52973,114, 1010),NxVec3(114, 54243,-1444),NxVec3(1010,-1444,11067)), NxVec3(52973,54243,     11067),  Rot[15]);
		Segmento[15]->setCOMpose(NxMat34(Rot[15],(PelvisP + NxVec3(-38.35, -167.03,-14.97))));
		Segmento[15]->setPMInertia(NxVec3(  52973,54243,     11067));
		revJoints[15] = CreateRevoluteJoint(Segmento[13]->actor,Segmento[15]->actor, (Segmento[13]->shapes[4]->Ti.t),NxVec3(1,0,0));
		//fixed[15] = CreateFixedJoint(Segmento[13]->actor,Segmento[15]->actor, (Segmento[13]->shapes[4]->Ti.t),NxVec3(1,0,0));
		//Segmento[15]->fixShape();
		
	Segmento[17]=new Physic_VRShape(2,   15,  -1,0,0,0,   0,0,1,10, 0,1,0,-36, 37.08);
		Segmento[17]->setTransformT(Segmento[15]->shapes[5]->Ti, Segmento[17]->H);
		declarar_TD2(Segmento[17], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(33435,779, -617),NxVec3(779, 39224,-804),NxVec3(-617,-804,11521)), NxVec3( 11479, 33355,   39346),  Rot[17]);
		Segmento[17]->setCOMpose(NxMat34(Rot[17],(PelvisP + NxVec3(-43.39, -207.74,-11.31))));
		Segmento[17]->setPMInertia(NxVec3( 33435,39224,   11521));
		//fixed[17] = CreateFixedJoint(Segmento[15]->actor,Segmento[17]->actor, (Segmento[15]->shapes[1]->Ti.t+NxVec3(0,-.010,0)),NxVec3(0,0,1));
		revJoints[17] = CreateRevoluteJoint(Segmento[15]->actor,Segmento[17]->actor, (Segmento[15]->shapes[1]->Ti.t+NxVec3(0,-10,0)),NxVec3(0,0,1));
		//Segmento[17]->fixShape();
		
/****************************************Pierna Izquierda*************************************/
	Segmento[8]=new Physic_VRShape(2,   0,  0,1,0,15,   1,0,0,0,  0,0,-1,21, 14.9); 
		Segmento[8]->setTransformT(Segmento[0]->shapes[25]->Ti, Segmento[8]->H);
		declarar_INI(Segmento[8], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(13799, 0, 0),NxVec3(0, 13185,110),NxVec3(0, 110,2746)), NxVec3(13799.23, 13185,  2746),  Rot[8]);
		Segmento[8]->setCOMpose(NxMat34(Rot[8],(PelvisP + NxVec3(38.31,-12,-15.23))));
		Segmento[8]->setPMInertia(NxVec3( 13799.23, 13185,  2746));
		revJoints[8] = CreateRevoluteJoint(Segmento[0]->actor,Segmento[8]->actor, (Segmento[0]->shapes[25]->Ti.t),NxVec3(0,-1,0));
		//Segmento[8]->fixShape();
	
					
		
	Segmento[10]=new Physic_VRShape(6,   8,   0, 0, 1, -22,    0, 1,0, -15,    1,0, 0, 0, 137.05); 
		Segmento[10]->setTransformT(Segmento[8]->shapes[1]->Ti, Segmento[10]->H);
		declarar_CaI1(Segmento[10], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(52973,114, -1010),NxVec3(110,  54243,1444),NxVec3(-1010, 1444,11067)), NxVec3(52973,  54243, 11067),  Rot[10]);
		Segmento[10]->setCOMpose(NxMat34(Rot[10],(PelvisP + NxVec3(38.73, -46.10,-14.72))));
		Segmento[10]->setPMInertia(NxVec3(52973,  54243, 11067));
		revJoints[10] = CreateRevoluteJoint(Segmento[8]->actor,Segmento[10]->actor, (Segmento[8]->shapes[1]->Ti.t),NxVec3(0,0,1));
		//Segmento[10]->fixShape();
	

	Segmento[12]=new Physic_VRShape(3,   10,  0, -1, 0, 0,    0,0 ,-1, -23,      1, 0, 0, 19, 30.62);
		Segmento[12]->setTransformT(Segmento[10]->shapes[5]->Ti, Segmento[12]->H);
		declarar_CaI2(Segmento[12], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(16624, 0, 0),NxVec3(0, 13579,1342),NxVec3(0, 1342,24938)), NxVec3(16624,13579,   24938),  Rot[12]);
		Segmento[12]->setCOMpose(NxMat34(Rot[12],(PelvisP + NxVec3(38.81, -75.14,0))));
		Segmento[12]->setPMInertia(NxVec3( 16624,13579,   24938));
		revJoints[12] = CreateRevoluteJoint(Segmento[10]->actor,Segmento[12]->actor, (Segmento[10]->shapes[5]->Ti.t),NxVec3(1,0,0));
		//Segmento[12]->fixShape();
	
	Segmento[14]=new Physic_VRShape(5,   12,   -1,0, 0,0,  0,-1,0,15,   0, 0,1,-22, 86.65 );
		Segmento[14]->setTransformT(Segmento[12]->shapes[2]->Ti, Segmento[14]->H);
		declarar_RI(Segmento[14], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(37214,-702, -101),NxVec3(-702, 13545,124),NxVec3(-101,124,43537)), NxVec3(  37214, 13545,   43537),  Rot[14]);
		Segmento[14]->setCOMpose(NxMat34(Rot[14],(PelvisP + NxVec3(37.35, -117.65,1.47))));
		Segmento[14]->setPMInertia(NxVec3(   37214, 13545,   43537));
		revJoints[14] = CreateRevoluteJoint(Segmento[14]->actor,Segmento[12]->actor, (Segmento[12]->shapes[2]->Ti.t),NxVec3(-1,0,0));
		//Segmento[14]->fixShape();
	Segmento[16]=new Physic_VRShape(6,   14,   0,-1,0,15, -1,0,0,0,  0,0,-1,22, 137.05);
		Segmento[16]->setTransformT(Segmento[14]->shapes[4]->Ti, Segmento[16]->H);
		declarar_TI1(Segmento[16], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(52973,-114, -1010),NxVec3(-114, 54243,-1444),NxVec3(-1010,-1444,11067)), NxVec3( 52973,54243,     11067),  Rot[16]);
		Segmento[16]->setCOMpose(NxMat34(Rot[16],(PelvisP + NxVec3(37.62, -167.03,-14.97))));
		Segmento[16]->setPMInertia(NxVec3(  52973,54243,     11067));
		revJoints[16] = CreateRevoluteJoint(Segmento[14]->actor,Segmento[16]->actor, (Segmento[14]->shapes[4]->Ti.t),NxVec3(1,0,0));
		//fixed[16] = CreateFixedJoint(Segmento[14]->actor,Segmento[16]->actor, (Segmento[14]->shapes[4]->Ti.t),NxVec3(1,0,0));
		//Segmento[16]->fixShape();
	Segmento[18]=new Physic_VRShape(2,   16,  -1,0,0,0,   0,0,1,10, 0,1,0,-36, 37.08);
		Segmento[18]->setTransformT(Segmento[16]->shapes[5]->Ti, Segmento[18]->H);
		declarar_TI2(Segmento[18], gScene);
		NxDiagonalizeInertiaTensor(NxMat33(NxVec3(33435,-779, 617),NxVec3(-779, 39224,-804),NxVec3(617,-804,11521)), NxVec3(33435,39224,   11521),  Rot[18]);
		Segmento[18]->setCOMpose(NxMat34(Rot[18],(PelvisP + NxVec3(42, -207.74,-11.31))));
		Segmento[18]->setPMInertia(NxVec3( 33435,39224,   11521));
		revJoints[18] = CreateRevoluteJoint(Segmento[18]->actor,Segmento[16]->actor, (Segmento[16]->shapes[5]->Ti.t),NxVec3(0,0,1));
		//fixed[18] = CreateFixedJoint(Segmento[18]->actor,Segmento[16]->actor, (Segmento[16]->shapes[5]->Ti.t+NxVec3(0,.007,0)),NxVec3(0,0,1));
		//Segmento[18]->fixShape();
	
}

