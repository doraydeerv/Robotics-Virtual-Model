#include "Physic_VRSHAPE.h" 
#include "NxPhysics.h"

extern NxScene*          gScene;
void declarar_HD1(Physic_VRShape *Eslabon,  NxScene* gScene);
void declarar_HD2(Physic_VRShape *Eslabon, NxScene* gScene);
void declarar_CD(Physic_VRShape *Eslabon, NxScene* gScene);
/*
void declarar_HD1(Physic_VRShape *Eslabon)
{
 
 Eslabon[1].shapes[0]=new MeshActor("Shape_F1",      0,  -1, 0, 0, 0,   0, 1, 0, 0, 0, 0, -1, 0,   NxVec3(0.7,0.7,0.7), 0.00135);
 Eslabon[1].shapes[1]=new MeshActor("Shape_AX-12_Rotor", 0,  0,0,-1,-20,  0,1,0,-5,  1,0,0,-8,   NxVec3(1,0,0), 0.00135);
 Eslabon[1].crearsegmento(gScene);
}



void declarar_HD2(Physic_VRShape *Eslabon)
{

Eslabon[3].shapes[0]=new MeshActor("shape_AX-12", 0,    1, 0, 0, 0,    0, 1, 0, 0,     0, 0, 1, 0,   NxVec3(0,0,0), 0.00135);
Eslabon[3].shapes[1]=new MeshActor("Shape_F3", 0,   -1, -0, 0, 0,    0, 1, 0, -20.5,   0, 0, -1,3,   NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[3].shapes[2]=new MeshActor("Shape_F2", 1,   0 ,-1, 0, 0,    0, 0, 1, -23,  -1, 0, 0, 0,   NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[3].shapes[3]=new MeshActor("Shape_AX-12_Rotor",2,  0,0,-1,18,   0,1,0,0,  1,0,0,-8,  NxVec3(1,0,0), 0.00135);
Eslabon[3].crearsegmento(gScene);
}


void declarar_CD(Physic_VRShape *Eslabon)
{

Eslabon[5].shapes[0]=new MeshActor("shape_AX-12",0,   1 ,0, 0, 0,    0, 1, 0, 0,    0, 0, 1, 0, NxVec3(0,0,0), 0.00135);
Eslabon[5].shapes[1]=new MeshActor("Shape_F3",0,-1, -0, 0, 0, 0, 1, 0, -22.5, 0, 0, -1, 2, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[5].shapes[2]=new MeshActor("Shape_F10",1,   0, 0, -1, 0,    0, -1, 0, -7,   -1, 0, 0, 0, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[5].shapes[3]=new MeshActor("Shape_F10",2,  -1, 0, 0, 0,      0, -1, 0, 4,     0, 0, 1, 0, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[5].shapes[4]=new MeshActor("Shape_F9",3,    0,-1, 0, 0,      0, 0, 1, -17+5,    -1, 0, 0, -5, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[5].shapes[5]=new MeshActor("f11",4,         0, 1, 0, -19,   1, 0, 0, -15,    0, 0, -1, -15+25, NxVec3(0.7,0.7,0.7), 0.00135);
Eslabon[5].crearsegmento(gScene);
}

*/