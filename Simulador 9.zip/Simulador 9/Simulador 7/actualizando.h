#include <stdio.h>
#include "NxPhysics.h"
#include <math.h>
#include "Torso.h"
#include "BrazoIzquierdo.h"
#include "BrazoDerecho.h"
#include "PiernaIzquierda.h"
#include "PiernaDerecha.h"
#include "SegmentosC.h"

extern NxMat34 ROT;
extern float POSOR[4];
extern float ang_rad[19];
extern float pi;
extern Physic_VRShape *SegmentoC[19];
extern NxMat34 Id;
extern float Roll, Pitch, Yaw;
extern NxReal offsetc;
void act_shapes(Physic_VRShape *Eslabon)
{
		Eslabon->shapes[0]->setlocalpose(Id,Eslabon->shapes[0]->H);
		Eslabon->shapes[0]->setTransT(Eslabon->Ti, Eslabon->shapes[0]->H);
			(Id,Eslabon->shapes[0]->H);
			for (int j=1;j<=Eslabon->figuras;j++)
			{
			Eslabon->shapes[j]->setlocalpose(Eslabon->shapes[Eslabon->shapes[j]->padre]->localpose,Eslabon->shapes[j]->H);
			Eslabon->shapes[j]->setTransT(Eslabon->shapes[Eslabon->shapes[j]->padre]->Ti,Eslabon->shapes[j]->H);
			}

}

void actualiza()
{

/************************Brazo Derecho**************************************/
	SegmentoC[0]->actor->setGlobalPosition(NxVec3(POSOR[1],(POSOR[2])+offsetc,POSOR[3]));
	
		RotX(Pitch);
		NxMat33 RotPitch=ROT.M; 
		RotY(Roll);
		NxMat33 RotRoll=ROT.M;
		RotZ(Yaw);
		NxMat33 RotYaw=ROT.M;
		NxMat33 temp;
		temp.multiply(RotRoll, RotPitch);
		temp.multiply(RotYaw,temp);
		SegmentoC[0]->actor->setGlobalOrientation(temp);
		//SegmentoC[0]->setTransformT(SegmentoC[0]->H,temp);
		act_shapes(SegmentoC[0]);
		SegmentoC[0]->Ti=SegmentoC[0]->actor->getGlobalPose(); 
	
		RotZ(ang_rad[1]);
		ROT.multiply(ROT,SegmentoC[1]->H);
		SegmentoC[1]->setTransformT(SegmentoC[0]->shapes[22]->Ti, ROT);
		SegmentoC[1]->actor->setGlobalPose(SegmentoC[1]->Ti);
		act_shapes(SegmentoC[1]);
			
		RotZ(ang_rad[3]);
		ROT.multiply(ROT,SegmentoC[3]->H);
		SegmentoC[3]->setTransformT(SegmentoC[1]->shapes[1]->Ti, ROT);
		SegmentoC[3]->actor->setGlobalPose(SegmentoC[3]->Ti);
		act_shapes(SegmentoC[3]);

		RotZ(ang_rad[5]);
		ROT.multiply(ROT,SegmentoC[5]->H);
		SegmentoC[5]->setTransformT(SegmentoC[3]->shapes[3]->Ti, ROT);
		SegmentoC[5]->actor->setGlobalPose(SegmentoC[5]->Ti);
		act_shapes(SegmentoC[5]);
/****************************Brazo Izquierdo*********************************/

		RotZ(ang_rad[2]);
		ROT.multiply(ROT,SegmentoC[2]->H);
		SegmentoC[2]->setTransformT(SegmentoC[0]->shapes[23]->Ti, ROT);
		SegmentoC[2]->actor->setGlobalPose(SegmentoC[2]->Ti);
		act_shapes(SegmentoC[2]);
		
		
		
	
		RotZ(ang_rad[4]);
		ROT.multiply(ROT,SegmentoC[4]->H);
		SegmentoC[4]->setTransformT(SegmentoC[2]->shapes[1]->Ti, ROT);
		SegmentoC[4]->actor->setGlobalPose(SegmentoC[4]->Ti);
		act_shapes(SegmentoC[4]);
		
		
		
	
		RotZ(ang_rad[6]);
		ROT.multiply(ROT,SegmentoC[6]->H);
		SegmentoC[6]->setTransformT(SegmentoC[4]->shapes[3]->Ti, ROT);
		SegmentoC[6]->actor->setGlobalPose(SegmentoC[6]->Ti);
		act_shapes(SegmentoC[6]);
		
/****************************************Pierna Derecha*************************************/


		RotZ(ang_rad[7]);
		ROT.multiply(ROT,SegmentoC[7]->H);
		SegmentoC[7]->setTransformT(SegmentoC[0]->shapes[24]->Ti, ROT);
		SegmentoC[7]->actor->setGlobalPose(SegmentoC[7]->Ti);
		act_shapes(SegmentoC[7]);
		
	
	
	
		RotX(ang_rad[9]);
		ROT.multiply(ROT,SegmentoC[9]->H);	
		SegmentoC[9]->setTransformT(SegmentoC[7]->shapes[1]->Ti, ROT);
		SegmentoC[9]->actor->setGlobalPose(SegmentoC[9]->Ti);
		act_shapes(SegmentoC[9]);
	
	
	
		RotZ(ang_rad[11]);
		ROT.multiply(ROT,SegmentoC[11]->H);	
		SegmentoC[11]->setTransformT(SegmentoC[9]->shapes[5]->Ti, ROT);
		SegmentoC[11]->actor->setGlobalPose(SegmentoC[11]->Ti);
		act_shapes(SegmentoC[11]);
		
	
		RotZ(ang_rad[13]);
		ROT.multiply(ROT,SegmentoC[13]->H);
		SegmentoC[13]->setTransformT(SegmentoC[11]->shapes[2]->Ti, ROT);
		SegmentoC[13]->actor->setGlobalPose(SegmentoC[13]->Ti);
		act_shapes(SegmentoC[13]);
		
		
		

		RotZ(ang_rad[15]);
		ROT.multiply(ROT,SegmentoC[15]->H);
		SegmentoC[15]->setTransformT(SegmentoC[13]->shapes[4]->Ti, ROT);
		SegmentoC[15]->actor->setGlobalPose(SegmentoC[15]->Ti);
		act_shapes(SegmentoC[15]);
		
		
	
		RotZ(ang_rad[17]);
		ROT.multiply(ROT,SegmentoC[17]->H);
		SegmentoC[17]->setTransformT(SegmentoC[15]->shapes[5]->Ti, ROT);
		SegmentoC[17]->actor->setGlobalPose(SegmentoC[17]->Ti);
		act_shapes(SegmentoC[17]);
/****************************************Pierna Izquierda*************************************/
	
		RotZ(ang_rad[8]);
		ROT.multiply(ROT,SegmentoC[8]->H);
		SegmentoC[8]->setTransformT(SegmentoC[0]->shapes[25]->Ti, ROT);
		SegmentoC[8]->actor->setGlobalPose(SegmentoC[8]->Ti);
		act_shapes(SegmentoC[8]);
		
		RotX(ang_rad[10]);
		ROT.multiply(ROT,SegmentoC[10]->H);	
		SegmentoC[10]->setTransformT(SegmentoC[8]->shapes[1]->Ti, ROT);
		SegmentoC[10]->actor->setGlobalPose(SegmentoC[10]->Ti);
		act_shapes(SegmentoC[10]);

		RotZ(ang_rad[12]);
		ROT.multiply(ROT,SegmentoC[12]->H);	
		SegmentoC[12]->setTransformT(SegmentoC[10]->shapes[5]->Ti,ROT);
		SegmentoC[12]->actor->setGlobalPose(SegmentoC[12]->Ti);
		act_shapes(SegmentoC[12]);
		
	
		RotZ(ang_rad[14]);
		ROT.multiply(ROT,SegmentoC[14]->H);
		SegmentoC[14]->setTransformT(SegmentoC[12]->shapes[2]->Ti,ROT);
		SegmentoC[14]->actor->setGlobalPose(SegmentoC[14]->Ti);
		act_shapes(SegmentoC[14]);	

	
		RotZ(ang_rad[16]);
		ROT.multiply(ROT,SegmentoC[16]->H);
		SegmentoC[16]->setTransformT(SegmentoC[14]->shapes[4]->Ti, ROT);
		SegmentoC[16]->actor->setGlobalPose(SegmentoC[16]->Ti);
		act_shapes(SegmentoC[16]);
		
	
		RotZ(ang_rad[18]);
		ROT.multiply(ROT,SegmentoC[18]->H);
		SegmentoC[18]->setTransformT(SegmentoC[16]->shapes[5]->Ti, ROT);
		SegmentoC[18]->actor->moveGlobalPose(SegmentoC[18]->Ti);
		SegmentoC[18]->actor->setGlobalPose(SegmentoC[18]->Ti);
		act_shapes(SegmentoC[18]);

}