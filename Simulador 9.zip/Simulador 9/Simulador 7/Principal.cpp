#define NOMINMAX
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include<assert.h>
#include <time.h>


#include "Physic_VRSHAPE.h" //Libreria del Motor de F�sica

#include "FuncionesdeGLUT.h"
#include "Segmentos.h"
#include "SegmentosC.h"
#include "movimiento.h"
#include "BorsteIndugula.h"

float var_brazo=-90;
Physic_VRShape *Segmento[19];
Physic_VRShape *SegmentoC[19];
NxDistanceJoint *DistanceJoint[19];
float frame[517][25];
NxActor* Pelvis;
NxShape* CMT;
NxShape* ZMP;
NxActor* Esfera2;
NxVec3 posicionCM;
NxVec3 posicionZMP;
float ang_rad[19];
float set_ang[19];
float pi=3.1416;
float POSOR[4];
float Roll, Pitch, Yaw;
NxVec3 PCtmenos1[19];
NxVec3 PDtmenos1[19];
NxVec3  CMact,CMant,CMacel,CMVelant, CM;
float MasaTotal;
NxVec3 vel_lin_ant[19];	
NxVec3  num2anterior[19];	
NxVec3   NUM;	
NxReal ZMPx, ZMPz;
NxMat34 Identidad;
NxQuat qdtmenos1[19];
NxQuat qctmenos1[19];
NxReal offsetd = 250; // Elevaci�n sobre el suelo.
NxReal offsetc = 130;
FILE *f;
FILE *j;
//NxQuat qdtmenos1[19];
//NxQuat qctmenos1[19];
void PrintControls()
{
	printf("\n Control de Camara:\n ----------------\n w = Adelante, s = Atras\n a = Izquierda, d = Derecha\n q = Arriba, z = Abajo\n p = Pause\n");
    printf("\n Seleccionar Motor:\n --------------");
    printf("\n Brazo Derecho:  1,3,5"); 
	printf("\n Brazo Izquierdo:  2,4,6"); 
	printf("\n Pierna  Derecha:  7,9,B,D,F,H"); 
	printf("\n Pierna Izquierda: 8,A,C,E,G,I");
	printf("\n +: Incrementar Torque");
	printf("\n -: Decrementar Torque");
	printf("\n R: Liberar el segmento\n");
	printf("\n Otros:\n --------------\n #: Generar Reporte\n  ");

}
void valoresini()
{
	/*********zmp**********/

	MasaTotal=0;
	
	CM= NxVec3(0,0,0);
	CMVelant=NxVec3(0,0,0);
	for (int f=0; f<=18;f++)
	{
	vel_lin_ant[f]=NxVec3(0,0,0);
	num2anterior[f]=NxVec3(0,0,0);
	}
	CMant= NxVec3(0,0,0);

	
	/**********************/
	NxVec3 Eje= NxVec3(1,1,1);
	NxReal Ang= 0;
	for (int zz=0;zz<=18;zz++)
	{
	PCtmenos1[zz]=NxVec3(0,0,0);
	PDtmenos1[zz]=NxVec3(0,0,0);
	qdtmenos1[zz]=NxQuat(Ang, Eje);
	qctmenos1[zz]=NxQuat(Ang, Eje);
	//qdtmenos1[zz].id();
	//qctmenos1[zz].id();
	}
ang_rad[1]=(var_brazo*pi/180);
ang_rad[2]=(var_brazo*pi/180);
ang_rad[3]=(0*pi/180);
ang_rad[4]=(0*pi/180);
ang_rad[5]=0;
ang_rad[6]=0;

ang_rad[7]= (0*pi/180);
ang_rad[8]= (0*pi/180);

ang_rad[9]= (0*pi/180);
ang_rad[10]=(0*pi/180);

ang_rad[11]= (0*pi/180);
ang_rad[12]= (0*pi/180);

ang_rad[13]= 0;
ang_rad[14]= 0;

ang_rad[15]= 0; 
ang_rad[16]=0; 

ang_rad[17]= 0;
ang_rad[18]= 0;
}
void IniciarLecturaDinamica()
{

	f=fopen("PosicionesDinamico.txt","wt");
	fputs ( "Lectura de Humanoide Din�mico \n", f);

	//fclose(f);
}
void IniciarLecturaCinematica()
{

	j=fopen("PosicionesCinematico.txt","wt");
	fputs ( "Lectura de Humanoide Cinem�tico \n", j);

	//fclose(f);
}
void main( int argc, char **argv )
{
	
	PrintControls();
	InitGlut(argc, argv,"Simulacion Din�mica del Robot  Bioloid Premium Configuraci�n A");
	
	
	InitNx();
	Lectura();

	Pelvis= CreateSphere(NxVec3(frame[2][19]+ 42,(frame[2][20]+offsetc)-45,frame[2][21]+10),2,10);

	valoresini();
	Segmentos();
	masatotal();
	SegmentosCin();
	IniciarLecturaDinamica();
	IniciarLecturaCinematica();
	glutMainLoop();
	ReleaseNx();
	fclose(f);

	

}

