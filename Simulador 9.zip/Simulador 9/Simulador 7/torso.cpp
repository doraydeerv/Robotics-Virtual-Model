
#include "Torso.h"

void declarar_Torso(Physic_VRShape *Eslabon, NxScene* gScene)
{
		Eslabon->shapes[0]=new MeshActor("f51", 0,   1,0,0,0 ,  0,1,0,0,    0,0,1,-8,   NxVec3(0.7,0.7,0.7), 1130);
		Eslabon->shapes[1]=new MeshActor("f52", 0,   1,0,0,0,   0,1,0,0,  0,0,1,-3,NxVec3(0.7,0.7,0.7), 1070);
		Eslabon->shapes[2]=new MeshActor("cm-510",  1,  -1,0,0,87.5,   0,1,0,12,  0,0,-1,11,NxVec3(0.8,0.8,0.8), 560);
		Eslabon->shapes[3]=new MeshActor("Shape_f10",1,   1,0,0,44   ,0,1,0,68,  0,0,1,20,NxVec3(0.6,0.6,0.6),1330);//Base de Cabeza
		Eslabon->shapes[4]=new MeshActor("Shape_f9", 3,   0,1,0,0,   0,0,-1,13,  -1,0,0,-5,NxVec3(0.6,0.6,0.6), 1650);//Bases de Cabeza
		Eslabon->shapes[5]=new MeshActor("f57",    4,     0,0,-1,45,   1,0,0,-33 ,  0,-1,0,9,NxVec3(0.5,0.5,.50), 268);//Cabeza
		Eslabon->shapes[6]=new MeshActor("f56",   5,      1,0,0,3,   0,1,0,-4,   0,0,1,50,NxVec3(0.5,.5,.5), 214);//Cabeza
		Eslabon->shapes[7]=new MeshActor("f60",    1,     1,0,0,10,  0,-1,0,11.3,  0,0,-1,0,NxVec3(0.75,0.75,0.75), 640); //Base Bateria
		Eslabon->shapes[8]=new MeshActor("battery", 7,    1,0,0,-3,    0,1,0,0,   0,0,1,3,NxVec3(0.8,0.8,0.8),1420);
		Eslabon->shapes[9]=new MeshActor("f58",		0,	  1,0,0,-5,   0,1,0,-43,  0,0,1,0,NxVec3(0.5,0.5,0.5), 313);// 
		 /******Motor 1 de Brazo Izquierdo*************************************************/
		Eslabon->shapes[10]=new MeshActor("Shape_F3", 0,       0, 0, -1, 74,    1, 0, 0,26,    0, -1, 0, 33,NxVec3(0.8,0.8,0.8), 1430);
		Eslabon->shapes[11]=new MeshActor("shape_AX-12", 10,   0,1, 0, 4,       1, 0, 0, 16,   0, 0, -1, 2,NxVec3(0,0,0), 0.00135);
		Eslabon->shapes[12]=new MeshActor("Shape_F3",  11,    0, -1, 0, 14, -1, 0, 0, -2.5, 0, 0, -1, 2.5,NxVec3(0.8,0.8,0.8), 1430);
		 /*******Motor 2, Brazo Derecho************************************************/
		Eslabon->shapes[13]=new MeshActor("Shape_F3",0,       0, 0, -1, 18,    1, 0, 0, 026,    0, -1, 0,33,NxVec3(0.8,0.8,0.7), 1430);
		Eslabon->shapes[14]=new MeshActor("shape_AX-12",13, 0,1, 0, 4,     -1, 0, 0, 16,     0, 0, 1,0,NxVec3(0,0,0), 1430);
		Eslabon->shapes[15]=new MeshActor("Shape_F3",14,     0, 1, 0, -14,   1, 0, 0, -2.5,  0, 0, -1, 2.5,NxVec3(0.8,0.8,0.8), 1430);
		/**************** Motor 8,  Pierna Izquierda *************************************/
		Eslabon->shapes[16]=new MeshActor( "Shape_f53", 0,   1, 0, 0, 56,    0, 1, 0,-7,    0, 0, 1, 0,NxVec3(0.8,0.8,0.8), 0.00135);
		Eslabon->shapes[17]=new MeshActor("shape_AX-12",16,  0, 1, 0, 10, 0, 0, -1, -15, -1, 0, 0, 16,NxVec3(0,0,0), 0.00135);
		Eslabon->shapes[25]= new MeshActor("Shape_AX-12_Rotor", 17,  1,0,0,0,   0,1,0,15, 0,0,1,20,  NxVec3(1,0,0), 0.00135);
		/**************** Motor 7, Pierna Derecha******************************************/
		Eslabon->shapes[18]=new MeshActor("Shape_f53",0,    1, 0, 0, 8,    0, 1, 0, -7,    0, 0, 1, 0,NxVec3(0.8,0.8,0.8), 0.00135);
		Eslabon->shapes[19]=new MeshActor("shape_AX-12",18, 0, -1, 0,10, 0, 0, -1, -15, 1, 0, 0, 16,NxVec3(0,0,0), 0.00135);
		Eslabon->shapes[24]= new MeshActor("Shape_AX-12_Rotor", 19,  1,0,0,0,   0,1,0,15, 0,0,1,20,  NxVec3(1,0,0), 0.00135);
		/*************** Figuras entre motores 7 y 8, adelante y atr�s ***************************/
		Eslabon->shapes[20]=new MeshActor("Shape_F3",0,    1, 0, 0, 45,  0,0,-1,-24,     0, 1, 0, 0,NxVec3(0.8,0.8,0.8), 0.00135);
		Eslabon->shapes[21]=new MeshActor("Shape_F3",0,    1, 0, 0,43,  0,0,1,-24,     0, -1, 0, 30,NxVec3(0.8,0.8,0.8), 0.00135);
		/*************************Rotores de los brazos derecho e izquierdo**************************/
		Eslabon->shapes[22]=new MeshActor("Shape_AX-12_Rotor", 0,   0,0,-1,-3,  0,1,0,40,  1,0,0,17.5,    NxVec3(1,0,0), 0.00135);
		Eslabon->shapes[23]=new MeshActor("Shape_AX-12_Rotor", 0,   0,0,-1,92,  0,1,0,45,  1,0,0,17.5,    NxVec3(1,0,0), 0.00135);
		
		Eslabon->crearsegmento(gScene);

}

