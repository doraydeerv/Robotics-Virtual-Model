#include "BorsteIndugula.h"


void ResorteL(int numactor, float kL, float bL)
{
	/***************************************Lineal *******************************************************************/
	/* Resorte*/
	NxVec3 PosicionC=SegmentoC[numactor]->actor->getCMassGlobalPosition();
	NxVec3 PosicionD=Segmento[numactor]->actor->getCMassGlobalPosition();

	//printf("\nPosicionc: %.3f, %.3f, %.3f\tPosiciond: %.3f, %.3f, %.3f\n", PosicionC.x, PosicionC.y, PosicionC.z, PosicionD.x, PosicionD.y, PosicionD.z); 
		

	NxVec3 Pos= NxVec3(PosicionC.x-PosicionD.x, PosicionC.y-PosicionD.y, PosicionC.z-PosicionD.z);
	NxVec3 RTL=kL*Pos;
	/*Amortiguador*/
	NxVec3 VLC;
	NxVec3 VLD;
	NxReal Delta2=1.0/20.0;
	VLD=(PosicionD-PDtmenos1[numactor])/Delta2;
	VLC=(PosicionC-PCtmenos1[numactor])/Delta2;

	PCtmenos1[numactor]=PosicionC;
	PDtmenos1[numactor]=PosicionD;

	NxVec3 VLinealTL=NxVec3(VLD-VLC);

	NxVec3 ATL=-bL*VLinealTL;
	NxVec3 FTL=RTL+ATL;
	Segmento[numactor]->actor->addForce(FTL); 
	//printf("\nActor %d\n", numactor);
	//printf("\nError Posicion: %.3f, %.3f, %.3f/Fza Resorte %.0f, %.0f, %.0f,\nError Vel. Lin.: %.3f,%.3f,%.3f/Fza Amorti. %.0f, %.0f, %.0f\n", Pos.x, Pos.y, Pos.z,  RTL.x, RTL.y, RTL.z,VLinealTL.x, VLinealTL.y, VLinealTL.z, ATL.x, ATL.y, ATL.z); 
		
}

void ResorteT(float kT,float bT)
{
	/******************Torsional***********************************************************************************/
	/*Resorte*/
	NxQuat qc=SegmentoC[0]->actor->getGlobalOrientationQuat();

	NxQuat qd= Segmento[0]->actor->getGlobalOrientationQuat();

	NxQuat Errorq;
	NxQuat qdconj;
	
	NxReal ErrorqAngle;
	NxVec3 ErrorqAxis;
	NxVec3 Tresorte;

	qdconj = qd; qdconj.conjugate();
	Errorq=qdconj*qc;
	Errorq.getAngleAxis(ErrorqAngle, ErrorqAxis);

	
	
	NxVec3 Eangular;
	Eangular = ErrorqAngle * ErrorqAxis;

	Tresorte = (-kT) * Eangular;

	Segmento[0]->actor->addTorque(Tresorte);
	//printf("Diferencia Angular \t %.3f\t %.3f\t %.3f\n", Eangular.x, Eangular.y, Eangular.z); 
	//printf("Torque Resorte\t %.3f\t %.3f\t %.3f\n", Tresorte.x, Tresorte.y, Tresorte.z);

	/*************Amortiguador*/
	
	NxReal ad,adant, ac, acant;
	NxVec3 axd,axdant,axc, axcant;
	qd.getAngleAxis(ad, axd);
	qdtmenos1[0] .getAngleAxis(adant, axdant);
	NxVec3 ejed=ad*axd;
	NxVec3 ejedant=adant*axdant;
	//printf("\nDin�mico Anterior\t %.3f\t %.3f\t %.3f", ejedant.x, ejedant.y, ejedant.z); 
	//printf("\nDinamico Actual  \t %.3f\t %.3f\t %.3f", ejed.x, ejed.y, ejed.z); 
	NxVec3 Difangd = ejed-ejedant;
	//printf("\nDiferencia Angular  \t %.3f\t %.3f\t %.3f", Difangd.x, Difangd.y, Difangd.z);
	
	NxVec3 Velangd= Difangd/(1.0/20.0);
	//printf("\nVelocidad  Angular  \t %.3f\t %.3f\t %.3f", Velangd.x, Velangd.y, Velangd.z);
	qc.getAngleAxis(ac, axc);
	qctmenos1[0] .getAngleAxis(acant, axcant);
	NxVec3 ejec=ac*axc;
	NxVec3 ejecant=acant*axcant;
	//printf("\nCinematico Anterior\t %.3f\t %.3f\t %.3f", ejecant.x, ejecant.y, ejecant.z); 
	//printf("\nCinematico Actual  \t %.3f\t %.3f\t %.3f", ejec.x, ejec.y, ejec.z); 
	NxVec3 Difangc = ejec-ejecant;
	//printf("\nDiferencia Angular  \t %.3f\t %.3f\t %.3f", Difangc.x, Difangc.y, Difangc.z);

	NxVec3 Velangc= Difangc/(1.0/20.0);
	//printf("\nVelocidad  Angular  \t %.3f\t %.3f\t %.3f", Velangc.x, Velangc.y, Velangc.z);

	NxVec3 Tamortiguador;
	NxVec3 w= Velangd-Velangc;
	

	Tamortiguador = -bT *(Velangd-Velangc);
	
	qdtmenos1[0] = qd;
	qctmenos1[0] = qc;


	if (Tamortiguador.isFinite())
	{
		Segmento[0]->actor->addTorque(NxVec3(Tamortiguador.x,Tamortiguador.y,Tamortiguador.z));
		//printf("\nTorque Amortiguador\t %.3f\t %.3f\t %.3f\n", Tamortiguador.x, Tamortiguador.y, Tamortiguador.z);
	}
}
void ResorteT( int numactor, NxVec3 Eje,float kT,float bT)
{
		/******************Torsional***********************************************************************************/
	/*Resorte*/
	NxQuat qc=SegmentoC[numactor]->actor->getGlobalOrientationQuat();
	NxQuat qd=Segmento[numactor]->actor->getGlobalOrientationQuat();
	

	NxQuat Errorq;
	NxQuat qdconj;
	
	NxReal ErrorqAngle;
	NxVec3 ErrorqAxis;
	

	qdconj = qd; qdconj.conjugate();
	Errorq=qdconj*qc;
	Errorq.getAngleAxis(ErrorqAngle, ErrorqAxis);
	
	NxVec3 Eangular;
	Eangular = ErrorqAngle*ErrorqAxis;
	
	
			

	//Eangular.arrayMultiply(Eangular, Eje);
	NxVec3 Tresorte;
	Tresorte = (-kT) * Eangular;

	Segmento[numactor]->actor->addLocalTorque(Tresorte);
	printf("\nDiferencia Angular \t %.3f\t %.3f\t %.3f", Eangular.x, Eangular.y, Eangular.z); 
	printf("\nTorque Resorte\t %.3f\t %.3f\t %.3f", Tresorte.x, Tresorte.y, Tresorte.z);
	
	


	/*************Amortiguador*/
	
	NxReal ad,adant, ac, acant;
	NxVec3 axd,axdant,axc, axcant;
	qd.getAngleAxis(ad, axd);
	qdtmenos1[numactor] .getAngleAxis(adant, axdant);
	NxVec3 ejed=ad*axd;
	NxVec3 ejedant=adant*axdant;
	//printf("\nDin�mico Anterior\t %.3f\t %.3f\t %.3f", ejedant.x, ejedant.y, ejedant.z); 
	printf("\nDinamico Actual  \t %.3f\t %.3f\t %.3f", ejed.x, ejed.y, ejed.z); 
	NxVec3 Difangd = ejed-ejedant;
	//printf("\nDiferencia Angular  \t %.3f\t %.3f\t %.3f", Difangd.x, Difangd.y, Difangd.z);
	
	NxVec3 Velangd= Difangd/(1.0/20.0);
	//printf("\nVelocidad  Angular  \t %.3f\t %.3f\t %.3f", Velangd.x, Velangd.y, Velangd.z);
	qc.getAngleAxis(ac, axc);
	qctmenos1[numactor] .getAngleAxis(acant, axcant);
	NxVec3 ejec=ac*axc;
	NxVec3 ejecant=acant*axcant;
	//printf("\nCinematico Anterior\t %.3f\t %.3f\t %.3f", ejecant.x, ejecant.y, ejecant.z); 
	printf("\nCinematico Actual  \t %.3f\t %.3f\t %.3f", ejec.x, ejec.y, ejec.z); 
	NxVec3 Difangc = ejec-ejecant;
	//printf("\nDiferencia Angular  \t %.3f\t %.3f\t %.3f", Difangc.x, Difangc.y, Difangc.z);

	NxVec3 Velangc= Difangc/(1.0/20.0);
	//printf("\nVelocidad  Angular  \t %.3f\t %.3f\t %.3f", Velangc.x, Velangc.y, Velangc.z);



	NxVec3 Tamortiguador;
	NxVec3 w= Velangd-Velangc;
	
	Tamortiguador = -bT *(Velangd-Velangc);
	//Tamortiguador.arrayMultiply(Tamortiguador, Eje);
	qdtmenos1[numactor] = qd;
	qctmenos1[numactor] = qc;


	if (Tamortiguador.isFinite())
	{
		Segmento[numactor]->actor->addLocalTorque(NxVec3(Tamortiguador.x,Tamortiguador.y,Tamortiguador.z));
		printf("\nTorque Amortiguador\t %.3f\t %.3f\t %.3f\n", Tamortiguador.x, Tamortiguador.y, Tamortiguador.z);
	}
}
void updateSpring(int numactor, NxVec3 Eje, NxReal offset)
{
	NxQuat qcant=SegmentoC[SegmentoC[numactor]->padre]->actor->getGlobalOrientationQuat();
	NxQuat qcact=SegmentoC[numactor]->actor->getGlobalOrientationQuat();
	NxQuat qcantc = qcant;
	NxQuat qcantqcact;
	qcantc.conjugate();
	qcantqcact.multiply(qcantc, qcact);
	NxReal angle;
	NxVec3 ejec;
	qcantqcact.getAngleAxis(angle,ejec);
		
	NxReal anglec= 0;
	NxVec3 ejecc; ejecc=NxVec3(0,0,0);
	NxVec3 angeje;angeje= NxVec3(0,0,0);
	/********/
	if (((numactor==13)|(numactor==14))   & (angle>180))
	{
		angle= (angle-360);
		//printf("El 13 se pasa de 180 grados");
	}
	if ((numactor==16))
		angle= angle-180;
	if (((numactor==17)|(numactor==18))& ((angle<180)|(angle>180)))
		angle=180-angle;
	
	/**************/
	NxVec3 angulo= (angle * ejec);

	
	NxReal ang;

	if (Eje.x==1)
		ang=angulo.x;
	if (Eje.y==1)
		ang=angulo.y;
	if (Eje.z==1)
		ang=angulo.z;
	if (Eje.x==-1)
		ang=-angulo.x;
	if (Eje.y==-1)
		ang=-angulo.y;
	if (Eje.z==-1)
		ang=-angulo.z;
	
	NxSpringDesc springDesc;
	revJoints[numactor]->getSpring(springDesc);
	springDesc.spring = 999999999999999999;
	springDesc.damper = 0;
	springDesc.targetValue=(ang*pi/180) + offset;
	set_ang[numactor]= (ang*pi/180) + offset;
	revJoints[numactor]->setSpring(springDesc);
	//if (numactor ==5)
	//{
	//	printf ("\nSegmento 5 Angulo %.3f Ang-Eje %.3f, ", angle, ang );
	//	printf("\nAngulo target %.3f rads , %.3f grados", springDesc.targetValue, springDesc.targetValue*180/pi );
	//}	
	//printf ("  Segmento %d Angulo %.3f Angulo-Eje %.3f ", numactor, angle, ang );
}
void BorstIndugula()
{

	ResorteL( 0, 15000,3000);
	ResorteT(-900000,100000);
	
	ResorteT(1,NxVec3(0,0,-1),1000000000000000,1000);
	ResorteT(2,NxVec3(0,0,1),1000,1000);
	ResorteT(3,NxVec3(0,0,-1),1000000000000000,1000);
	ResorteT(4,NxVec3(0,0,-1),1000,1000);
	/*updateSpring(1, NxVec3(0,0,-1), (85*pi/180));
	updateSpring(2, NxVec3(0,0,1),(-85*pi/180));
	updateSpring(3, NxVec3(0,0,-1), (-100*pi/180));
	updateSpring(4, NxVec3(0,0,-1),(100*pi/180));
	//updateSpring(5, NxVec3(0,1,0),(6*pi/180));
	//updateSpring(6, NxVec3(0,1,0),(-8*pi/180));
	ResorteL( 5, 500,800);
	ResorteL( 6, 500,800);*/
	updateSpring(7, NxVec3(0,0,1), (0*pi/180));
	updateSpring(8, NxVec3(0,0,1),(0*pi/180));
	updateSpring(9, NxVec3(0,0,1),(-125*pi/180));
	updateSpring(10, NxVec3(0,0,1),(-125*pi/180));
	updateSpring(11, NxVec3(0,1,0),(125*pi/180));
	updateSpring(12, NxVec3(0,-1,0),(-125*pi/180));
	updateSpring(13, NxVec3(0,1,0), 0);
	updateSpring(14, NxVec3(0,1,0),(0*pi/180));
	updateSpring(15, NxVec3(0,0,-1),(270*pi/180));
	updateSpring(16, NxVec3(0,0,1),(90*pi/180));
	updateSpring(17, NxVec3(0,-1,0), (35*pi/180));
	updateSpring(18, NxVec3(0,1,0),(35*pi/180));
	ResorteL( 17, 3000,1000);
	ResorteL( 18, 3000,1000);
	
/*	NxQuat qc=SegmentoC[5]->actor->getGlobalOrientationQuat();
	NxReal angle;
	NxVec3 ejec;
	qc.getAngleAxis(angle,ejec);
	NxVec3 angulo= (angle * ejec);
	printf("\nAngulo Cinematico %.3f %.3f %.3f %.3f", angle,  angulo.x, angulo.y, angulo.z );
	//NxReal angd =revJoints[5]->getAngle();
	//prin*/
}





