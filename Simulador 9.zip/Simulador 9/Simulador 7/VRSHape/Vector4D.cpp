// Vector4D.cpp: implementation of the Vector4D class.
//
//////////////////////////////////////////////////////////////////////

#include "Vector4D.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Vector4D::Vector4D()
{
		a = 0;
		x = 0;
		y = 0;
		z = 0;
}

Vector4D::Vector4D(float a, float x, float y, float z)			// Constructor that initializes this VectorAD to the intended values of x, y and z
	{
		this->a = a;
		this->x = x;
		this->y = y;
		this->z = z;
	}

Vector4D::Vector4D(float a[4])	
	{
		this->a = a[0];
		this->x = a[1];
		this->y = a[2];
		this->z = a[3];
	}

float Vector4D::operator[] (int v)			
	{
	if (v==0) return a;
	else if (v==1) return x;
	else if (v==2) return y;
	else if (v==3) return z;
	else return -99999999.0f;
	}


Vector4D::~Vector4D()
{

}
