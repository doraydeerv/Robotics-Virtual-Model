// MeshActor.cpp: implementation of the MeshActor class.
//
//////////////////////////////////////////////////////////////////////

#include <string.h>
#include "MeshActor.h"

extern NxPhysicsSDK*     gPhysicsSDK;
extern NxScene*          gScene;

static NxU32 getFileSize(const char* name)
{
	#ifndef SEEK_END
	#define SEEK_END 2
	#endif
	
	FILE * File = fopen(name, "rb");
	if(!File)
		return 0;

	fseek(File, 0, SEEK_END);
	NxU32 eof_ftell = ftell(File);
	fclose(File);
	return eof_ftell;
}

void MeshActor::readFileTri(char *filetri){

	FILE *f;
	char tmpChar[255];

	f=fopen(filetri,"rt");
	fscanf(f,"%s",tmpChar);
	fscanf(f,"%s",tmpChar); BUNNY_NBVERTICES=atoi(tmpChar);
	fscanf(f,"%s",tmpChar); BUNNY_NBFACES=atoi(tmpChar);
	gBunnyVertices=new float[BUNNY_NBVERTICES*3];
	gBunnyTriangles=new int[BUNNY_NBFACES*3];

	for (unsigned int i=0, vert=0; i<BUNNY_NBVERTICES*3; i++)
	{
		fscanf(f,"%s",tmpChar); gBunnyVertices[vert++]=atof(tmpChar);
	}
	int tri=0;
	for (int i=0; i<BUNNY_NBFACES*3; i++)
	{
		fscanf(f,"%s",tmpChar); gBunnyTriangles[tri++]=atoi(tmpChar);
	}
	fclose(f);
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
 
MeshActor::MeshActor(char *file, int Padre , float a, float b, float c, float d, float e, float f, float g, float h, float i, float j, float k, float l,  NxVec3 Color, float densidad)
{
char extri[5]=".tri";
char extpmap[6]=".pmap";
strcpy (filetri, file);
strcpy (filepmap, file);
strcat (filetri, extri);
strcat (filepmap, extpmap);
padre= Padre;
color= Color;

	readFileTri(filetri);
	// Scale the bunny a bit
	//for(NxU32 i=0;i<BUNNY_NBVERTICES*3;i++)	gBunnyVertices[i] /= 1000.0f;

	gBunnyNormals = new NxVec3[BUNNY_NBVERTICES];
	NxBuildSmoothNormals(BUNNY_NBFACES, BUNNY_NBVERTICES, (const NxVec3*)gBunnyVertices, (const NxU32*)gBunnyTriangles, NULL, gBunnyNormals, true);

	// Initialize PMap
	NxPMap bunnyPMap;
	bunnyPMap.dataSize	= 0;
	bunnyPMap.data		= NULL;

	// Build physical model
	NxTriangleMeshDesc bunnyDesc;
	bunnyDesc.numVertices				= BUNNY_NBVERTICES;
	bunnyDesc.numTriangles				= BUNNY_NBFACES;
	bunnyDesc.pointStrideBytes			= sizeof(NxVec3);
	bunnyDesc.triangleStrideBytes		= 3*sizeof(NxU32);
	bunnyDesc.points					= gBunnyVertices;
	bunnyDesc.triangles					= gBunnyTriangles;							
	bunnyDesc.flags						= 0;



	NxInitCooking();
	MemoryWriteBuffer buf;
	bool status = NxCookTriangleMesh(bunnyDesc, buf);
	MemoryReadBuffer readBuffer(buf.data);
	bunnyTriangleMesh = gPhysicsSDK->createTriangleMesh(readBuffer);
	
	


	// PMap stuff
	// Try loading PMAP from disk
	FILE* fp = fopen(filepmap, "rb");
	if(!fp)
		{
		// Not found => create PMap
		printf("please wait while precomputing pmap...\n");
		if(NxCreatePMap(bunnyPMap, *bunnyTriangleMesh, 64))
			{
			// The pmap has successfully been created, save it to disk for later use
			fp = fopen(filepmap, "wb");
			if(fp)
				{
				fwrite(bunnyPMap.data, bunnyPMap.dataSize, 1, fp);
				fclose(fp);
				fp = NULL;
				}

			//assign pmap to mesh
			bunnyTriangleMesh->loadPMap(bunnyPMap);

			// sdk created data => sdk deletes it
			NxReleasePMap(bunnyPMap);
			}
		printf("...done\n");
		}
	else
		{
		// Found pmap file
		bunnyPMap.dataSize	= getFileSize(filepmap);
		bunnyPMap.data		= new NxU8[bunnyPMap.dataSize];
		fread(bunnyPMap.data, bunnyPMap.dataSize, 1, fp);
		fclose(fp);

		//assign pmap to mesh
		bunnyTriangleMesh->loadPMap(bunnyPMap);
		
		//we created data => we delete it
		delete bunnyPMap.data;
		}


		//create triangle mesh instance
	//NxTriangleMeshShapeDesc bunnyShapeDesc;
	bunnyShapeDesc.meshData	= bunnyTriangleMesh;
	

	// Create body
	//NxBodyDesc BodyDesc;
	//BodyDesc.angularDamping	= 0.5f;
	//BodyDesc.maxAngularVelocity	= 10.0f;

	//ActorDesc.shapes.pushBack(&bunnyShapeDesc);
	//ActorDesc.body			= &BodyDesc;
	//ActorDesc.density		= density;
	//ActorDesc.globalPose.t  = pos;
	//actor= gScene->createActor(ActorDesc);
	

	//display_list=glGenLists(1);
	//glNewList(display_list, GL_COMPILE);
	
		glBegin (GL_TRIANGLES);
		const int* indices = gBunnyTriangles;
		for(unsigned int iii=0;iii<BUNNY_NBFACES;iii++)
		{
			for(int j=0;j<3;j++)
			{
				int vref0 = *indices++;
						
 				glNormal3f (gBunnyNormals[vref0].x,gBunnyNormals[vref0].y,gBunnyNormals[vref0].z);
			    glVertex3f (gBunnyVertices[vref0*3+0],gBunnyVertices[vref0*3+1],gBunnyVertices[vref0*3+2]);
				
			}
		}
		glEnd();
	
	//glEndList();

	setTransH(a,b,c,d,e,f,g,h,i,j,k,l);
	
	

}

MeshActor::MeshActor(char *filetri, char *filemap, NxVec3 pos, NxReal density, NxScene* scene, NxPhysicsSDK *psdk)
{

	gScene=scene;
	gPhysicsSDK=psdk;

	readFileTri(filetri);

	// Scale the bunny a bit
	//for(NxU32 i=0;i<BUNNY_NBVERTICES*3;i++)	gBunnyVertices[i] /= 1000.0f;

	// Build vertex normals (used only for rendering)
	gBunnyNormals = new NxVec3[BUNNY_NBVERTICES];
	NxBuildSmoothNormals(BUNNY_NBFACES, BUNNY_NBVERTICES, (const NxVec3*)gBunnyVertices, (const NxU32*)gBunnyTriangles, NULL, gBunnyNormals, true);

	// Initialize PMap
	NxPMap bunnyPMap;
	bunnyPMap.dataSize	= 0;
	bunnyPMap.data		= NULL;

	// Build physical model
	NxTriangleMeshDesc bunnyDesc;
	bunnyDesc.numVertices				= BUNNY_NBVERTICES;
	bunnyDesc.numTriangles				= BUNNY_NBFACES;
	bunnyDesc.pointStrideBytes			= sizeof(NxVec3);
	bunnyDesc.triangleStrideBytes		= 3*sizeof(NxU32);
	bunnyDesc.points					= gBunnyVertices;
	bunnyDesc.triangles					= gBunnyTriangles;							
	bunnyDesc.flags						= 0;



	NxInitCooking();
	MemoryWriteBuffer buf;
	bool status = NxCookTriangleMesh(bunnyDesc, buf);
	MemoryReadBuffer readBuffer(buf.data);
	bunnyTriangleMesh = gPhysicsSDK->createTriangleMesh(readBuffer);

	


	// PMap stuff
	// Try loading PMAP from disk
	FILE* fp = fopen(filemap, "rb");
	if(!fp)
		{
		// Not found => create PMap
		printf("please wait while precomputing pmap...\n");
		if(NxCreatePMap(bunnyPMap, *bunnyTriangleMesh, 64))
			{
			// The pmap has successfully been created, save it to disk for later use
			fp = fopen(filemap, "wb");
			if(fp)
				{
				fwrite(bunnyPMap.data, bunnyPMap.dataSize, 1, fp);
				fclose(fp);
				fp = NULL;
				}

			//assign pmap to mesh
			bunnyTriangleMesh->loadPMap(bunnyPMap);

			// sdk created data => sdk deletes it
			NxReleasePMap(bunnyPMap);
			}
		printf("...done\n");
		}
	else
		{
		// Found pmap file
		bunnyPMap.dataSize	= getFileSize(filemap);
		bunnyPMap.data		= new NxU8[bunnyPMap.dataSize];
		fread(bunnyPMap.data, bunnyPMap.dataSize, 1, fp);
		fclose(fp);

		//assign pmap to mesh
		bunnyTriangleMesh->loadPMap(bunnyPMap);

		//we created data => we delete it
		delete bunnyPMap.data;
		}


		//create triangle mesh instance
	//NxTriangleMeshShapeDesc bunnyShapeDesc;
	bunnyShapeDesc.meshData	= bunnyTriangleMesh;
	

	// Create body
	//NxBodyDesc BodyDesc;
	//BodyDesc.angularDamping	= 0.5f;
	//BodyDesc.maxAngularVelocity	= 10.0f;

	//ActorDesc.shapes.pushBack(&bunnyShapeDesc);
	//ActorDesc.body			= &BodyDesc;
	//ActorDesc.density		= density;
	//ActorDesc.globalPose.t  = pos;
	//actor= gScene->createActor(ActorDesc);
	

	display_list=glGenLists(1);
	glNewList(display_list, GL_COMPILE);
	
		glBegin (GL_TRIANGLES);
		const int* indices = gBunnyTriangles;
		for(unsigned int iii=0;iii<BUNNY_NBFACES;iii++)
		{
			for(int j=0;j<3;j++)
			{
				int vref0 = *indices++;
						
 				glNormal3f (gBunnyNormals[vref0].x,gBunnyNormals[vref0].y,gBunnyNormals[vref0].z);
			    glVertex3f (gBunnyVertices[vref0*3+0],gBunnyVertices[vref0*3+1],gBunnyVertices[vref0*3+2]);
				
			}
		}
		glEnd();
	
	glEndList();


}


MeshActor::MeshActor( char *filetri, NxVec3 pos, NxReal density, NxScene* scene, NxPhysicsSDK *psdk) //convex
{

	gScene=scene;
	gPhysicsSDK=psdk;

	readFileTri(filetri);

	// Build vertex normals (used only for rendering)
	gBunnyNormals = new NxVec3[BUNNY_NBVERTICES];
	NxBuildSmoothNormals(BUNNY_NBFACES, BUNNY_NBVERTICES, (const NxVec3*)gBunnyVertices, (const NxU32*)gBunnyTriangles, NULL, gBunnyNormals, true);


	// Build physical model
	NxConvexMeshDesc bunnyDesc;
	//bunnyDesc.numTriangles				= BUNNY_NBFACES;
	bunnyDesc.numVertices				= BUNNY_NBVERTICES;
	bunnyDesc.pointStrideBytes			= sizeof(NxVec3);
	bunnyDesc.points					= gBunnyVertices;
	bunnyDesc.flags						= NX_CF_COMPUTE_CONVEX | NX_CF_USE_LEGACY_COOKER;

	NxInitCooking();
	MemoryWriteBuffer buf;
	bool status = NxCookConvexMesh(bunnyDesc, buf);
	MemoryReadBuffer readBuffer(buf.data);
	bunnyConvexMesh = gPhysicsSDK->createConvexMesh(readBuffer);


		//create triangle mesh instance
	NxConvexShapeDesc bunnyShapeDesc;
	bunnyShapeDesc.meshData	= bunnyConvexMesh;

	/*// Create body
	NxBodyDesc BodyDesc;
	BodyDesc.angularDamping	= 0.5f;
	BodyDesc.maxAngularVelocity	= 10.0f;

	ActorDesc.shapes.pushBack(&bunnyShapeDesc);
	ActorDesc.body			= &BodyDesc;
	ActorDesc.density		= .50f;
	ActorDesc.globalPose.t  = pos;
	actor= gScene->createActor(ActorDesc);*/



	NxShape*const* shapes = actor->getShapes();
    shapes[0]->isConvexMesh()->getConvexMesh().saveToDesc(cmd);
    shapes[0]->userData = (void*)&cmd;

 
	display_list=glGenLists(1);
	glNewList(display_list, GL_COMPILE);
	
		glBegin (GL_TRIANGLES);
		const int* indices = gBunnyTriangles;
		for(unsigned int iii=0;iii<BUNNY_NBFACES;iii++)
		{
			for(int j=0;j<3;j++)
			{
				int vref0 = *indices++;
						
 				glNormal3f (gBunnyNormals[vref0].x,gBunnyNormals[vref0].y,gBunnyNormals[vref0].z);
			    glVertex3f (gBunnyVertices[vref0*3+0],gBunnyVertices[vref0*3+1],gBunnyVertices[vref0*3+2]);
				printf("Dibujando triangulos indicando tres vertices");
			}
		}
		glEnd();
	glEndList();
}


void MeshActor::render()
{

						float glmat[16];
						glPushMatrix();
						bunnyShapeDesc.localPose.getColumnMajor44(glmat);
						glMultMatrixf(glmat);
						RenderBunny();
						//glCallList(display_list);

						glPopMatrix();
							// Handle shadows
//							if(gShadows)
							/*{
							glPushMatrix();
								const static float ShadowMat[]={ 1,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,1 };
								glMultMatrixf(ShadowMat);
							glMultMatrixf(glmat);
								glDisable(GL_LIGHTING);
							glColor4f(0.1f, 0.1f, 0.1f, 1.0f);
							RenderBunny();
							glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
							glEnable(GL_LIGHTING);
								glPopMatrix();
							}*/
}

void MeshActor::render(NxMat34 M)
{
	float glmat[16];
	glPushMatrix();
		M.getColumnMajor44(glmat);
		glMultMatrixf(glmat);
		RenderBunny();
	glPopMatrix();
}

NxActor *MeshActor::getActor()
{
	return actor;
}

void MeshActor::RenderBunny()
{
		glBegin (GL_TRIANGLES);
		glColor3f(color.x, color.y, color.z);	
		const int* indices = gBunnyTriangles;
		for(unsigned int iii=0;iii<BUNNY_NBFACES;iii++)
		{
			for(int j=0;j<3;j++)
			{
				int vref0 = *indices++;
				
 				glNormal3f (gBunnyNormals[vref0].x,gBunnyNormals[vref0].y,gBunnyNormals[vref0].z);
			    glVertex3f (gBunnyVertices[vref0*3+0],gBunnyVertices[vref0*3+1],gBunnyVertices[vref0*3+2]);

			}
		}
		glEnd();

		/*

	float* pVertList = NULL;
	float* pNormList = NULL;

	if(pVertList == NULL && pNormList == NULL)
	{
		pVertList = new float[BUNNY_NBFACES*3*3];
		pNormList = new float[BUNNY_NBFACES*3*3];

		int vertIndex = 0;
		int normIndex = 0;
		const int* indices = gBunnyTriangles;
		for(unsigned int i=0;i<BUNNY_NBFACES;i++)
		{
			for(int j=0;j<3;j++)
			{
				int vref0 = *indices++;
						
				pVertList[vertIndex++] = gBunnyVertices[vref0*3+0];
				pVertList[vertIndex++] = gBunnyVertices[vref0*3+1];
				pVertList[vertIndex++] = gBunnyVertices[vref0*3+2];

				pNormList[normIndex++] = gBunnyNormals[vref0].x;
				pNormList[normIndex++] = gBunnyNormals[vref0].y;
				pNormList[normIndex++] = gBunnyNormals[vref0].z;
			}
		}
	}

	if(pVertList != NULL && pNormList != NULL)
	{
		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3,GL_FLOAT, 0, pVertList);
		glEnableClientState(GL_NORMAL_ARRAY);
		glNormalPointer(GL_FLOAT, 0, pNormList);
	

		glDrawArrays(GL_TRIANGLES, 0, BUNNY_NBFACES*3);
	
		glDisableClientState(GL_NORMAL_ARRAY);
		glDisableClientState(GL_VERTEX_ARRAY);
		
	}

	delete pVertList;
	delete pNormList;*/
}

void MeshActor::setTransH(float a, float b, float c,float d, float e, float f,float g, float h, float i,float j, float k, float l )
{
	NxMat33 r(NxVec3(a,b,c),NxVec3(e,f,g),NxVec3(i,j,k));  
	NxVec3  t(NxVec3(d,h,l));
	//NxMat34 hl;
	H.M =r;
	H.t= t;
	
	/*NxMat34 Prem1;
	NxMat34 Prem2;
	NxMat34 RZ270(NxMat33(NxVec3(0,1,0),NxVec3(-1,0,0),NxVec3(0,0,1)), NxVec3(0,0,0));
	NxMat34 RX90(NxMat33(NxVec3(1,0,0),NxVec3(0,0,-1),NxVec3(0,1,0)),NxVec3(0,0,0));
	Prem1.multiply(RZ270,RX90);
	Prem2.multiply(hl,Prem1);
	H=Prem2;*/
}
	
void MeshActor::setTransT(NxMat34 Tant,NxMat34 H)
{

 Ti.multiply (Tant,H);
 
}

void MeshActor::setlocalpose(NxMat34 localant,NxMat34 H)

{
localpose.multiply(localant,H);

}

void DrawmiMesh(NxShape* mesh)
{
	
   
}