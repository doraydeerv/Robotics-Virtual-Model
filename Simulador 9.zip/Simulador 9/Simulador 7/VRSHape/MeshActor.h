// MeshActor.h: interface for the MeshActor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_MESHACTOR_H__)
#define _MESHACTOR_H__

#if _MSC_VER > 1000
#pragma once
#endif 

#include "NxPhysics.h"
#include "NxCooking.h"
#include "Stream.h"
#include "stdio.h"

#include<gl\glut.h>									//basic header file for OpenGL 

class MeshActor
{

  public:

		//NxPhysicsSDK		*gPhysicsSDK;
		//NxScene				*gScene;
	    NxActor				*actor;

		NxTriangleMesh		* bunnyTriangleMesh;
		NxTriangleMeshShapeDesc bunnyShapeDesc;
		NxConvexMesh		* bunnyConvexMesh;
		NxConvexMeshDesc	 cmd;
	//	NxActorDesc			ActorDesc;


		unsigned int		BUNNY_NBVERTICES;
		unsigned int		BUNNY_NBFACES;
		float				*gBunnyVertices;
		int					*gBunnyTriangles;
		NxVec3				*gBunnyNormals;
		NxMat34 H;
		NxMat34 Ti;
		NxMat34 localpose;
		int padre;
		int display_list;
		char filetri[255];
		char filepmap[255];
		NxVec3 color;
	MeshActor::MeshActor(char *file, int padre , float a, float b, float c, float d, float e, float f, float g, float h, float i, float j, float k, float l,  NxVec3 color, float densidad);
    MeshActor(char *filetri, char *filemap, NxVec3 pos, NxReal density, NxScene* scene, NxPhysicsSDK *psdk);
	MeshActor( char *filetri, NxVec3 pos, NxReal density, NxScene* scene, NxPhysicsSDK *psdk);
	void MeshActor::setTransH(float a, float b, float c,float d, float e, float f,float g, float h, float i,float j, float k, float l );
    void MeshActor::setTransT(NxMat34 Tant,NxMat34 H);
	void MeshActor::setlocalpose(NxMat34 localant,NxMat34 H);
	void MeshActor::DrawmiMesh(NxShape* mesh);
	MeshActor();
	~MeshActor();
	void render();
	void render(NxMat34);
	void RenderBunny();
	NxActor *getActor();
	void MeshActor::readFileTri(char *filetri);

};
 
#endif 
