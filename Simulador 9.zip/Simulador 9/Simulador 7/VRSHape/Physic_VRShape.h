 // Physic_VRShape.h: interface for the Physic_VRShape class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_PHYSIC_VRSHAPE_H__)
#define _PHYSIC_VRSHAPE_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
 
#include "CommonCode2.h"
#include "NxPhysics.h"
#include "MeshActor.h"
#include "Vector4D.h"
typedef char cadena[255];

class Physic_VRShape  
{
public:

		
		MeshActor *shapes[26];
		NxMat34  H;
		NxMat34  Ti;
		NxBodyDesc BodyDesc;
		int padre;
		NxMat34 Id;
		NxPhysicsSDK		*gPhysicsSDK;
		NxScene				*gScene;
		float PESO;
	Physic_VRShape(int elems, int padre, float a,float b, float c, float d, float e, float f, float g, float h, float i, float j, float k, float l, float peso);
	Physic_VRShape( char *filename, NxScene* gScene, NxPhysicsSDK *gPhysicsSDK);
	virtual		~Physic_VRShape();
	void		initial_transformation();
	void		translation(NxVec3 t);
	void		translation(NxReal x,NxReal y,NxReal z);
	void		rotAxis(NxReal angle, NxReal x, NxReal y, NxReal z);
	void		rotAxis(Vector4D r);
	void		rotQuat(NxQuat r);
	void		getTransform(NxVec3 *t, NxQuat *q);
	void		setTransform(NxVec3 t, NxQuat q);
	void		getTransformAx(NxVec3 *t, Vector4D *rot);
	void		getTransformAx(float *t, Vector4D *rot);
	void        setTransformH(float a, float b, float c,float d, float e, float f,float g, float h, float i,float j, float k, float l );
	void        setTransformT(NxMat34 Tant,NxMat34 H);
	void        setCOMglobal(NxVec3 comglobal);
	void        setPMInertia(NxVec3 pminertia);
	void        setCOMpose(NxMat34 compose);
	void		getQuaternion(NxQuat *q);
	
	NxMat34     getEndTi();
	NxVec3		getCMass();
	NxVec3		getCMassLocal();
	void		render();
	void		renderMesh();
	void		renderShadow(NxReal height);
	int			getID();
	int			getVertices();
	float		getVertexCoord(int vi, int j);
	int			getFaces();
	int			getFaceIndex(int i, int j);
	void		fixShape();
	void		releaseShape();
	void		setGravity();
	void		removeGravity();
	void        crearsegmento(NxScene* scene);
	NxVec3      colorr;
	NxActor *getActor();

	cadena OGL_FILENAME[10];
	cadena PHYSX_FILENAME[10];
	int  figuras;
	NxActorDesc ActorDesc;
	NxActor *actor;
protected:


//	NxVec3 com;

private:
	
	
	int OBJECT_ID;

	// Transformations for object1
	NxReal R[9];
	NxReal T[3];
//	NxReal Q[4];    // Quaternion for the second object's rotation

	float TRANS[3];

	float ANGLE;
	float AXX;
	float AXY;
	float AXZ;
	
};

#endif // !defined(AFX_UZC_VRSHAPE_H__23E2F3F7_6EDC_4C7A_9ED7_9209ED19F06A__INCLUDED_)
