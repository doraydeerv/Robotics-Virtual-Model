 // Physic_VRShape.cpp: implementation of the Physic_VRShape class.
//
//////////////////////////////////////////////////////////////////////


#include "Physic_VRShape.h"
#include "MeshActor.h"

#include "NxPhysics.h"
#include "CommonCode.h"


#include <string.h>
#include <stdio.h>
//#include <fstream.h>
#include <stdlib.h>
#include <math.h>

#include <GL\gl.h>
#include <GL\glu.h>


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Physic_VRShape::Physic_VRShape(int elems, int padre, float a,float b, float c, float d, float e, float f, float g, float h, float i, float j, float k, float l, float peso)
{
	figuras=elems;
	setTransformH( a, b, c, d,   e, f, g, h,   i, j, k, l);
	PESO=peso;
}
void Physic_VRShape::crearsegmento(NxScene* gscene)
{
		
	shapes[0]->setlocalpose(Id,shapes[0]->H);
	shapes[0]->setTransT(Ti, shapes[0]->H);
		(Id,shapes[0]->H);
	for (int j=1;j<=figuras;j++)
	{
		shapes[j]->setlocalpose(shapes[shapes[j]->padre]->localpose,shapes[j]->H);
		shapes[j]->setTransT(shapes[shapes[j]->padre]->Ti,shapes[j]->H);
	}
	//NxBodyDesc BodyDesc;
	BodyDesc.angularDamping	= 0.05f;
	BodyDesc.maxAngularVelocity	= 1.0f;
	BodyDesc.mass = PESO;
	for(int i=0;i<=figuras;i++)
	{
		shapes[i]->bunnyShapeDesc.localPose= shapes[i]->localpose;
		ActorDesc.shapes.pushBack(&shapes[i]->bunnyShapeDesc);			
	}	
		
	
	ActorDesc.body			= &BodyDesc;
	ActorDesc.density		= 0;

		
	ActorDesc.globalPose.t  = NxVec3(0,450,0);
	bool check = ActorDesc.isValid();
	actor= gscene->createActor(ActorDesc);
	getActor()->setGlobalPose(Ti);
	
	

}


/*Physic_VRShape::Physic_VRShape( char *filename, NxScene* gScene, NxPhysicsSDK *gPhysicsSDK) //convex
{
	strcpy(OGL_FILENAME,filename);
	strcpy(PHYSX_FILENAME,filename);
	shape=new MeshActor( OGL_FILENAME,NxVec3(0,0,0),1, gScene, gPhysicsSDK);
	initial_transformation();
}*/


Physic_VRShape::~Physic_VRShape()
{

}

void Physic_VRShape::initial_transformation(){
    actor->setGlobalPosition(NxVec3(0,0,0));
    actor->setGlobalOrientationQuat(NxQuat(0,NxVec3(0,1,0)));
//	com=actor->getCMassGlobalPosition();
}

void Physic_VRShape::translation(NxVec3 T){
    actor->setGlobalPosition(T);
}

void Physic_VRShape::translation(NxReal x,NxReal y,NxReal z){
    actor->setGlobalPosition(NxVec3(x,y,z));
}

void Physic_VRShape::rotAxis(float angle, float x, float y, float z){
	if (angle==0) return;
	if ((x==0) && (y==0) && (x==0)) y=0.0001;
	NxQuat Q(angle, NxVec3(x,y,z));
    actor->setGlobalOrientationQuat(Q);
}

void Physic_VRShape::rotAxis(Vector4D r){

	if (r[0]==0) return;
	if ((r.x==0) && (r.y==0) && (r.x==0)) r.y =0.0001;

	NxQuat Q(r[0], NxVec3(r[1],r[2],r[3]));
    actor->setGlobalOrientationQuat(Q);
}

void Physic_VRShape::rotQuat(NxQuat q){
    actor->setGlobalOrientationQuat(q);
}

void Physic_VRShape::getTransformAx(NxVec3 *t, Vector4D *rot){
    *t=actor->getGlobalPosition();
    NxQuat q=actor->getGlobalOrientationQuat();
	NxVec3 axis;
	NxReal angle;
	q.getAngleAxis(angle, axis);
	rot-> a=angle;
	rot-> x=axis[0];
	rot-> y=axis[1];
	rot-> z=axis[2];

}

void Physic_VRShape::getTransformAx(float t[3], Vector4D *rot){
    NxVec3 p=actor->getGlobalPosition();
	t[0]=p[0];
	t[1]=p[1];
	t[2]=p[2];
	NxVec3 axis;
	NxReal angle;
    NxQuat q=actor->getGlobalOrientationQuat();
	q.getAngleAxis(angle, axis);
	rot-> a=angle;
	rot-> x=axis[0];
	rot-> y=axis[1];
	rot-> z=axis[2];

}

void Physic_VRShape::getTransform(NxVec3 *t, NxQuat *q){
    *t=actor->getGlobalPosition();
    *q=actor->getGlobalOrientationQuat();
}

void Physic_VRShape::setTransform(NxVec3 T, NxQuat Q)
{
	NxMat34 M(NxMat33(Q),T);
	actor->setGlobalPose(M);
}
void Physic_VRShape::setCOMglobal(NxVec3 comglobal)
{
	
	actor->setCMassOffsetGlobalPosition(comglobal);
	//actor->raiseActorFlag(NX_AF_LOCK_COM);
}
void  Physic_VRShape::setPMInertia(NxVec3 pminertia)
{
      actor->setMassSpaceInertiaTensor(pminertia);
}
void        Physic_VRShape::setCOMpose(NxMat34 compose)
{
      actor->setCMassOffsetGlobalPose(compose);
}


void Physic_VRShape::setTransformH(float a, float b, float c,float d, float e, float f,float g, float h, float i,float j, float k, float l )
{
	NxMat33 r(NxVec3(a,b,c),NxVec3(e,f,g),NxVec3(i,j,k));  
	NxVec3  t(NxVec3(d,h,l));
	//NxMat34 hl;
	H.M =r;
	H.t= t;
	
	/*NxMat34 Prem1;
	NxMat34 Prem2;
	NxMat34 RZ270(NxMat33(NxVec3(0,1,0),NxVec3(-1,0,0),NxVec3(0,0,1)), NxVec3(0,0,0));
	NxMat34 RX90(NxMat33(NxVec3(1,0,0),NxVec3(0,0,-1),NxVec3(0,1,0)),NxVec3(0,0,0));
	Prem1.multiply(RZ270,RX90);
	Prem2.multiply(hl,Prem1);
	H=Prem2;*/
}
	
void Physic_VRShape::setTransformT(NxMat34 Tant,NxMat34 H)
{

 Ti.multiply (Tant,H);


}
void Physic_VRShape::getQuaternion(NxQuat *q){
    *q=actor->getGlobalOrientationQuat();
}

NxVec3 Physic_VRShape::getCMass(){
    NxVec3 p=actor->getCMassGlobalPosition();
	return p;
}

//NxVec3 Physic_VRShape::getCMassLocal(){
//	return com;
//}


///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape Render function
///////////////////////////////////////////////////////////////////////////////

void Physic_VRShape::render()
{
	NxShape*const *FIGURAS= actor->getShapes();
	NxMat34 pose;
	float glmat[16];
	for (int i=0;i<=figuras;i++)
	{
		pose= FIGURAS[i]->getGlobalPose();
		pose.M.getColumnMajorStride4(&(glmat[0]));
		pose.t.get(&(glmat[12]));
		glmat[3] = glmat[7] = glmat[11] = 0.0f; glmat[15] = 1.0f;
		glPushMatrix();
		glMultMatrixf(glmat);
		shapes[i]->RenderBunny();
		glPopMatrix();
	}

	
}


///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape Render TRIMESH function
///////////////////////////////////////////////////////////////////////////////

void Physic_VRShape::renderMesh()
{

}

///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape getting object identificator function
///////////////////////////////////////////////////////////////////////////////

int Physic_VRShape::getID(){return OBJECT_ID;}

///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape getting number of vertices function
///////////////////////////////////////////////////////////////////////////////

/*int Physic_VRShape::getVertices(){
	return BUNNY_NBVERTICES ;
	//return number_of_vertices;
}

float Physic_VRShape::getVertexCoord(int vi, int j){
//	return vertices[vi][j];
	return gBunnyVertices [vi*3+j];

}

int Physic_VRShape::getFaces(){
	return BUNNY_NBFACES ;
	//return number_of_faces;
}
int Physic_VRShape::getFaceIndex(int i, int j){
	//return face_indicies[i][j];
	return gBunnyTriangles [i*3+j];
}
*/
///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape raiseBodyFlag(NX_BF_KINEMATIC)
///////////////////////////////////////////////////////////////////////////////

void Physic_VRShape::fixShape()
{
	while 	(!actor->readBodyFlag(NX_BF_KINEMATIC))
		actor->raiseBodyFlag(NX_BF_KINEMATIC);
}

///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape clearBodyFlag(NX_BF_KINEMATIC)
///////////////////////////////////////////////////////////////////////////////

void Physic_VRShape::releaseShape()
{
	while 	(actor->readBodyFlag(NX_BF_KINEMATIC))
		actor->clearBodyFlag(NX_BF_KINEMATIC);
}

///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape clearBodyFlag(NX_BF_DISABLE_GRAVITY)
///////////////////////////////////////////////////////////////////////////////

void Physic_VRShape::setGravity()
{
	while 	(actor->readBodyFlag(NX_BF_DISABLE_GRAVITY))
		actor->clearBodyFlag(NX_BF_DISABLE_GRAVITY);
}

///////////////////////////////////////////////////////////////////////////////
// Physic_VRShape raiseBodyFlag(NX_BF_DISABLE_GRAVITY)
///////////////////////////////////////////////////////////////////////////////

void Physic_VRShape::removeGravity()
{
	while 	(!actor->readBodyFlag(NX_BF_DISABLE_GRAVITY))
		actor->raiseBodyFlag(NX_BF_DISABLE_GRAVITY);
}
NxActor *Physic_VRShape::getActor()
{
	return actor ;
}
NxMat34 Physic_VRShape::getEndTi()
{
	NxMat34 EndTi=shapes[figuras]->Ti;

return EndTi;
}