// Vector4D.h: interface for the Vector4D class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_VECTOR4D_H_)
#define _VECTOR4D_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Vector4D  
{
public:
	float a;									// the a value of this Vector4D
	float x;									// the x value of this Vector4D
	float y;									// the y value of this Vector4D
	float z;									// the z value of this Vector4D

	Vector4D();									// Constructor to set a = x = y = z = 0
	Vector4D(float a, float x, float y, float z);			// Constructor that initializes this Vector4D 
	Vector4D(float a[4]);
	float Vector4D::operator[] (int v);			
	virtual ~Vector4D();

};

#endif 

