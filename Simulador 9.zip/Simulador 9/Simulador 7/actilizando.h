void actualiza()
{

/************************Brazo Derecho**************************************/
	    RotZ(ang_rad[1]);
		ROT.multiply(SegmentoC[1]->H,ROT);
		SegmentoC[1]->setTransformT(SegmentoC[0]->shapes[22]->Ti, ROT);
		
		
		
	
		RotZ(ang_rad[3]);
		ROT.multiply(ROT,SegmentoC[3]->H);
		SegmentoC[3]->setTransformT(SegmentoC[1]->shapes[1]->Ti, ROT);
		
		
	
	
		RotZ(ang_rad[5]);
		ROT.multiply(ROT,SegmentoC[5]->H);
		SegmentoC[5]->setTransformT(SegmentoC[3]->shapes[3]->Ti, ROT);
		
		
		
/****************************Brazo Izquierdo*********************************/

		RotZ(ang_rad[2]);
		ROT.multiply(ROT,SegmentoC[2]->H);
		SegmentoC[2]->setTransformT(SegmentoC[0]->shapes[23]->Ti, ROT);
		
		
		
		
	
		RotZ(ang_rad[4]);
		ROT.multiply(ROT,SegmentoC[4]->H);
		SegmentoC[4]->setTransformT(SegmentoC[2]->shapes[1]->Ti, ROT);
		
		
		
		
	
		RotZ(ang_rad[6]);
		ROT.multiply(ROT,SegmentoC[6]->H);
		SegmentoC[6]->setTransformT(SegmentoC[4]->shapes[3]->Ti, ROT);
		
		
/****************************************Pierna Derecha*************************************/


		RotZ(ang_rad[7]);
		ROT.multiply(ROT,SegmentoC[7]->H);
		SegmentoC[7]->setTransformT(SegmentoC[0]->shapes[24]->Ti, ROT);
		
		
	
	
	
		RotX(ang_rad[9]);
		ROT.multiply(ROT,SegmentoC[9]->H);	
		SegmentoC[9]->setTransformT(SegmentoC[7]->shapes[1]->Ti, ROT);
		
	
	
	
		RotZ(ang_rad[11]);
		ROT.multiply(ROT,SegmentoC[11]->H);	
		SegmentoC[11]->setTransformT(SegmentoC[9]->shapes[5]->Ti, ROT);
		
		
	
		RotZ(ang_rad[13]);
		ROT.multiply(ROT,SegmentoC[13]->H);
		SegmentoC[13]->setTransformT(SegmentoC[11]->shapes[2]->Ti, ROT);
		
		
		
		

		RotZ(ang_rad[15]);
		ROT.multiply(ROT,SegmentoC[15]->H);
		SegmentoC[15]->setTransformT(SegmentoC[13]->shapes[4]->Ti, ROT);
		
		
		
	
		RotZ(ang_rad[17]);
		ROT.multiply(ROT,SegmentoC[17]->H);
		SegmentoC[17]->setTransformT(SegmentoC[15]->shapes[5]->Ti, ROT);
		
/****************************************Pierna Izquierda*************************************/
	
		RotZ(ang_rad[8]);
		ROT.multiply(ROT,SegmentoC[8]->H);
		SegmentoC[8]->setTransformT(SegmentoC[0]->shapes[25]->Ti, ROT);
		
		
		RotX(ang_rad[10]);
		ROT.multiply(ROT,SegmentoC[10]->H);	
		SegmentoC[10]->setTransformT(SegmentoC[8]->shapes[1]->Ti, ROT);
		
		RotZ(ang_rad[12]);
		ROT.multiply(ROT,SegmentoC[12]->H);	
		SegmentoC[12]->setTransformT(SegmentoC[10]->shapes[5]->Ti,ROT);
		
		
	
		RotZ(ang_rad[14]);
		ROT.multiply(ROT,SegmentoC[14]->H);
		SegmentoC[14]->setTransformT(SegmentoC[12]->shapes[2]->Ti,ROT);
			

	
		RotZ(ang_rad[16]);
		ROT.multiply(ROT,SegmentoC[16]->H);
		SegmentoC[16]->setTransformT(SegmentoC[14]->shapes[4]->Ti, ROT);
		
		
	
		RotZ(ang_rad[18]);
		ROT.multiply(ROT,SegmentoC[18]->H);
		SegmentoC[18]->setTransformT(SegmentoC[16]->shapes[5]->Ti, ROT);
		
		

}