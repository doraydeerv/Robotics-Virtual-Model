/*Funciones de Glut  */
#include<gl\glut.h>  //Libreria de Gr�ficos
#include "CommonCode2.h"
#include "actualizando.h"
#include "BorsteIndugula.h"
#include "zerom.h"

static int dispListSphere;

extern float var_brazo;
bool FUERZA=0;
NxVec3 VectorT;
NxVec3 Vector;
float anglex=0, angley=0, anglez=0;
int lookfrom=450;
int last_x = 0, last_y = 0,left = 1,middle = 0,right = 0;
int zoom_y = 0;
int S=2;
int t=-5;
int dir;
int izq;
int der;
extern float POSOR[4];
NxMat33 poseCM;
extern NxVec3 posicionCM;
extern NxVec3 posicionZMP;
extern float set_ang[19];
NxReal  radio;
extern NxReal offsetc;
int ScreenWidth  = 1000;
int	ScreenHeight = 1000; 
#define MAX_KEYSm 256
bool gKeysm[MAX_KEYSm];
/*******************************/
// Physics SDK globals
extern NxPhysicsSDK*     gPhysicsSDK;
extern NxScene*          gScene;
extern NxScene*          gScene2;
extern NxVec3            gDefaultGravity;
extern NxVec3            PelvisP;
extern float pi;
extern float ang_rad[19];
extern float frame[517][25];
extern int framest;
extern float Roll, Pitch, Yaw;
extern DebugRenderer     gDebugRenderer;
extern UserAllocator*	  gAllocator;


// Camera globals
extern NxVec3 gCameraPos;

// Force globals
extern NxVec3 gForceVec;
extern NxReal gForceStrength;
extern bool bForceMode;

// Simulation globals
extern bool bPause;
extern bool bShadows;
extern bool bfixedMode;
extern bool datosmecanicosf;
extern bool bDebugWireframeMode;
extern Physic_VRShape *Segmento[19]; 
extern Physic_VRShape  *SegmentoC[19];
extern NxRevoluteJoint*   revJoints[19];
bool cinematico=0;
bool dinamico=1;
// Actor globals
extern  NxActor* groundPlane;
extern NxActor* gSelectedActor;
extern Physic_VRShape *Segmento[19];
extern NxActor* Pelvis;
extern NxShape*  CMT;
extern NxActor*  Esfera2;
int actualizar;
extern FILE *f;
extern FILE *j;
void datosmecanicos()
{
// GUARDADO EN DatosBioloid.txt
	FILE *f;
	f=fopen("DatosBioloid.txt","wt");
	fputs ("Datos Bioloid \n", f);
	
	fputs ("\nMasas \n",f);
	for (int z=0;z<=18;z++)
		fprintf (f, "La masa del segmento %d es: %.6f  \n",z, Segmento[z]->actor->getMass());	

	fputs ("\nPosici�n Global \n",f);
	float PG[16];
	for (int z=0;z<=18;z++)
		{
		    Segmento[z]->actor->getGlobalPose().getRowMajor44(PG);
			fprintf (f, "La Posici�n Global  del segmento %d es:\n %.3f, %.3f, %.3f, %.3f \n %.3f, %.3f, %.3f, %.3f\n  %.3f, %.3f, %.3f, %.3f\n",z, 
			    
				PG[0],PG[1],PG[2],PG[3],
				PG[4],PG[5],PG[6],PG[7],
				PG[8],PG[9],PG[10],PG[11]);

		}
	
	fputs ("\nCentros de Masas Globales \n",f);
	for (int z=0;z<=18;z++)	
		fprintf (f, "El centro de masa global del segmento %d es: %.2f, %.2f, %.2f \n", z, Segmento[z]->actor->getCMassGlobalPosition().x, Segmento[z]->actor->getCMassGlobalPosition().y, Segmento[z]->actor->getCMassGlobalPosition().z);
	
	fputs ("\nCentros de Masas con respecto a la Pelvis marco matlab (mm)\n",f);
	for (int z=0;z<=18;z++)	
		fprintf (f, "El centro de masa global del segmento %d es: %.2f, %.2f, %.2f \n", z, Segmento[z]->actor->getCMassGlobalPosition().z - PelvisP.z,Segmento[z]->actor->getCMassGlobalPosition().x - PelvisP.x,Segmento[z]->actor->getCMassGlobalPosition().y- PelvisP.y); 
	
	fputs ("\nTensor de Inercia Global (g/mm2) \n",f);
	float TI[10];
	for (int z=0;z<=18;z++)
	{
		Segmento[z]->actor->getGlobalInertiaTensor().getColumnMajor(TI);
			fprintf (f, "El tensor de Inercial global  del segmento %d es: \n %.2f, %.2f, %.2f \n %.2f, %.2f, %.2f\n  %.2f, %.2f, %.2f\n",z, 
				TI[0],TI[1],TI[2],
				TI[3],TI[4],TI[5],
				TI[6],TI[7],TI[8]);

	}

	fclose(f);
}
void LecturaDinamica()
	{
	//FILE *f;
	//f=fopen("PosicionesDinamico.txt","wt");
	fprintf (f, "%\d \t ", S-1);
	for (int z=1; z<=4;z++)
		fprintf (f, "% .02f \t ", revJoints[z]->getAngle());
	for (int z=7; z<=18;z++)
		fprintf (f, "% .02f \t  ", revJoints[z]->getAngle());
	NxVec3 Torsopos=  Segmento[0]->actor->getGlobalPosition();
	fprintf(f, "%.02f \t %.02f \t %.02f \t ", Torsopos.x, Torsopos.y, Torsopos.z);
	NxQuat Torsoori;
	Torsoori = Segmento[0]->actor->getGlobalOrientationQuat();
	
	NxReal Angle;
	NxVec3 Axis;
	Torsoori.getAngleAxis(Angle, Axis);
	NxVec3 Torso_Ori = Angle * Axis;
	fprintf(f, "%.02f \t %.02f \t %.02f \t ", Torso_Ori.x, Torso_Ori.y, Torso_Ori.z);
	fprintf(f, "\n"); 
}
void LecturaCinematica()
	{
	//FILE *f;
	//f=fopen("PosicionesDinamico.txt","wt");

	fprintf (j, "%\d \t ", S-1);
	for (int z=1; z<=18;z++)
	{
		fprintf (j, "%.02f \t", set_ang[z]);
	}
	
	NxVec3 Torsopos=  SegmentoC[0]->actor->getGlobalPosition();
	fprintf(j, "%.02f \t %.02f \t %.02f \t ", Torsopos.x, Torsopos.y, Torsopos.z);
	NxQuat Torsoori;
	Torsoori = SegmentoC[0]->actor->getGlobalOrientationQuat();
	
	NxReal Angle;
	NxVec3 Axis;
	Torsoori.getAngleAxis(Angle, Axis);
	NxVec3 Torso_Ori = Angle * Axis;
	fprintf(j, "%.02f \t %.02f \t %.02f \t ", Torso_Ori.x, Torso_Ori.y, Torso_Ori.z);
	fprintf(j, "\n"); 
}

void InitNx()
{
	// Create a memory allocator
    gAllocator = new UserAllocator;

    // Create the physics SDK
    gPhysicsSDK = NxCreatePhysicsSDK(NX_PHYSICS_SDK_VERSION, gAllocator);

	// Set the physics parameters
	gPhysicsSDK->setParameter(NX_MIN_SEPARATION_FOR_PENALTY, -1);
	
	gPhysicsSDK->setParameter(NX_DYN_FRICT_SCALING,200); 
	gPhysicsSDK->setParameter(NX_STA_FRICT_SCALING,200); 
	// Set the debug visualization parameters
	gPhysicsSDK->setParameter(NX_VISUALIZATION_SCALE, 1);
	//gPhysicsSDK->setParameter(NX_VISUALIZE_COLLISION_SHAPES, 1);
	gPhysicsSDK->setParameter(NX_VISUALIZE_WORLD_AXES,100); 
	//gPhysicsSDK->setParameter(NX_VISUALIZE_ACTOR_AXES, 50);
	//gPhysicsSDK->setParameter( NX_VISUALIZE_BODY_AXES, 1);
	gPhysicsSDK->setParameter(NX_VISUALIZE_BODY_MASS_AXES,1);
	//gPhysicsSDK->setParameter(NX_VISUALIZE_BODY_REDUCED,1);
	//gPhysicsSDK->setParameter(NX_VISUALIZE_COLLISION_FNORMALS, 1);
	//gPhysicsSDK->setParameter(NX_VISUALIZE_BODY_JOINT_GROUPS,2);
	//gPhysicsSDK->setParameter(NX_VISUALIZE_BODY_JOINT_LIST,1); 
	//gPhysicsSDK->setParameter(NX_VISUALIZE_JOINT_LOCAL_AXES,1); 
	//gPhysicsSDK->setParameter(NX_VISUALIZE_JOINT_WORLD_AXES,20); 
	
	
    // Create the scene
    NxSceneDesc sceneDesc;
    sceneDesc.gravity               = gDefaultGravity;
    sceneDesc.broadPhase            = NX_BROADPHASE_COHERENT;
    sceneDesc.collisionDetection    = true;

	gScene = gPhysicsSDK->createScene(sceneDesc);
	gScene2 = gPhysicsSDK->createScene(sceneDesc);

	// Create the default material
	NxMaterial* defaultMaterial ;
	defaultMaterial = gScene->getMaterialFromIndex(0); 
	defaultMaterial->setRestitution(0);
	defaultMaterial->setStaticFriction(0.5);
	defaultMaterial->setDynamicFriction(0.5);

	// Create the objects in the scene
	groundPlane = CreateGroundPlane();
	DrawActor(groundPlane);

	UpdateTime();
	if (gScene)  
		StartPhysics();
}



void RenderActors(bool shadows)
{
    // Render all the actors in the scene
    DrawActor(groundPlane);
	DrawActor(Pelvis);
	
	if(dinamico==1)
		for (int zz=0;zz<=18;zz++)
			if ( Segmento[zz] != NULL )
				{Segmento[zz]->render();} 
		
	if (cinematico==1)

	{
		for (int zz=0;zz<=18;zz++)
		if ( SegmentoC[zz] != NULL )
			{
				for (int xx=0;xx<=SegmentoC[zz]->figuras;xx++)
					SegmentoC[zz]->shapes[xx]->color=NxVec3(0.9,0.9,0.9);
			SegmentoC[zz]->render();
			}
		}
	/********************/
		// SPHERE DISPLAY LIST
	dispListSphere = glGenLists(1);
	glNewList(dispListSphere, GL_COMPILE);      
	GLUquadricObj * quadObj = gluNewQuadric ();
	gluQuadricDrawStyle (quadObj, GLU_FILL);
	gluQuadricNormals (quadObj, GLU_SMOOTH); 
	gluQuadricOrientation(quadObj,GLU_OUTSIDE);
	gluSphere (quadObj, 1.0f, 9, 7);	//unit sphere
	glEndList();
	gluDeleteQuadric(quadObj);
	/***********************/
	glPushMatrix();
	poseCM=NxMat33(NxVec3(1,0,0),NxVec3(0,1,0),NxVec3(0,0,1));
	SetupGLMatrix(posicionCM, poseCM);
	radio=3;
	glScaled(radio,radio,radio);
	glCallList(dispListSphere);
	glPopMatrix();
	/********************/
	/***********************/
	glPushMatrix();
	poseCM=NxMat33(NxVec3(1,0,0),NxVec3(0,1,0),NxVec3(0,0,1));
	SetupGLMatrix(posicionZMP, poseCM);
	radio=3;
	glScaled(radio,radio,radio);
	glCallList(dispListSphere);
	glPopMatrix();
	/********************/

	/*NxVec3 P0,P1, incremento;		
	for (int s=0;s<=18;s++)
		if ( revJoints[s]!= NULL )
				{
				P0 = revJoints[s]->getGlobalAnchor();
				incremento.multiply (100, revJoints[s]->getGlobalAxis());
				P1=P0+incremento;
				DrawLine(P0, P1, NxVec3(1,1,0));
				//(revJoints[s][t]->getGlobalAnchor() + NxVec3(20,0,0))
				} */
	/*Pendiente Verificar Sombras*/
     /*  if (shadows)
           for (int t=0;t<=18;t++)
				DrawActorShadow(Segmento[t]->actor);
			  
	 */
    

}

void RenderCallback()
{
	//Calcular ZMP
    // Clear buffers
	/*************************************************************************/
	Roll=frame[S][22]* pi/180;
	Pitch=frame[S][23]* pi/180;
	Yaw=frame[S][24]* pi/180;
	ang_rad[1]= -pi/4+(frame[S][1]* pi/180); 
	ang_rad[2]= -pi/4+(frame[S][2]* pi/180);
	ang_rad[3]= 3*pi/8+(frame[S][3]*pi/180); 
	ang_rad[4]= -3*pi/8+(frame[S][4]*pi/180);
	
	
	/*ang_rad[1]= (t* pi/180); 
	ang_rad[2]= (t* pi/180);
	ang_rad[3]= 3*pi/8+((frame[S][3]+izq)*pi/180); 
	ang_rad[4]= -3*pi/8+((frame[S][4]+der)*pi/180);
	
	if ((dir==0) & (izq!=-80))
		izq-=1;
	if (izq==-80)
		dir=1;
	if ((dir==1) & (izq!=0))
		izq+=1;
	if ((izq==0) & (dir ==1))
		dir=2;

	if ((dir==2) & (der!=50))
		der+=1;
	if (der==50)
		dir=3;
	if ((dir==3) & (der!=0))
		der-=1;
	if ((der==0) & (dir ==3))
		dir=4;

	if ((t!=-190) & (dir ==4))
		t-=1;		
	if (t==-190)
		dir=5;
	if ((t!=-5) & (dir ==5))
		t+=1;
	if ((t==-5) & (dir ==5))
		dir=0;*/
	ang_rad[7]= -(frame[S][7]*pi/180) ;  
	ang_rad[8]= -(frame[S][8]*pi/180) ; 

	ang_rad[9]= 0;//+ (-20- frame[S][9]*pi/180) ;  actualiza(9);
	ang_rad[10]= 0;// +(20- frame[S][10]*pi/180) ;  actualiza(10);

	ang_rad[11]= (frame[S][11]*pi/180) ;  
	ang_rad[12]= (frame[S][12]*pi/180) ;  

	ang_rad[13]=  -(frame[S][13]*pi/180) ;  
	ang_rad[14]=  -(frame[S][14]*pi/180) ;  

	ang_rad[15]= (frame[S][15]*pi/180) ;  
	ang_rad[16]= (frame[S][16]*pi/180) ;  

	ang_rad[17]= 0;// + (frame[S][17]*pi/180) ;  actualiza(17);;
	ang_rad[18]= 0;// - (frame[S][18]*pi/180) ;  actualiza(18);*/
		
	//ang_rad[1]=(var_brazo*pi/180);
	POSOR[1]=frame[S][19];
	POSOR[2]=frame[S][20]+offsetc;
	POSOR[3]=frame[S][21]; 

	//POSOR[1]=frame[2][19];
	//POSOR[2]=frame[2][20]+offsetc;
	//POSOR[3]=frame[2][21];
	actualiza();
	BorstIndugula();
	calcularzmp();
	LecturaDinamica();
	LecturaCinematica();
	printf ("\n frame %d ", S);
	
	if (S==framest)
		{//S=2;
		exit(0);
		//actualizar=actualizar;//+73.6;
		}
	S++;
	/*************************************************************************/
	
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	ProcessCameraKeys();
	SetupCamera();
	
	if (gScene && datosmecanicosf)
	{
		datosmecanicos();
		datosmecanicosf=0;

	}

	if (gScene && FUERZA)
	{
		if (gSelectedActor == Segmento[0]->actor)
			gSelectedActor->addForce(NxVec3(0,50000000,0)); 
		else
			ApplyForceToActor(gSelectedActor,  VectorT, 15000, false);
		FUERZA=0;
	}
		
    if (gScene && !bPause)
	{
		GetPhysicsResults();
		//while (!gScene2->fetchResults(NX_RIGID_BODY_FINISHED, true));
        ProcessInputs();
		//gDebugRenderer.renderData(*gScene2->getDebugRenderable());
		StartPhysics();
		//NxReal deltaTime = UpdateTime();
		//gScene2->simulate(deltaTime);
		//gScene2->flushStream();
	}
	
	if (gScene && !bfixedMode)
	{
		gSelectedActor->clearBodyFlag(NX_BF_KINEMATIC);
		bfixedMode=true;
	}
	
	
		// Display scene
 	RenderActors(bShadows);
	
	if (bForceMode && FUERZA)
		DrawForce(Segmento[1]->actor, NxVec3(0,1,0), NxVec3(1,1,0));
	else if (!bForceMode && FUERZA)
		DrawForce(gSelectedActor, VectorT, NxVec3(1,1,1));
	//gForceVec = NxVec3(0,1000,0);

    glFlush();
    glutSwapBuffers();
}


void ProcessInputs()
{
   // ProcessForceKeys();

    // Show debug wireframes
	if (bDebugWireframeMode)
	{
		if (gScene) 
			gDebugRenderer.renderData(*gScene->getDebugRenderable());
	}
}

void KeyboardUpCallback(unsigned char key, int x, int y)
{
	#define MAX_KEYS 256
	extern bool gKeys[MAX_KEYS];
	gKeys[key] = false;

	switch (key)
	{
		case 'p': { bPause = !bPause; UpdateTime(); break; }
		case 'x': { bShadows = !bShadows; break; }
		case 'b': { bDebugWireframeMode = !bDebugWireframeMode; break; }		
		
		case 'T': { bForceMode = false; break; }
		
		//case 'S': { ResetNx();Segmentos();glutMainLoop(); }
		case 'R': { bfixedMode = false; break; }

		case '+': { FUERZA=1; VectorT=Vector;  break; }
		case '-': { FUERZA=1; VectorT=-Vector; break; }
		case '#': { datosmecanicosf= true; break; }
	    case '0': { gSelectedActor=Segmento[0]->actor;  Vector= NxVec3(0,0,1);	break;}
		case '1': { gSelectedActor=Segmento[1]->actor;  Vector= NxVec3(0,0,1);	break;}
		case '2': { gSelectedActor=Segmento[2]->actor;  Vector= NxVec3(0,0,1);	break;}
		case '3': { gSelectedActor=Segmento[3]->actor;  Vector=NxVec3(0,0,1);	break;}
		case '4': { gSelectedActor=Segmento[4]->actor;  Vector=NxVec3(0,0,1);	break;}
		case '5': { gSelectedActor=Segmento[5]->actor;  Vector=NxVec3(0,0,1);   break;}
        case '6': { gSelectedActor=Segmento[6]->actor;  Vector=NxVec3(0,0,1);	break;}
		case '7': { gSelectedActor=Segmento[7]->actor;  Vector=NxVec3(0,0,1);   break;}
		case '8': { gSelectedActor=Segmento[8]->actor;  Vector=NxVec3(0,0,1);	break;}
		case '9': { gSelectedActor=Segmento[9]->actor;  Vector=NxVec3(0,0,1);	break;}
		case 'A': { gSelectedActor=Segmento[10]->actor; Vector=NxVec3(0,0,1);	break;}
		case 'B': { gSelectedActor=Segmento[11]->actor; Vector=NxVec3(1,0,0);  break;}
        case 'C': { gSelectedActor=Segmento[12]->actor; Vector=NxVec3(1,0,0);	break;}
		case 'D': { gSelectedActor=Segmento[13]->actor; Vector=NxVec3(0,0,1);	break;}
		case 'E': { gSelectedActor=Segmento[14]->actor; Vector=NxVec3(0,0,1);	break;}
		case 'F': { gSelectedActor=Segmento[15]->actor; Vector=NxVec3(0,0,1);	break;}
		case 'G': { gSelectedActor=Segmento[16]->actor; Vector=NxVec3(0,0,1);	break;}
		case 'H': { gSelectedActor=Segmento[17]->actor; Vector=NxVec3(0,1,0);	break;}
		case 'I': { gSelectedActor=Segmento[18]->actor; Vector=NxVec3(0,1,0);  break;}
       
		case 'c': { cinematico=!cinematico;  break;}
		case 'f': { dinamico=!dinamico;  break;}
		case 'm': { var_brazo++;  printf("%2.4f\n",var_brazo); break;}
		case 'n': { var_brazo--;  break;}
		case '/': { ang_rad[3]=(0*pi/180); ang_rad[4]=(0*pi/180);  break;}
		case '*': {ang_rad[3]=(-89*pi/180); ang_rad[4]=(90*pi/180);  break;}
		case 27 : { exit(0); break; }
		default : { break; }
	}
}












