#include "Physic_VRSHAPE.h"
extern Physic_VRShape *Segmento[19];
extern Physic_VRShape *SegmentoC[19];
extern NxVec3 PCtmenos1[19];
extern NxVec3 PDtmenos1[19];

extern NxQuat qdtmenos1[19];
extern NxQuat qctmenos1[19];
extern float ang_rad[19];
extern float frame[517][25];
//extern NxQuat qdtmenos1[19];
//extern NxQuat qctmenos1[19];

extern NxRevoluteJoint*   revJoints[19];
extern float pi;
extern float set_ang[19];
void ResorteL( int numactor, float kL, float bL);
void ResorteTL( NxActor* ActorC, NxVec3 PosicionC,NxQuat qc, NxActor* ActorD,NxVec3 PosicionD, NxQuat dq, float kTL, float bTL,float kTT, float bTT);
void ResorteT(float kT,float bT);
void ResorteT( int numactor, NxVec3 Eje,float kT,float bT);
void updateSpring(int numactor, NxVec3 Eje);
void BorstIndugula();