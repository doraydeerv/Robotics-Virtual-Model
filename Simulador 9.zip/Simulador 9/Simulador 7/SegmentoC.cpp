#include <stdio.h>
#include "NxPhysics.h"
#include <math.h>
#include "Torso.h"
#include "BrazoIzquierdo.h"
#include "BrazoDerecho.h"
#include "PiernaIzquierda.h"
#include "PiernaDerecha.h"

NxMat34 Idc;
NxMat34 ROT;
extern float ang_rad[19];
extern float pi;
extern float frame[517][25];
extern NxPhysicsSDK*     gPhysicsSDK;
extern NxScene*          gScene2;
extern NxVec3            gDefaultGravity;
extern Physic_VRShape  *SegmentoC[19];
extern float Roll, Pitch, Yaw;
extern NxMat33 Rot[18];
extern NxVec3 PelvisP;
extern NxReal offsetc;
void RotX(float angulo)
{
	NxMat34 rotX;
	rotX.M= NxMat33(NxVec3(1,0,0),NxVec3(0,cos(angulo),-sin(angulo)),NxVec3(0,sin(angulo),cos(angulo)));
	rotX.t=NxVec3(0,0,0);
	ROT=rotX;
}
void RotY(float angulo)
{
	NxMat34 rotY;
	rotY.M= NxMat33(NxVec3(cos(angulo),0,sin(angulo)),NxVec3(0,1,0),NxVec3(-sin(angulo),0,cos(angulo)));
	rotY.t=NxVec3(0,0,0);
	ROT=rotY;
}
void RotZ(float angulo)
{
	NxMat34 rotZ;
	rotZ.M= NxMat33(NxVec3(cos(angulo),-sin(angulo),0),NxVec3(sin(angulo),cos(angulo),0),NxVec3(0,0,1));
	rotZ.t=NxVec3(0,0,0);
	ROT=rotZ;
}



void SegmentosCin()
{	

SegmentoC[0]=new Physic_VRShape(25,   0,   1,0,0,frame[2][19],   0,1,0,frame[2][20]+offsetc,   0,0,1,frame[2][21], 553 ); 
		RotX(Pitch);
		NxMat34 RotPitch=ROT; 
		RotY(Roll);
		NxMat34 RotRoll=ROT;
		RotZ(Yaw);
		NxMat34 RotYaw=ROT;
		NxMat34 temp;
		temp.multiply(RotRoll, RotPitch);
		temp.multiply(RotYaw,temp);
		SegmentoC[0]->setTransformT(SegmentoC[0]->H,temp);
		declarar_Torso(SegmentoC[0],  gScene2);
		SegmentoC[0]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[0]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[0],(PelvisP + NxVec3(0,58,-7))));
		
		
/************************Brazo Derecho**************************************/
	SegmentoC[1]=new Physic_VRShape(1,   0,  0,-1, 0, 9,  1,0, 0, 0,  0, 0, 1, 17,  11.38 );
	    RotZ(ang_rad[1]);
		ROT.multiply(SegmentoC[1]->H,ROT);
		SegmentoC[1]->setTransformT(SegmentoC[0]->shapes[22]->Ti, ROT);
		declarar_HD1(SegmentoC[1], gScene2);
		SegmentoC[1]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[1],(PelvisP + NxVec3(-60.6,89.63,4.63))));
		SegmentoC[1]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[1]->padre=0;
		
	SegmentoC[3]=new Physic_VRShape(3,   1,   1,0,0, 0,  0,1,0, -14,    0, 0,1, -21, 76.72); 
		RotZ(ang_rad[3]);
		ROT.multiply(ROT,SegmentoC[3]->H);
		SegmentoC[3]->setTransformT(SegmentoC[1]->shapes[1]->Ti, ROT);
		declarar_HD2(SegmentoC[3],gScene2);
		SegmentoC[3]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[3],(PelvisP + NxVec3(-97.45,90.38,16.63))));
		SegmentoC[3]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[3]->padre=1;
	
	SegmentoC[5]=new Physic_VRShape(5,   3,    0, 1, 0, -15,     1,  0, 0, 00,    0, 0, -1,20, 77.35); 
		RotZ(ang_rad[5]);
		ROT.multiply(ROT,SegmentoC[5]->H);
		SegmentoC[5]->setTransformT(SegmentoC[3]->shapes[3]->Ti, ROT);
		declarar_CD(SegmentoC[5],gScene2);
		SegmentoC[5]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[5],(PelvisP + NxVec3(-167,90,15))));
		SegmentoC[5]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[5]->padre=3;
		
/****************************Brazo Izquierdo*********************************/
SegmentoC[2]=new Physic_VRShape(1,   0,   0,-1, 0, 7,     1,0, 0, 0,     0, 0, 1, -18, 11.38);
		RotZ(ang_rad[2]);
		ROT.multiply(ROT,SegmentoC[2]->H);
		SegmentoC[2]->setTransformT(SegmentoC[0]->shapes[23]->Ti, ROT);
		declarar_HI1(SegmentoC[2], gScene2);
		SegmentoC[2]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[2],(PelvisP + NxVec3(60.94,89,4))));
		SegmentoC[2]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[2]->padre=0;
		
		
	SegmentoC[4]=new Physic_VRShape(3,   2,   1,0,0, 0,  0,1,0, -15,    0, 0,1,-22, 76.72);  
		RotZ(ang_rad[4]);
		ROT.multiply(ROT,SegmentoC[4]->H);
		SegmentoC[4]->setTransformT(SegmentoC[2]->shapes[1]->Ti, ROT);
		declarar_HI2(SegmentoC[4], gScene2);
		SegmentoC[4]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[4],(PelvisP + NxVec3(97,90,16))));
		SegmentoC[4]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[4]->padre=2;
		
		
	SegmentoC[6]=new Physic_VRShape(5,   4,  1, 0, 0, 0,   0,  1, 0, -15,    0, 0, 1,-20, 77.35);  
		RotZ(ang_rad[6]);
		ROT.multiply(ROT,SegmentoC[6]->H);
		SegmentoC[6]->setTransformT(SegmentoC[4]->shapes[3]->Ti, ROT);
		declarar_CI(SegmentoC[6], gScene2);
		SegmentoC[6]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[6],(PelvisP + NxVec3(166,90,15))));
		SegmentoC[6]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[6]->padre=4;
/****************************************Pierna Derecha*************************************/

	SegmentoC[7]=new Physic_VRShape(2,   0,   0,-1,0,-15,   -1,0,0,0,  0,0,-1,21, 14.88); 
		RotZ(ang_rad[7]);
		ROT.multiply(ROT,SegmentoC[7]->H);
		SegmentoC[7]->setTransformT(SegmentoC[0]->shapes[24]->Ti, ROT);
		declarar_IND(SegmentoC[7], gScene2);
		SegmentoC[7]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[7],(PelvisP + NxVec3(-38.31,-12,-15.23))));
		SegmentoC[7]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[7]->padre=0;
	
	
	SegmentoC[9]=new Physic_VRShape(6,   7,   0, 0, 1,-21,      0,1,0, -15,     1, 0,0,0, 137.05);
		RotX(ang_rad[9]);
		ROT.multiply(ROT,SegmentoC[9]->H);	
		SegmentoC[9]->setTransformT(SegmentoC[7]->shapes[1]->Ti, ROT);
		declarar_CaD1(SegmentoC[9], gScene2);
		SegmentoC[9]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[9],(PelvisP + NxVec3(-38.35, -46.10,-14.72))));
		SegmentoC[9]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[9]->padre=7;
	
	SegmentoC[11]=new Physic_VRShape(3,   9,    0, -1, 0, 0,    0, 0,-1, -23,    1,0, 0, -19, 30.62);
		RotZ(ang_rad[11]);
		ROT.multiply(ROT,SegmentoC[11]->H);	
		SegmentoC[11]->setTransformT(SegmentoC[9]->shapes[5]->Ti, ROT);
		declarar_CaD2(SegmentoC[11], gScene2);
		SegmentoC[11]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[11],(PelvisP + NxVec3(-38.81, -75.14,0))));
		SegmentoC[11]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[11]->padre=9;

	SegmentoC[13]=new Physic_VRShape(5,   11,    1,0, 0, 0,  0, -1, 0, 15,   0, 0, -1,22, 86.65);
		RotZ(ang_rad[13]);
		ROT.multiply(ROT,SegmentoC[13]->H);
		SegmentoC[13]->setTransformT(SegmentoC[11]->shapes[2]->Ti, ROT);
		declarar_RD(SegmentoC[13], gScene2);
		SegmentoC[13]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[13],(PelvisP + NxVec3(-38.08, -117.65,1.47))));
		SegmentoC[13]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[13]->padre=11;
		
		
		
	SegmentoC[15]=new Physic_VRShape(5,   13,  0, -1, 0, 15,   1, 0, 0, 0,   0,0, 1, -22,137.05  );
		RotZ(ang_rad[15]);
		ROT.multiply(ROT,SegmentoC[15]->H);
		SegmentoC[15]->setTransformT(SegmentoC[13]->shapes[4]->Ti, ROT);
		declarar_TD1(SegmentoC[15], gScene2);
		SegmentoC[15]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[15],(PelvisP + NxVec3(-38.35, -167.03,-14.97))));
		SegmentoC[15]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[15]->padre=13;
		
	SegmentoC[17]=new Physic_VRShape(2,   15,  -1,0,0,0,   0,0,1,10, 0,1,0,-36, 37.08);
		RotZ(ang_rad[17]);
		ROT.multiply(ROT,SegmentoC[17]->H);
		SegmentoC[17]->setTransformT(SegmentoC[15]->shapes[5]->Ti, ROT);
		declarar_TD2(SegmentoC[17], gScene2);
		SegmentoC[17]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[17],(PelvisP + NxVec3(-43.39, -207.74,-11.31))));
		SegmentoC[17]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[17]->padre=15;

/****************************************Pierna Izquierda*************************************/
	SegmentoC[8]=new Physic_VRShape(2,   0,  0,1,0,15,   1,0,0,0,  0,0,-1,21, 14.9); 
		RotZ(ang_rad[8]);
		ROT.multiply(ROT,SegmentoC[8]->H);
		SegmentoC[8]->setTransformT(SegmentoC[0]->shapes[25]->Ti, ROT);
		declarar_INI(SegmentoC[8], gScene2);
		SegmentoC[8]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[8],(PelvisP + NxVec3(39.19,-12,-15.23))));
		SegmentoC[8]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[8]->padre=0;
		
	SegmentoC[10]=new Physic_VRShape(6,   8,   0, 0, 1, -22,    0, 1,0, -15,    1,0, 0, 0, 137.05); 
		RotX(ang_rad[10]);
		ROT.multiply(ROT,SegmentoC[10]->H);	
		SegmentoC[10]->setTransformT(SegmentoC[8]->shapes[1]->Ti, ROT);
		declarar_CaI1(SegmentoC[10], gScene2);
		SegmentoC[10]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[10],(PelvisP + NxVec3(38.73, -46.10,-14.72))));
		SegmentoC[10]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[10]->padre=8;

	SegmentoC[12]=new Physic_VRShape(3,   10,  0, -1, 0, 0,    0,0 ,-1, -23,      1, 0, 0, 19, 30.62);
		RotZ(ang_rad[12]);
		ROT.multiply(ROT,SegmentoC[12]->H);	
		SegmentoC[12]->setTransformT(SegmentoC[10]->shapes[5]->Ti,ROT);
		declarar_CaI2(SegmentoC[12], gScene2);
		SegmentoC[12]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[12],(PelvisP + NxVec3(38.81, -75.14,0))));
		SegmentoC[12]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[12]->padre=10;
		
	SegmentoC[14]=new Physic_VRShape(5,   12,   -1,0, 0,0,  0,-1,0,15,   0, 0,1,-22, 86.65 );
		RotZ(ang_rad[14]);
		ROT.multiply(ROT,SegmentoC[14]->H);
		SegmentoC[14]->setTransformT(SegmentoC[12]->shapes[2]->Ti,ROT);
		declarar_RI(SegmentoC[14], gScene2);
		SegmentoC[14]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[14],(PelvisP + NxVec3(37.35, -117.65,1.47))));
		SegmentoC[14]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[14]->padre=12;

	SegmentoC[16]=new Physic_VRShape(6,   14,   0,-1,0,15, -1,0,0,0,  0,0,-1,22, 137.05);
		RotZ(ang_rad[16]);
		ROT.multiply(ROT,SegmentoC[16]->H);
		SegmentoC[16]->setTransformT(SegmentoC[14]->shapes[4]->Ti, ROT);
		declarar_TI1(SegmentoC[16], gScene2);
		SegmentoC[16]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[16],(PelvisP + NxVec3(37.62, -167.03,-14.97))));
		SegmentoC[16]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[16]->padre=14;

	SegmentoC[18]=new Physic_VRShape(2,   16,  -1,0,0,0,   0,0,1,10, 0,1,0,-36, 37.08);
		RotZ(ang_rad[18]);
		ROT.multiply(ROT,SegmentoC[18]->H);
		SegmentoC[18]->setTransformT(SegmentoC[16]->shapes[5]->Ti, ROT);
		declarar_TI2(SegmentoC[18], gScene2);
		SegmentoC[18]->actor->setCMassOffsetGlobalPose(NxMat34(Rot[18],(PelvisP + NxVec3(42, -207.74,-11.31))));
		SegmentoC[18]->actor->raiseBodyFlag(NX_BF_KINEMATIC);
		SegmentoC[18]->padre=16;

}