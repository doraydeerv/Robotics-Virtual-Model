#include <stdio.h>
#include "NxPhysics.h"
#include <math.h>
#include "Torso.h"
#include "BrazoIzquierdo.h"
#include "BrazoDerecho.h"
#include "PiernaIzquierda.h"
#include "PiernaDerecha.h"


extern float ang_rad[19];
extern float pi;

extern NxPhysicsSDK*     gPhysicsSDK;
extern NxScene*          gScene2;
extern NxVec3            gDefaultGravity;
extern Physic_VRShape  *SegmentoC[19];


void RotX(float angulo);
void RotY(float angulo);
void RotZ(float angulo);
void SegmentosCin();

	   
		

		
