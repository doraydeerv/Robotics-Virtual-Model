#define NOMINMAX 
#ifndef LINUX
#include <windows.h>
#else
#include <windows_replacement.h>
#endif
#include <GL/gl.h>
#include <GL/glut.h>
#include <stdio.h>

#include "NxPhysics.h"
#include "Objects.h"

static bool gShadows = false;

NxObject::NxObject(NxActor* actor) : owner(actor)
	{
	color.x = color.y = color.z = 1.0f;

	NX_ASSERT(actor);
	NX_ASSERT(!actor->userData);
	actor->userData	= this;
	}

NxObject::~NxObject()
	{
	}

NxCubeObject::NxCubeObject(NxActor* actor, NxF32 s) : NxObject(actor), size(s)
	{
	}

NxCubeObject::~NxCubeObject()
	{
	}

void NxCubeObject::render() const
	{
	float glmat[16];
	glPushMatrix();
	owner->getGlobalPose().getColumnMajor44(glmat);
	glMultMatrixf(glmat);
	glColor3fv(&color.x);
	glutSolidCube(size);
	glPopMatrix();

	// Handle shadows
	if(gShadows)
		{
		glPushMatrix();

		const static float ShadowMat[]={ 1,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,1 };

		glMultMatrixf(ShadowMat);
		glMultMatrixf(glmat);
		glDisable(GL_LIGHTING);
		glColor3f(0.1f, 0.2f, 0.3f);
		glutSolidCube(size);
		glColor3f(1.0f, 1.0f, 1.0f);
		glEnable(GL_LIGHTING);

		glPopMatrix();
		}
	}

NxSphereObject::NxSphereObject(NxActor* actor, NxF32 s) : NxObject(actor), size(s)
	{
	}

NxSphereObject::~NxSphereObject()
	{
	}

void NxSphereObject::render() const
	{
	float glmat[16];
	glPushMatrix();
	owner->getGlobalPose().getColumnMajor44(glmat);
	glMultMatrixf(glmat);
	glColor3fv(&color.x);
	glutSolidSphere(size, 10, 10);
	glPopMatrix();

	// Handle shadows
	if(gShadows)
		{
		glPushMatrix();

		const static float ShadowMat[]={ 1,0,0,0, 0,0,0,0, 0,0,1,0, 0,0,0,1 };

		glMultMatrixf(ShadowMat);
		glMultMatrixf(glmat);

		glDisable(GL_LIGHTING);
		glColor3f(0.1f, 0.2f, 0.3f);
		glutSolidSphere(size, 10, 10);
		glColor3f(1.0f, 1.0f, 1.0f);
		glEnable(GL_LIGHTING);

		glPopMatrix();
		}
	}

NxCapsuleObject::NxCapsuleObject(NxActor* actor, NxF32 radius, NxF32 height) : NxObject(actor)
	{
	}

NxCapsuleObject::~NxCapsuleObject()
	{
	}

static void setupGLMatrix(const NxVec3& pos, const NxMat33& orient)
{
	float glmat[16];	//4x4 column major matrix for OpenGL.
	orient.getColumnMajorStride4(&(glmat[0]));
	pos.get(&(glmat[12]));

	//clear the elements we don't need:
	glmat[3] = glmat[7] = glmat[11] = 0.0f;
	glmat[15] = 1.0f;

	glMultMatrixf(&(glmat[0]));
}

static int dispListPlane2 = 0xffffffff;
static int dispListBox2 = 0xffffffff;
static int dispListSphere2 = 0xffffffff;
static int dispListCylinder2 = 0xffffffff;

void initShapeDisplayLists2()
{
	// PLANE DISPLAY LIST
	glLoadIdentity();
	dispListPlane2 = glGenLists(1);
	glNewList(dispListPlane2, GL_COMPILE);

	glBegin(GL_QUADS);
	glNormal3f(0,1,0);
	glVertex3f(-1,0,-1);
	glVertex3f(-1,0,1);
	glVertex3f(1,0,1);
	glVertex3f(1,0,-1);

	glEnd();
	glEndList();

	// BOX DISPLAY LIST
	glLoadIdentity();
	dispListBox2 = glGenLists(1);//get a unique display list ID.
	glNewList(dispListBox2, GL_COMPILE);      

	glBegin(GL_QUADS);
	glNormal3f(0,0,1);
	glVertex3f(-1,-1,1);
	glVertex3f(1,-1,1);
	glVertex3f(1,1,1);
	glVertex3f(-1,1,1);

	glNormal3f(0,0,-1);
	glVertex3f(-1,1,-1);
	glVertex3f(1,1,-1);
	glVertex3f(1,-1,-1);
	glVertex3f(-1,-1,-1);

	glNormal3f(0,1,0);
	glVertex3f(-1,1,1);
	glVertex3f(1,1,1);
	glVertex3f(1,1,-1);
	glVertex3f(-1,1,-1);

	glNormal3f(0,-1,0);
	glVertex3f(-1,-1,-1);
	glVertex3f(1,-1,-1);
	glVertex3f(1,-1,1);
	glVertex3f(-1,-1,1);

	glNormal3f(1,0,0);
	glVertex3f(1,-1,-1);
	glVertex3f(1,1,-1);
	glVertex3f(1,1,1);
	glVertex3f(1,-1,1);

	glNormal3f(-1,0,0);
	glVertex3f(-1,-1,1);
	glVertex3f(-1,1,1);
	glVertex3f(-1,1,-1);
	glVertex3f(-1,-1,-1);

	glEnd();
	glEndList();

	// SPHERE DISPLAY LIST
	dispListSphere2 = glGenLists(1);
	glNewList(dispListSphere2, GL_COMPILE);      
	GLUquadricObj * quadObj = gluNewQuadric ();
	gluQuadricDrawStyle (quadObj, GLU_FILL);
	gluQuadricNormals (quadObj, GLU_SMOOTH); 
	gluQuadricOrientation(quadObj,GLU_OUTSIDE);
	gluSphere (quadObj, 1.0f, 9, 7);	//unit sphere
	glEndList();
	gluDeleteQuadric(quadObj);

	// CYLINDER DISPLAY LIST
	dispListCylinder2 = glGenLists(1);
	glNewList(dispListCylinder2, GL_COMPILE);      
	quadObj = gluNewQuadric ();
	gluQuadricDrawStyle (quadObj, GLU_FILL);
	gluQuadricNormals (quadObj, GLU_SMOOTH); 
	gluQuadricOrientation(quadObj,GLU_OUTSIDE);
	gluCylinder  (quadObj, 1.0f, 1.0f, 1.0f, 18, 1);	//unit cylinder
	glEndList();
	gluDeleteQuadric(quadObj);
}

void releaseShapeDisplayLists2()
{
	glDeleteLists(dispListPlane2,1);
	glDeleteLists(dispListBox2,1);
	glDeleteLists(dispListSphere2,1);
	glDeleteLists(dispListCylinder2,1);
}

void NxCapsuleObject::render() const
	{

	if(dispListSphere2==0xffffffff)
	{
	initShapeDisplayLists2();
	}


	NxShape* capsule = *owner->getShapes();

	NxMat34 pose = capsule->getGlobalPose();

	const NxReal & r = capsule->isCapsule()->getRadius();
	const NxReal & h = capsule->isCapsule()->getHeight();

	glColor3fv(&color.x);

	glPushMatrix();
	setupGLMatrix(pose.t, pose.M);

	glPushMatrix();
	glTranslated(0.0f, h*0.5f, 0.0f);
	glScaled(r,r,r);
	glCallList(dispListSphere2);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0.0f,-h*0.5f, 0.0f);
	glScaled(r,r,r);
	glCallList(dispListSphere2);
	glPopMatrix();

	glPushMatrix();
	glTranslated(0.0f,h*0.5f, 0.0f);
	glScaled(r,h,r);
	glRotated(90.0f,1.0f,0.0f,0.0f);
	glCallList(dispListCylinder2);
	glPopMatrix();

	glPopMatrix();
	}

