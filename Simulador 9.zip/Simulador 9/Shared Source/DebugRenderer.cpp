// ===============================================================================
//						     PHYSX SDK TRAINING PROGRAMS
//			                       DEBUG RENDERER
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#include "DebugRenderer.h"
#include "NxDebugRenderable.h"
#include <GL/glut.h>

NX_INLINE void setupColor(NxU32 color)
{
	NxF32 Blue	= NxF32((color)&0xff)/255.0f;
	NxF32 Green	= NxF32((color>>8)&0xff)/255.0f;
	NxF32 Red	= NxF32((color>>16)&0xff)/255.0f;
	glColor3f(Red, Green, Blue);
}

void DebugRenderer::renderData(const NxDebugRenderable& data) const
{
	glLineWidth(1.0f);

	glPushMatrix();
	glDisable(GL_LIGHTING);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Render points
/*	NxU32 NbPoints = data.getNbPoints();
	if(NbPoints)
	{
		const NxDebugPoint* Points = data.getPoints();

		glBegin(GL_POINTS);
		while(NbPoints--)
		{
			setupColor(Points->color);
			glVertex3fv(&Points->p.x);
			Points++;
		}
		glEnd();
	}*/

	// Render lines
	NxU32 NbLines = data.getNbLines();
	if(NbLines)
	{
		const NxDebugLine* Lines = data.getLines();

		glBegin(GL_LINES);
		while(NbLines--)
		{
			setupColor(Lines->color);
			glVertex3fv(&Lines->p0.x);
			glVertex3fv(&Lines->p1.x);
			Lines++;
		}
		glEnd();
	}
/*	
	// Render triangles
	NxU32 NbTris = data.getNbTriangles();
	if(NbTris)
	{
		const NxDebugTriangle* Triangles = data.getTriangles();

		glBegin(GL_TRIANGLES);
		while(NbTris--)
		{
			setupColor(Triangles->color);
			glVertex3fv(&Triangles->p0.x);
			glVertex3fv(&Triangles->p1.x);
			glVertex3fv(&Triangles->p2.x);
			Triangles++;
		}
		glEnd();
	}*/

	// Reset the color
	glColor3f(1,1,1);

	glEnable(GL_LIGHTING);
	glPopMatrix();
}


