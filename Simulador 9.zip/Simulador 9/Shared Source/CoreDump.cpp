#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>

#include "CoreDump.h"
#include "NxPhysics.h"
#include "NxPMap.h"
#include "NxSceneStats.h"

//==================================================================================
static const char *	getFloatString(float v,bool	binary=false)
{
	static char	data[64*16];
	static int	index=0;

	char *ret =	&data[index*64];
	index++;
	if (index == 16	) index	= 0;

	if ( v == FLT_MAX )
	{
		strcpy(ret,"fltmax");
	}
	else if	( v	== FLT_MIN )
	{
		strcpy(ret,"fltmin");
	}
	else if	( v	== 1 )
	{
		strcpy(ret,"1");
	}
	else if	( v	== 0 )
	{
		strcpy(ret,"0");
	}
	else if	( v	== -1 )
	{
		strcpy(ret,"-1");
	}
	else
	{
		if ( binary	)
		{
			unsigned int *iv = (unsigned int *)	&v;
			sprintf(ret,"%.4f$%x", v, *iv );
		}
		else
		{
			sprintf(ret,"%.9f",	v );
			const char *dot	= strstr(ret,".");
			if ( dot )
			{
				int	len	= (int)strlen(ret);
				char *foo =	&ret[len-1];
				while (	*foo ==	'0'	) foo--;
				if ( *foo == '.' )
					*foo = 0;
				else
					foo[1] = 0;
			}
		}
	}

	return ret;
}

//==================================================================================
static const char *	getString(NxJointProjectionMode	&m)
{
	const char *ret	= "unknown?";
	switch ( m )
	{
		case NX_JPM_NONE: ret =	"NX_JPM_NONE"; break;
		case NX_JPM_POINT_MINDIST: ret = "NX_JPM_POINT_MINDIST"; break;
	}
	return ret;
}

//==================================================================================
static const char *	getString(NxD6JointMotion m)
{
	const char * ret = "unknown?";

  switch ( m )
  {
	case NX_D6JOINT_MOTION_LOCKED: ret = "NX_D6JOINT_MOTION_LOCKED"; break;
	case NX_D6JOINT_MOTION_LIMITED:	ret	= "NX_D6JOINT_MOTION_LIMITED"; break;
	case NX_D6JOINT_MOTION_FREE: ret = "NX_D6JOINT_MOTION_FREE"; break;
  }

  return ret;
}

//==================================================================================
static const char *	getString(NxJointType type)
{
	const char *ret	= "unknown?";

  switch ( type	)
  {
	case NX_JOINT_PRISMATIC: ret = "NX_JOINT_PRISMATIC"; break;
	case NX_JOINT_REVOLUTE:	ret	= "NX_JOINT_REVOLUTE"; break;
	case NX_JOINT_CYLINDRICAL: ret = "NX_JOINT_CYLINDRICAL"; break;
	case NX_JOINT_SPHERICAL: ret = "NX_JOINT_SPHERICAL"; break;
	case NX_JOINT_POINT_ON_LINE: ret = "NX_JOINT_POINT_ON_LINE"; break;
	case NX_JOINT_POINT_IN_PLANE: ret =	"NX_JOINT_POINT_IN_PLANE"; break;
	case NX_JOINT_DISTANCE:	ret	= "NX_JOINT_DISTANCE"; break;
	case NX_JOINT_PULLEY: ret =	"NX_JOINT_PULLY"; break;
	case NX_JOINT_FIXED: ret = "NX_JOINT_FIXED"; break;
	case NX_JOINT_D6: ret =	"NX_JOINT_D6"; break;
	}

  return ret;
}

//==================================================================================
static const char *	getString(NxHeightFieldAxis	a)
{
	const char *ret	= "unknown?";

	switch ( a )
	{
		case NX_X:
			ret	= "NX_X";
			break;
		case NX_Y:
			ret	= "NX_Y";
			break;
		case NX_Z:
			ret	= "NX_Z";
			break;
		case NX_NOT_HEIGHTFIELD:
			ret	= "NX_NOT_HEIGHTFIELD";
			break;
	}
  return ret;
}

//==================================================================================
static const char *	getString(NxShapeType type)
{
	const char * ret = "unknown?";

	switch ( type )
	{
	case NX_SHAPE_PLANE:
		ret	= "NX_SHAPE_PLANE";
		break;
	case NX_SHAPE_SPHERE:
		ret	= "NX_SHAPE_SPHERE";
		break;
	case NX_SHAPE_BOX:
		ret	= "NX_SHAPE_BOX";
		break;
	case NX_SHAPE_CAPSULE:
		ret	= "NX_SHAPE_CAPSULE";
		break;
	case NX_SHAPE_CONVEX:
		ret	= "NX_SHAPE_CONVEX";
		break;
	case NX_SHAPE_MESH:
		ret	= "NX_SHAPE_MESH";
		break;
	case NX_SHAPE_COMPOUND:
		ret	= "NX_SHAPE_COMPOUND";
		break;
  }

	return ret;
}

//==================================================================================
static const char *	getString(NxCombineMode	mode)
{
	const char * ret = "unknown?";
	switch ( mode )
	{
	  case NX_CM_AVERAGE: ret =	"NX_CM_AVERAGE"; break;
	  case NX_CM_MIN:	  ret =	"NX_CM_MIN"; break;
	  case NX_CM_MULTIPLY:ret =	"NX_CM_MULTIPLY"; break;
	  case NX_CM_MAX:	  ret =	"NX_CM_MAX"; break;
	}
	return ret;
}

unsigned int CoreDump::getCoreVersion(NxPhysicsSDK *sdk)
{
	unsigned int ret = 0;

  if ( 1 )
  {
  	NxU32 apiRev,descRev,branchId;

    NxU32 sdkRev;

    if ( sdk )
    {
      sdkRev = sdk->getInternalVersion(apiRev,descRev,branchId);
    }
    else
    {
    	sdkRev = NX_SDK_VERSION_NUMBER;
    	apiRev = NX_SDK_API_REV;
    	descRev = NX_SDK_DESC_REV;
    	branchId = NX_SDK_BRANCH;
    }

		// The core dump version is determined first by what SDK version we are on 2.3.0 etc...
		// next by the version of the serialized data stream and, finally, by what
		// branch we are building against.
		ret = (sdkRev << 16 ) | (descRev << 8 ) | (branchId << 8 );


  }

  return ret;
}

//==================================================================================
bool CoreDump::coreDump(NxPhysicsSDK *sdk,const	char *fname,bool binary) //	save the contents of the state of the physics SDK in text or binary.
{
	bool ret = false;

#if	CORE_DUMP_ENABLE

	mFph = fopen(fname,"wb");
	mBinary	= binary;
	mIndent	= 0;

	if ( 1 ) //	gather all of the triangle meshes and convex hulls in the scene!
	{
		NxU32 scount = sdk->getNbScenes();
		for	(NxU32 i=0;	i<scount; i++)
		{
			NxScene	*scene = sdk->getScene(i);

			NxU32 acount = scene->getNbActors();

			if ( acount	)
			{
				NxActor	**actors = scene->getActors();
				for	(NxU32 j=0;	j<acount; j++)
				{
					NxActor	*a = actors[j];
					NxU32 nbActorShapes	  =	a->getNbShapes();
					NxShape	*const*	actorShapes	= a->getShapes();

					for	(NxU32 k=0;	k<nbActorShapes; k++)
					{
						NxShape	*shape = actorShapes[k];
						switch ( shape->getType() )
						{
							case NX_SHAPE_PLANE:
							if ( 1 )
							{
								const NxPlaneShape		  *current	 = shape->isPlane();
								assert(current);
								NxPlaneShapeDesc		Desc;
								current->saveToDesc(Desc);
								if ( Desc.ccdSkeleton )	AddSkeleton(Desc.ccdSkeleton );
							}
							break;
							case NX_SHAPE_SPHERE:
							if ( 1 )
							{
								const NxSphereShape		  *current	= shape->isSphere();
								NxSphereShapeDesc		Desc;
								assert(	current	);
								current->saveToDesc(Desc);
								if ( Desc.ccdSkeleton )	AddSkeleton(Desc.ccdSkeleton );
							}
								break;
							case NX_SHAPE_BOX:
							if ( 1 )
							{
								const NxBoxShape		  *current	   = shape->isBox();
								NxBoxShapeDesc			Desc;
								assert(	current	);
								current->saveToDesc(Desc);
								if ( Desc.ccdSkeleton )	AddSkeleton(Desc.ccdSkeleton );
							}
								break;
							case NX_SHAPE_CAPSULE:
							if ( 1 )
							{
								const NxCapsuleShape	  *current = shape->isCapsule();
								NxCapsuleShapeDesc		Desc;
								assert(	current	);
								current->saveToDesc(Desc);
								if ( Desc.ccdSkeleton )	AddSkeleton(Desc.ccdSkeleton );
							}
								break;
							case NX_SHAPE_CONVEX:
							if ( 1 )
							{
								const NxConvexShape		  *current	= shape->isConvexMesh();
									NxConvexShapeDesc	Desc;
								assert(	current	);
								current->saveToDesc(Desc);
								if ( Desc.ccdSkeleton )	AddSkeleton(Desc.ccdSkeleton );
								if ( Desc.meshData	  )	AddConvex(Desc.meshData);
							}
								break;
							case NX_SHAPE_MESH:
							if ( 1 )
							{
								const NxTriangleMeshShape *current	 = shape->isTriangleMesh();
								NxTriangleMeshShapeDesc	Desc;
								assert(	current	);
								current->saveToDesc(Desc);
								if ( Desc.ccdSkeleton )	AddSkeleton(Desc.ccdSkeleton );
								if ( Desc.meshData	  )	AddTriangleMesh(Desc.meshData);
											}
								break;
							case NX_SHAPE_COMPOUND:
								assert(0); // this is impossible!
								break;
							default:
								assert(0); //!!???
								break;
						}
					}
				}
			}

		}
	}

	if ( mFph )
	{
		WriteInt("[Physics SDK Version]", getCoreVersion(sdk) );
		++mIndent;

		// write out the number	of values we are writing
		WriteInt("[NUM_PARAMS]", NX_PARAMS_NUM_VALUES );
		for	(int i=NX_PENALTY_FORCE; i<	NX_PARAMS_NUM_VALUES; i++)
		{
			NxParameter	p =	(NxParameter) i;
			NxReal v = sdk->getParameter( p	);
			WriteParam(	p, v );
		}

		// list	of all of
		if ( mBinary )
		{
			unsigned int i;

			// k, output triangle mesh info
			unsigned numTriangleMeshes = mTriangleMeshes.size();
			WriteInt_b(	numTriangleMeshes );
			for	( i	= 0; i < numTriangleMeshes;	++i	)
			{
				char scratch[512];
				sprintf( scratch, "[TriangleMesh%d]", i+1 );
				//WriteTriangleMesh_b( mTriangleMeshes[i] );
				Write( scratch,	mTriangleMeshes[i] );
			}

			// k, output the convex	mesh info
			unsigned numConvexMeshes = mConvexMeshes.size();
			WriteInt_b(	numConvexMeshes	);
			for	( i	= 0; i < numConvexMeshes; ++i )
			{
				char scratch[512];
				sprintf( scratch, "[ConvexMesh%d]",	i+1	);
				//WriteConvexMesh_b( scratch, mConvexMeshes[i] );
				Write( scratch,	mConvexMeshes[i] );
			}

			// k, output skeletons
			unsigned numSkeletons =	mSkeletons.size();
			WriteInt_b(	numSkeletons );
			for	( i	= 0; i < numSkeletons; ++i )
			{
				char scratch[512];
				sprintf( scratch, "Skeleton	%d", i+1 );
				Write( scratch,	mSkeletons[i] );
			}
		}
		else
		{
			Print("[nbTriangleMeshes] %d", mTriangleMeshes.size() );
			++mIndent;

			for	(unsigned int i=0; i<mTriangleMeshes.size(); i++)
			{
				char scratch[512];
				sprintf(scratch,"[TriangleMesh%d]",	i );
				Write(scratch, mTriangleMeshes[i] );
			}
			--mIndent;

			Print("[nbConvexMeshes]	%d",   mConvexMeshes.size()	);
			++mIndent;
			if ( 1 )
			{
				for	(unsigned int i=0; i<mConvexMeshes.size(); i++)
				{
						char scratch[512];
						sprintf(scratch,"[ConvexMesh%d]", i+1 );
						Write(scratch, mConvexMeshes[i]	);
				}
			}
			--mIndent;

			Print("[nbCCDSkeletons]	%d",   mSkeletons.size() );
			++mIndent;
			if ( 1 )
			{
				for	(unsigned int i=0; i<mSkeletons.size();	i++)
				{
					char scratch[512];
					sprintf(scratch,"[ccdSkeleton%d]", i+1 );
					Write(scratch, mSkeletons[i] );
				}
			}
			--mIndent;
		}

		NxU32 scount = sdk->getNbScenes();
		Write("[NbScenes]",scount);
		++mIndent;
		if (  1	)
		{
			for	(NxU32 i=0;	i<scount; i++)
			{
					NxScene	*scene = sdk->getScene(i);
					assert(	scene );
					char scratch[512];
					sprintf(scratch,"[Scene%d]", i+1 );
					SaveUserData(scene);
					Write(scratch,scene);
					RestoreUserData(scene);
			}
		}

		--mIndent;
		--mIndent;

		fclose(mFph);
		mFph = 0;
		ret = true;
	}
#endif

	return ret;
}


#if	CORE_DUMP_ENABLE

//==================================================================================
void CoreDump::WriteBool( const	char *desc,	bool yesNo )
{
	if ( mFph )
	{
		if ( mBinary )
		{
			char value = yesNo ? 1 : 0;
			fwrite(	&value,	sizeof(char), 1, mFph );
		}
		else
		{
			Print( "%s = %s", desc,	yesNo ?	"TRUE" : "FALSE" );
		}
	}
}

//==================================================================================
void CoreDump::WriteChar( const char *desc, char c, bool descAsInt )
{
	if ( mFph )
	{
		if ( mBinary )
		{
			fwrite(	&c,	sizeof(char), 1, mFph );
		}
		else
		{
			if ( descAsInt )
			{
				Print( "%s = %d", desc,	(int)c );
			}
			else
			{
				Print( "%s = %c", desc,	c );
			}
		}
	}
}

//==================================================================================
void CoreDump::WriteInt(const char *desc,int n)
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&n,	sizeof(int), 1,	mFph );
		else
			Print("%s =	%d", desc, n );
	}
}

//==================================================================================
void CoreDump::WriteLong( const	char *desc,	long l )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&l,	sizeof(long), 1, mFph );
		else
			Print("%s =	%ld", desc,	l );
	}
}

//==================================================================================
void CoreDump::WriteShort( const char *desc, short s )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&s,	sizeof(short), 1, mFph );
		else
			Print("%s =	%d", desc, s );
	}
}

//==================================================================================
void CoreDump::WriteUnsigned( const	char *desc,	unsigned u )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&u,	sizeof(unsigned), 1, mFph );
		else
			Print("%s =	%d", desc, u );
	}
}

//==================================================================================
void CoreDump::WriteUnsignedLong( const	char *desc,	unsigned long ul )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&ul, sizeof(unsigned long),	1, mFph	);
		else
			Print("%s =	%ld", desc,	ul );
	}
}

//==================================================================================
void CoreDump::WriteUnsignedShort( const char *desc, unsigned short	us )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&us, sizeof(unsigned short), 1,	mFph );
		else
			Print("%s =	%d", desc, us );
	}
}

//==================================================================================
void CoreDump::WriteFloat( const char *desc, float f )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&f,	sizeof(float), 1, mFph );
		else
			Print( "%s = %s", desc,	getFloatString(	f, false ) );
			//Print( "%s %f", desc,	f );
	}
}

//==================================================================================
void CoreDump::WriteFlag( const	char *desc,	unsigned f )
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(	&f,	sizeof(unsigned), 1, mFph );
		else
			Print( "%s 0x%x", desc,	f );
	}
}

//==================================================================================
void CoreDump::WriteString(	const char *info )
{
	if ( mFph )
	{
		if ( mBinary )
		{
			int	len	= 0;
			assert(	mBinary	);

			if ( info )
			{
				len	= strlen( info );
				fwrite(	&len, sizeof(int), 1, mFph );
				fwrite(	info, sizeof(char),	sizeof(char)*len, mFph );
			}
			else
			{
				fwrite(	&len, sizeof(int), 1, mFph );
			}		 
		}
		else
		{
			Print( "%s", info );
		}
	}
}

//==================================================================================
void CoreDump::WriteChar_b(	char val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(char),	1, mFph	);
	}
}

//==================================================================================
void CoreDump::WriteInt_b( int val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(int), 1, mFph );
	}
}

//==================================================================================
void CoreDump::WriteLong_b(	long val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(long),	1, mFph	);
	}
}

//==================================================================================
void CoreDump::WriteShort_b( short val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(short), 1,	mFph );		   
	}
}

//==================================================================================
void CoreDump::WriteUnsigned_b(	unsigned val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(unsigned),	1, mFph	);		  
	}
}

//==================================================================================
void CoreDump::WriteUnsignedLong_b(	unsigned long val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(unsigned long), 1,	mFph );		   
	}
}

//==================================================================================
void CoreDump::WriteUnsignedShort_b( unsigned short	val	)
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(unsigned short), 1, mFph );		
	}
}

//==================================================================================
void CoreDump::WriteFloat_b( float val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(float), 1,	mFph );		   
	}
}

//==================================================================================
void CoreDump::WriteDouble_b( double val )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&val, sizeof(double), 1, mFph );		
	}
}

//==================================================================================
void CoreDump::WriteString_b( const	char *val )
{
	if ( mFph )
	{
		int	len	= 0;
		assert(	mBinary	);

		if ( val )
		{
			len	= strlen( val );
			fwrite(	&len, sizeof(int), 1, mFph );
			fwrite(	&val, sizeof(char),	sizeof(char)*len, mFph );
		}
		else
		{
			fwrite(	&len, sizeof(int), 1, mFph );
		}
	}
}

//==================================================================================
void CoreDump::WriteFlag_b(	unsigned flag )
{
	if ( mFph )
	{
		assert(	mBinary	);
		fwrite(	&flag, sizeof(unsigned), 1,	mFph );
	}
}

//==================================================================================
void CoreDump::WriteMatrix_b( const	NxMat34	&matrix	)
{
	if ( mFph )
	{
		assert(	mBinary	);
		NxReal m[9];
		matrix.M.getRowMajor( m	);

		// k, write	out	the	matrix
		for	( int i	= 0; i < 9;	++i	)
		{
			WriteFloat_b( m[i] );
		}
		WriteFloat_b( matrix.t.x );
		WriteFloat_b( matrix.t.y );
		WriteFloat_b( matrix.t.z );
	}
}

//==================================================================================
void CoreDump::WriteVec3_b(	const NxVec3 &v	)
{
	if ( mFph )
	{
		assert(	mBinary	);
		WriteFloat_b( v.x );
		WriteFloat_b( v.y );
		WriteFloat_b( v.z );
	}
}

//==================================================================================
void CoreDump::WriteParam(NxParameter p,NxReal v)
{
	if ( mFph )
	{
		if ( mBinary )
			WriteFloat_b( v	);
		else
		{
			const char *param =	"Unknown?";

			switch ( p )
			{
#if NX_SDK_BRANCH != NX_BRANCH_FWDEV230
				case NX_CCD_EPSILON:
					param = "NX_CCD_EPSILON";
					break;
#endif
				case NX_PENALTY_FORCE:
					param =	"NX_PENALTY_FORCE";	break;
				case NX_SKIN_WIDTH:
					param =	"NX_SKIN_WIDTH"; break;
				case NX_DEFAULT_SLEEP_LIN_VEL_SQUARED:
					param =	"NX_DEFAULT_SLEEP_LIN_VEL_SQUARED";	break;
				case NX_DEFAULT_SLEEP_ANG_VEL_SQUARED:
					param =	"NX_DEFAULT_SLEEP_ANG_VEL_SQUARED";	break;
				case NX_BOUNCE_THRESHOLD:
					param =	"NX_BOUNCE_THRESHOLD"; break;
				case NX_DYN_FRICT_SCALING:
					param =	"NX_DYN_FRICT_SCALING";	break;
				case NX_STA_FRICT_SCALING:
					param =	"NX_STA_FRICT_SCALING";	break;
				case NX_MAX_ANGULAR_VELOCITY:
					param =	"NX_MAX_ANGULAR_VELOCITY"; break;
				case NX_CONTINUOUS_CD:
					param =	"NX_CONTINUOUS_CD";	break;
				case NX_VISUALIZATION_SCALE:
					param =	"NX_VISUALIZATION_SCALE"; break;
				case NX_VISUALIZE_WORLD_AXES:
					param =	"NX_VISUALIZE_WORLD_AXES"; break;
				case NX_VISUALIZE_BODY_AXES:
					param =	"NX_VISUALIZE_BODY_AXES"; break;
				case NX_VISUALIZE_BODY_MASS_AXES:
					param =	"NX_VISUALIZE_BODY_MASS_AXES"; break;
				case NX_VISUALIZE_BODY_LIN_VELOCITY:
					param =	"NX_VISUALIZE_BODY_LIN_VELOCITY"; break;
				case NX_VISUALIZE_BODY_ANG_VELOCITY:
					param =	"NX_VISUALIZE_BODY_ANG_VELOCITY"; break;
				case NX_VISUALIZE_BODY_LIN_MOMENTUM:
					param =	"NX_VISUALIZE_BODY_LIN_MOMENTUM"; break;
				case NX_VISUALIZE_BODY_ANG_MOMENTUM:
					param =	"NX_VISUALIZE_BODY_ANG_MOMENTUM"; break;
				case NX_VISUALIZE_BODY_LIN_ACCEL:
					param =	"NX_VISUALIZE_BODY_LIN_ACCEL"; break;
				case NX_VISUALIZE_BODY_ANG_ACCEL:
					param =	"NX_VISUALIZE_BODY_ANG_ACCEL"; break;
				case NX_VISUALIZE_BODY_LIN_FORCE:
					param =	"NX_VISUALIZE_BODY_LIN_FORCE"; break;
				case NX_VISUALIZE_BODY_ANG_FORCE:
					param =	"NX_VISUALIZE_BODY_ANG_FORCE"; break;
				case NX_VISUALIZE_BODY_REDUCED:
					param =	"NX_VISUALIZE_BODY_REDUCED"; break;
				case NX_VISUALIZE_BODY_JOINT_GROUPS:
					param =	"NX_VISUALIZE_BODY_JOINT_GROUPS"; break;
				case NX_VISUALIZE_BODY_CONTACT_LIST:
					param =	"NX_VISUALIZE_BODY_CONTACT_LIST"; break;
				case NX_VISUALIZE_BODY_JOINT_LIST:
					param =	"NX_VISUALIZE_BODY_JOINT_LIST";	break;
				case NX_VISUALIZE_BODY_DAMPING:
					param =	"NX_VISUALIZE_BODY_DAMPING"; break;
				case NX_VISUALIZE_BODY_SLEEP:
					param =	"NX_VISUALIZE_BODY_SLEEP"; break;
				case NX_VISUALIZE_JOINT_LOCAL_AXES:
					param =	"NX_VISUALIZE_JOINT_LOCAL_AXES"; break;
				case NX_VISUALIZE_JOINT_WORLD_AXES:
					param =	"NX_VISUALIZE_JOINT_WORLD_AXES"; break;
				case NX_VISUALIZE_JOINT_LIMITS:
					param =	"NX_VISUALIZE_JOINT_LIMITS"; break;
				case NX_VISUALIZE_JOINT_ERROR:
					param =	"NX_VISUALIZE_JOINT_ERROR";	break;
				case NX_VISUALIZE_JOINT_FORCE:
					param =	"NX_VISUALIZE_JOINT_FORCE";	break;
				case NX_VISUALIZE_JOINT_REDUCED:
					param =	"NX_VISUALIZE_JOINT_REDUCED"; break;
				case NX_VISUALIZE_CONTACT_POINT:
					param =	"NX_VISUALIZE_CONTACT_POINT"; break;
				case NX_VISUALIZE_CONTACT_NORMAL:
					param =	"NX_VISUALIZE_CONTACT_NORMAL"; break;
				case NX_VISUALIZE_CONTACT_ERROR:
					param =	"NX_VISUALIZE_CONTACT_ERROR"; break;
				case NX_VISUALIZE_CONTACT_FORCE:
					param =	"NX_VISUALIZE_CONTACT_FORCE"; break;
				case NX_VISUALIZE_ACTOR_AXES:
					param =	"NX_VISUALIZE_ACTOR_AXES"; break;
				case NX_VISUALIZE_COLLISION_AABBS:
					param =	"NX_VISUALIZE_COLLISION_AABBS";	break;
				case NX_VISUALIZE_COLLISION_SHAPES:
					param =	"NX_VISUALIZE_COLLISION_SHAPES"; break;
				case NX_VISUALIZE_COLLISION_AXES:
					param =	"NX_VISUALIZE_COLLISION_AXES"; break;
				case NX_VISUALIZE_COLLISION_COMPOUNDS:
					param =	"NX_VISUALIZE_COLLISION_COMPOUNDS";	break;
				case NX_VISUALIZE_COLLISION_VNORMALS:
					param =	"NX_VISUALIZE_COLLISION_VNORMALS"; break;
				case NX_VISUALIZE_COLLISION_FNORMALS:
					param =	"NX_VISUALIZE_COLLISION_FNORMALS"; break;
				case NX_VISUALIZE_COLLISION_EDGES:
					param =	"NX_VISUALIZE_COLLISION_EDGES";	break;
				case NX_VISUALIZE_COLLISION_SPHERES:
					param =	"NX_VISUALIZE_COLLISION_SPHERES"; break;
				case NX_VISUALIZE_COLLISION_SAP:
					param =	"NX_VISUALIZE_COLLISION_SAP"; break;
				case NX_VISUALIZE_COLLISION_STATIC:
					param =	"NX_VISUALIZE_COLLISION_STATIC"; break;
				case NX_VISUALIZE_COLLISION_DYNAMIC:
					param =	"NX_VISUALIZE_COLLISION_DYNAMIC"; break;
				case NX_VISUALIZE_COLLISION_FREE:
					param =	"NX_VISUALIZE_COLLISION_FREE"; break;
				case NX_VISUALIZE_COLLISION_CCD:
					param =	"NX_VISUALIZE_COLLISION_CCD"; break;
				case NX_VISUALIZE_COLLISION_SKELETONS:
					param =	"NX_VISUALIZE_COLLISION_SKELETONS";	break;
		#if	NX_USE_FLUID_API
				case NX_VISUALIZE_FLUID_EMITTERS:
					param =	"NX_VISUALIZE_FLUID_EMITTERS"; break;
				case NX_VISUALIZE_FLUID_POSITION:
					param =	"NX_VISUALIZE_FLUID_POSITION"; break;
				case NX_VISUALIZE_FLUID_VELOCITY:
					param =	"NX_VISUALIZE_FLUID_VELOCITY"; break;
				case NX_VISUALIZE_FLUID_KERNEL_RADIUS:
					param =	"NX_VISUALIZE_FLUID_KERNEL_RADIUS";	break;
				case NX_VISUALIZE_FLUID_BOUNDS:
					param =	"NX_VISUALIZE_FLUID_BOUNDS"; break;
		#endif
				case NX_ADAPTIVE_FORCE:
					param =	"NX_ADAPTIVE_FORCE"; break;
				case NX_COLL_VETO_JOINTED:
					param =	"NX_COLL_VETO_JOINTED";	break;
				case NX_TRIGGER_TRIGGER_CALLBACK:
					param =	"NX_TRIGGER_TRIGGER_CALLBACK"; break;
				case NX_SELECT_HW_ALGO:
					param =	"NX_SELECT_HW_ALGO"; break;
				case NX_VISUALIZE_ACTIVE_VERTICES:
					param =	"NX_VISUALIZE_ACTIVE_VERTICES";	break;
				case NX_PARAMS_NUM_VALUES:
					param =	"NX_PARAMS_NUM_VALUES";	break;
				case NX_MIN_SEPARATION_FOR_PENALTY:
					param =	"NX_MIN_SEPARATION_FOR_PENALTY"; break;
				default:
				  assert(0);
				  break;
			}
		
			++mIndent;
			Print("[%s]	%s", param,	getFloatString(v) );
			--mIndent;
		}
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,NxU32	v)
{
	if ( mFph )
	{
		if ( mBinary )
			fwrite(&v, sizeof(NxU32), 1, mFph );
		else
			Print("%s %d", desc, v );
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc, NxScene *scene)
{
	if ( mFph )
	{
		++mIndent;
		Print("%s",	desc);

		NxU32 i;

		// write the scene description first
		WriteSceneDesc(	scene );

		// write material stuff
		const NxU32 count = scene->getNbMaterials();
		WriteUnsigned( "[NbMaterials]",	count );

		if ( count )
		{

			NxSceneDesc sd;
			scene->saveToDesc(sd);

			bool hardwareScene = true;

			if ( sd.simType == NX_SIMULATION_SW ) hardwareScene = false;

			NxMaterial **materials = new NxMaterial *[count];
			memset(materials, 0, sizeof(NxMaterial *)*count );
			NxU32 iterator = 0;
			NxU32 gcount = scene->getMaterialArray(	&materials[0], count, iterator );


			for	( i	= 0; i < count;	++i	)
			{
				NxMaterial *mat	= materials[i];

				char scratch[128];
				sprintf( scratch, "[NxMaterial%d", i+1 );
				++mIndent;
				Write( scratch,	mat, hardwareScene	);
				--mIndent;
			}

			if(materials)
			{
				delete[] materials;
				materials=NULL;
			}
		}

		// write actor stuff
		NxU32 actorCount = scene->getNbActors();
		mNbActors		 = actorCount;
		WriteUnsigned( "[NbActors]", actorCount	);

		if ( actorCount	)
		{
			NxActor	**actors = scene->getActors();
			mActors	= actors;
			for	( i	= 0; i < actorCount; ++i )
			{
				NxActor	*a = actors[i];
				char scratch[512];
			   
				sprintf(scratch,"[NxActor%d]", i+1);
				++mIndent;
				Write( scratch,	a );
				--mIndent;
			}
		}

		// write pairs
		NxU32 pairCount	= scene->getNbPairs();
		WriteInt( "[NbPairs]", pairCount );

		if ( pairCount )
		{
			NxPairFlag *array = new NxPairFlag[pairCount];
			memset(array, 0, pairCount*sizeof(NxPairFlag));
			scene->getPairFlagArray( array,	pairCount );
			for	( i	= 0; i < pairCount;	++i	)
			{
				char scratch[512];
				sprintf(scratch,"[NxPairFlag%d]", i+1 );

				++mIndent;
				Write( scratch,	&array[i] );
				--mIndent;
			}


			if(array!=NULL)
			{
				delete[] array;
				array=NULL;
			}
		}

		// write joints
		NxU32 jointCount = scene->getNbJoints();
		WriteInt( "[NbJoints]",	jointCount );
		if ( jointCount	)
		{
			scene->resetJointIterator();
			for	( i	= 0; i < jointCount; ++i )
			{
				NxJoint	*j = scene->getNextJoint();
				assert(j);
				char scratch[512];
				sprintf(scratch,"[NxJoint%d]", i );

				++mIndent;
				Write(scratch,j);
				--mIndent;
			}
		}

		// now write effectors
		NxU32 effectorCount = scene->getNbEffectors();
		WriteInt( "[NbEffectors]", effectorCount );
		if ( effectorCount )
		{
			scene->resetEffectorIterator();
			for ( i = 0; i < effectorCount; ++i )
			{
				NxEffector *e = scene->getNextEffector();
				assert( e );
				char scratch[512];
				sprintf( scratch,"[NxEffector%d]", i );

				++mIndent;
				Write( scratch, *scene, *e );
				--mIndent;
			}
		}

		if ( 0 )
		{
//#pragma message("TODO: Implement binary core dump	for	'Fluids'")
			//count	= scene->getNbFluids();
		}
		mActors	= 0;
		--mIndent;
	}
}

//==================================================================================
void CoreDump::WriteSceneDesc( NxScene *scene )
{
	// here	we write out the scene description - note that currently we	cannot
	// obtain the scene	description	from a scene, so we	will "fake"	it for now
	if ( mFph && scene )
	{
		Print( "sceneDesc" );
		++mIndent;

		// k, simply get the scene desc with our new call
		NxSceneDesc	desc;
		scene->saveToDesc(desc);

		// now write everything
		WriteBool( "collision_detection", desc.collisionDetection );
		WriteBool( "groundPlane",         desc.groundPlane );
		WriteBool( "boundsPlanes",        desc.boundsPlanes );
		Write( "gravity",                 desc.gravity );
		WriteInt( "broadPhase",           desc.broadPhase );
		WriteInt( "timeStepMethod",	      desc.timeStepMethod );
		WriteFloat(	"maxTimestep",        desc.maxTimestep );
		WriteUnsigned( "maxIter",         desc.maxIter );	
		WriteUnsigned( "simType",         desc.simType );
		WriteUnsigned( "hwSceneType",     desc.hwSceneType );

#if NX_SDK_BRANCH != NX_BRANCH_RELEASE230
		WriteUnsigned( "pipelineSpec",    desc.pipelineSpec );
#endif

		WriteBool( "limits", desc.limits ? true : false );
		if ( desc.limits )
		{
			//
			WriteUnsigned( "limits.maxActors",		  desc.limits->maxNbActors );
			WriteUnsigned( "limits.maxBodies",		  desc.limits->maxNbBodies );
			WriteUnsigned( "limits.maxStaticShapes",  desc.limits->maxNbStaticShapes );
			WriteUnsigned( "limits.maxDynamicShapes", desc.limits->maxNbDynamicShapes	);
			WriteUnsigned( "limits.maxJoints" ,		  desc.limits->maxNbJoints );	
		}

		WriteBool( "maxBounds", desc.maxBounds ? true : false );
		if ( desc.maxBounds )
		{
			if ( mBinary )
			{
				WriteVec3_b( desc.maxBounds->min );
				WriteVec3_b( desc.maxBounds->max );
			}
			else
			{
				Print("%maxBounds->min=(%s,%s,%s)", getFloatString(desc.maxBounds->min.x),
					getFloatString(desc.maxBounds->min.y), getFloatString(desc.maxBounds->min.z) );
				Print("%maxBounds->max=(%s,%s,%s)", getFloatString(desc.maxBounds->max.x),
					getFloatString(desc.maxBounds->max.y), getFloatString(desc.maxBounds->max.z) );
			}
		}

		// write out pntr members, but only if ASCII, as we won't know what the heck they
		// are (they are user-defined)
		if ( !mBinary )
		{
			Print( "NxUserNotify Present = %s", desc.userNotify ? "true" : "false" );
			Print( "NxUserTriggerReport Present = %s", desc.userTriggerReport ? "true" : "false" );
			Print( "NxUserContactReport Present = %s", desc.userContactReport ? "true" : "false" );
			Print( "userData Present = %s", desc.userData ? "true" : "false" );
		}

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxVec3 &v)
{
	if ( mFph )
	{
		if ( mBinary )
		{
			//WriteVec3_b( v );
			WriteFloat_b( v.x );
			WriteFloat_b( v.y );
			WriteFloat_b( v.z );
		}
		else
		{
			Print("%s=%s,%s,%s", desc, getFloatString(v.x),	getFloatString(v.y), getFloatString(v.z) );
		}
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxBodyDesc *b)
{
	if ( mFph )
	{
		// indicate whether it has a body or not
		char buff[128];
		sprintf( buff, "Body Desc Present = %s", b ? "true" : "false" );
		WriteBool( buff, b ? true : false );

		if ( b )
		{
			Print("body=DYNAMIC");
			++mIndent;

			Write( "massLocalPose",                b->massLocalPose );
			Write( "massSpaceInertia",             b->massSpaceInertia );
			WriteFloat(	"mass",	                   b->mass );
			Write( "linearVelocity",               b->linearVelocity );
			Write( "angularVelocity",              b->angularVelocity );
			WriteFloat(	"wakeUpCounter",           b->wakeUpCounter );
			WriteFloat(	"linearDamping",           b->linearDamping );
			WriteFloat(	"angularDamping",          b->angularDamping );
			WriteFloat(	"maxAngularVelocity",      b->maxAngularVelocity );
			WriteFloat(	"CCDMotionThreshold",      b->CCDMotionThreshold );
			WriteFloat(	"sleepLinearVelocity",     b->sleepLinearVelocity );
			WriteFloat(	"sleepAngularVelocity",	   b->sleepAngularVelocity );
			WriteUnsigned( "solverIterationCount", b->solverIterationCount );

			if ( mBinary )
			{
				WriteFlag_b( b->flags );
			}
			else
			{
				PrintFlag(b->flags,"NX_BF_DISABLE_GRAVITY",NX_BF_DISABLE_GRAVITY);
				PrintFlag(b->flags,"NX_BF_FROZEN_POS_X",NX_BF_FROZEN_POS_X);
				PrintFlag(b->flags,"NX_BF_FROZEN_POS_Y",NX_BF_FROZEN_POS_Y);
				PrintFlag(b->flags,"NX_BF_FROZEN_POS_Z",NX_BF_FROZEN_POS_Z);
				PrintFlag(b->flags,"NX_BF_FROZEN_ROT_X",NX_BF_FROZEN_ROT_X);
				PrintFlag(b->flags,"NX_BF_FROZEN_ROT_Y",NX_BF_FROZEN_ROT_Y);
				PrintFlag(b->flags,"NX_BF_FROZEN_ROT_Z",NX_BF_FROZEN_ROT_Z);
				PrintFlag(b->flags,"NX_BF_KINEMATIC",NX_BF_KINEMATIC);
				PrintFlag(b->flags,"NX_BF_VISUALIZATION",NX_BF_VISUALIZATION);
			}

			--mIndent;
		}
		else
		{
			Print("body=NULL");
		}
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxMat34	&p)
{
	if ( mFph )
	{
		NxReal m[9];
		p.M.getRowMajor( m );

		if ( mBinary )
		{
			// k, write	out	the	matrix
			for	( int i	= 0; i < 9;	++i	)
			{
				WriteFloat_b( m[i] );
			}
			WriteFloat_b( p.t.x	);
			WriteFloat_b( p.t.y	);
			WriteFloat_b( p.t.z	);
		}
		else
		{
			NxReal m[9];
			p.M.getRowMajor(m);
			Print("%s=%s,%s,%s	%s,%s,%s  %s,%s,%s	%s,%s,%s", desc, getFloatString(m[0]), getFloatString(m[1]), getFloatString(m[2]),	 getFloatString(m[3]), getFloatString(m[4]), getFloatString(m[5]),	getFloatString(m[6]), getFloatString(m[7]),	getFloatString(m[8]),  getFloatString(p.t.x), getFloatString(p.t.y), getFloatString(p.t.z) );
		}
	}
}

//==================================================================================
void CoreDump::PrintFlag(unsigned int state,const char *desc,unsigned int flag)
{
	if ( !mBinary )
	{
		if ( state & flag )
			Print("%s=true", desc );
		else
			Print("%s=false", desc );
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc, NxActor *a)
{
	if ( mFph )
	{
		NxActorDesc	actorDesc;
		NxBodyDesc descbody;
		NxBodyDesc *bodyDescPntr = 0;

		// print out description
		Print("%s",	desc);

		// indent
		++mIndent;

		// k, does this	have a dynamic body?
		if ( a->saveBodyToDesc(descbody) )
		{
			// yes,	save off the body description
			bodyDescPntr = &descbody;
		}

		// get actor description
		a->saveToDesc( actorDesc );


		if ( bodyDescPntr && ( bodyDescPntr->CCDMotionThreshold < 0 ) )
		{
			bodyDescPntr->CCDMotionThreshold	= 0;
		}

		// k, time to write	all	information	- first	write matrix
		Write( "globalPose", actorDesc.globalPose );

		// write body description
		Write( "[body]", bodyDescPntr );

		// k, this is a	HACK - if you take a look in NxBodyDesc::isValidInternal(),	there is a check to	make sure
		// that	a body description does	NOT	have both a	mass and density (actually is a	little more	involved),
		// so we HACK it here to zero out the density if we	have a body	and	it has a mass
		float density =	actorDesc.density;
		if ( bodyDescPntr && ( bodyDescPntr->mass >	0 )	)
		{
			// gotta make sure the density is 0
			density	= 0;
		}

		WriteFloat(	"density", density );


		// write the actor's group
		WriteInt( "group", actorDesc.group );

		char buff[128];
		if ( mBinary )
		{
			// write flags
			WriteFlag_b( actorDesc.flags );

			// also place name in the buffer
			sprintf( buff, a->getName()	? a->getName() : "null"	);
		}
		else
		{
			// write flags
			PrintFlag( actorDesc.flags,	"NX_AF_DISABLE_COLLISION", NX_AF_DISABLE_COLLISION );
			PrintFlag( actorDesc.flags,	"NX_AF_DISABLE_RESPONSE",  NX_AF_DISABLE_RESPONSE );

#if	NX_USE_FLUID_API
			PrintFlag( actorDesc.flags,	"NX_AF_FLUID_DISABLE_COLLISION", NX_AF_FLUID_DISABLE_COLLISION );
			PrintFlag( actorDesc.flags,	"NX_AF_FLUID_ACTOR_REATION", NX_AF_FLUID_ACTOR_REACTION	);
#endif			  
			// also place name in the buffer
			sprintf( buff, "name=\"%s\"", a->getName() ? a->getName() :	"null" );
		}
		WriteString( buff );

		// now write the # of shapes
		NxU32 numActorShapes		= a->getNbShapes();
		NxShape* const*	actorShapes	= a->getShapes();
		WriteInt( "[NbShapes]",	numActorShapes );
		++mIndent;

		// write out each shape
		for	( NxU32	i=0; i<numActorShapes; ++i )
		{
			NxShape	*shape = actorShapes[i];
			Write("NxShape",shape);
		}
		--mIndent;
		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxShapeDesc	&d,const NxShape *shape)
{
	if ( mFph )
	{
		// write out local pose
		Write( "localPose",	d.localPose	);

		// write group, material index, mass, density and skin width
		WriteInt( "group", d.group );
		WriteInt( "materialIndex", d.materialIndex );
		WriteFloat(	"mass",	d.mass );
		WriteFloat(	"density", d.density );
		WriteFloat(	"skinWidth", d.skinWidth );

		// k, write out rest of data
		char scratch[218];
		if ( mBinary )
		{
			WriteFlag_b( d.shapeFlags );

			WriteInt_b(	 reinterpret_cast<int>(	d.ccdSkeleton )	);

#ifdef NX_SUPPORT_NEW_FILTERING
			//!< Groups	bitmask	for	collision filtering
			WriteUnsigned_b( d.groupsMask.bits0	);
			WriteUnsigned_b( d.groupsMask.bits1	);
			WriteUnsigned_b( d.groupsMask.bits2	);
			WriteUnsigned_b( d.groupsMask.bits3	);
#endif
			sprintf( scratch, shape->getName() ? shape->getName() :	"null" );
		}
		else
		{
			PrintFlag(d.shapeFlags,"NX_TRIGGER_ON_ENTER",	NX_TRIGGER_ON_ENTER	);
			PrintFlag(d.shapeFlags,"NX_TRIGGER_ON_LEAVE",	NX_TRIGGER_ON_LEAVE	);
			PrintFlag(d.shapeFlags,"NX_TRIGGER_ON_STAY",	NX_TRIGGER_ON_STAY );
			PrintFlag(d.shapeFlags,"NX_TRIGGER_ENABLE",	NX_TRIGGER_ENABLE );

			PrintFlag(d.shapeFlags,"NX_SF_VISUALIZATION",	NX_SF_VISUALIZATION	);
			PrintFlag(d.shapeFlags,"NX_SF_DISABLE_COLLISION",	NX_SF_DISABLE_COLLISION	);

			PrintFlag(d.shapeFlags,"NX_SF_FEATURE_INDICES",	NX_SF_FEATURE_INDICES );
			PrintFlag(d.shapeFlags,"NX_SF_DISABLE_RAYCASTING",	NX_SF_DISABLE_RAYCASTING );
			PrintFlag(d.shapeFlags,"NX_SF_POINT_CONTACT_FORCE",	NX_SF_POINT_CONTACT_FORCE );
			PrintFlag(d.shapeFlags,"NX_SF_DISABLE_RESPONSE",	NX_SF_DISABLE_RESPONSE );

#if	NX_USE_FLUID_API
			PrintFlag(d.shapeFlags,"NX_SF_FLUID_DRAIN",	NX_SF_FLUID_DRAIN );
			PrintFlag(d.shapeFlags,"NX_SF_FLUID_DRAIN_INVERT",	NX_SF_FLUID_DRAIN_INVERT );
			PrintFlag(d.shapeFlags,"NX_SF_FLUID_DISABLE_COLLISION",	NX_SF_FLUID_DISABLE_COLLISION );
			PrintFlag(d.shapeFlags,"NX_SF_FLUID_ACTOR_REACTION",	NX_SF_FLUID_ACTOR_REACTION );
#endif

			if ( d.ccdSkeleton )
				Print("ccdSkeleton=ccdSkeleton%d", GetSkeletonIndex(d.ccdSkeleton)+1 );
			else
				Print("ccdSkeleton=NULL");

#ifdef NX_SUPPORT_NEW_FILTERING
			Print("groupsMask=0x%08", d.groupsMask );
#endif

			sprintf( scratch, "name=\"%s\"", shape->getName() ?	shape->getName() : "null" );
		}
		WriteString( scratch );
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc, const NxShape *shape)
{
	if ( mFph )
	{
		// indicate whether it has a shape or not
		char buff[128];
		sprintf( buff, "Shape Present = %s", shape ? "true" : "false" );
		WriteBool( buff, shape ? true : false );

		if ( shape )
		{
			Print("%s=%s", desc, getString(	shape->getType() ) );
			++mIndent;

			// get the type
			NxShapeType	type = shape->getType();

			// should we write out the description?	 For now am	NOT	doing so.
			//WriteString( "shapeDesc=", getString(	type ) );

			// k, got to write the type	first
			WriteInt( "type	= ", type );
					
			// now write out shape type	specific params
			switch(	type )
			{
				case NX_SHAPE_PLANE:
				{
					const NxPlaneShape *current	= shape->isPlane();
					NxPlaneShapeDesc desc;
					assert(	current	);
					current->saveToDesc( desc );
					Write("PlaneShapeDesc",	desc, shape	);

					if ( mBinary )
					{
						// now write plane shape desc specific params
						WriteVec3_b( desc.normal );
						WriteFloat_b( desc.d );
					}
					else
					{
						Print("plane=%s,%s,%s,%s", getFloatString(desc.normal.x), getFloatString(desc.normal.y), getFloatString(desc.normal.z),	getFloatString(desc.d) );
					}
				}
				break;

				case NX_SHAPE_SPHERE:
				{
					const NxSphereShape	*current = shape->isSphere();
					NxSphereShapeDesc desc;
					assert(	current	);
					current->saveToDesc( desc );
					Write("SphereShapeDesc", desc, shape );

					WriteFloat(	"radius", desc.radius );
				}
				break;

				case NX_SHAPE_BOX:
				{
					const NxBoxShape *current =	shape->isBox();
					NxBoxShapeDesc desc;
					assert(	current	);
					current->saveToDesc( desc );
					Write("BoxShapeDesc", desc,	shape );

					// now write its dimensions
					Write( "BoxDimensions",	desc.dimensions	);
				}
				break;

				case NX_SHAPE_CAPSULE:
				{
					const NxCapsuleShape *current =	shape->isCapsule();
					NxCapsuleShapeDesc desc;
					assert(	current	);
					current->saveToDesc( desc );
					Write("CapsuleShapeDesc", desc,	shape );

					WriteFloat(	"radius", desc.radius );
					WriteFloat(	"height", desc.height );
					WriteFlag( "flags",	  desc.flags );
				}
				break;

				case NX_SHAPE_CONVEX:
				{
					const NxConvexShape	*current = shape->isConvexMesh();
					NxConvexShapeDesc desc;
					assert(	current	);
					current->saveToDesc( desc );
					Write("ConvexShapeDesc", desc, shape );

					// write its flags
					WriteInt( "meshFlags", desc.meshFlags );

#ifdef NX_SUPPORT_CONVEX_SCALE
					// write scale
					WriteFloat(	"scale", desc.scale	);
#endif

					// k, get its index	into the array of convex meshes!
					int	index =	GetConvexIndex(	desc.meshData );

					if ( mBinary )
					{
						//WriteUnsigned_b( reinterpret_cast<int>( desc.meshData	) );
						WriteInt_b(	index );
					}
					else
					{
						if ( desc.meshData )
							Print("meshData=ConvexMesh%d", index+1 );
						else
							Print("meshData=NULL");
					}
				}
				break;

				case NX_SHAPE_MESH:
				{
					const NxTriangleMeshShape *current = shape->isTriangleMesh();
					NxTriangleMeshShapeDesc	desc;
					assert(	current	);
					current->saveToDesc( desc );
					Write("TriMeshShapeDesc", desc,	shape );

					// write its flags
					WriteInt( "meshFlags", desc.meshFlags );

#ifdef NX_SUPPORT_CONVEX_SCALE
					// write scale
					WriteFloat(	"scale", desc.scale	);
#endif

					// k, this is bad, as it writes	a pntr to data in memory ...
					int	index =	GetTriangleMeshIndex( desc.meshData	);

					if ( mBinary )
					{
						//WriteUnsigned_b( reinterpret_cast<int>( desc.meshData	) );
						WriteInt_b(	index );
					}
					else
					{
						if ( desc.meshData )
							Print("meshData=TriangleMesh%d", index+1 );
						else
							Print("meshData=NULL");
					}
				}
				break;

				case NX_SHAPE_COMPOUND:
					assert(	0 );
				break;

				default:
					assert(0); //!!???
				break;
			}

			--mIndent;
		}
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc, NxPairFlag *p)
{
	if ( mFph && p )
	{
		Print("%s",	desc);
		++mIndent;

		int	actorIndex1	= -1, shapeIndex1 =	-1;
		int	actorIndex2	= -1, shapeIndex2 =	-1;

		if ( p->isActorPair() )
		{
			const NxActor *a1 = (const NxActor *) p->objects[0];
			const NxActor *a2 = (const NxActor *) p->objects[1];
		  actorIndex1 = GetActorIndex(a1);
		  actorIndex2 = GetActorIndex(a2);
		  assert(	actorIndex1 >= 0 );
		  assert(	actorIndex2 >= 0 );
		}
		else
		{

			const NxShape *s1 = (const NxShape *) p->objects[0];
			const NxShape *s2 = (const NxShape *) p->objects[1];

			const NxActor *a1 = &s1->getActor();
			const NxActor *a2 = &s2->getActor();

		  actorIndex1 = GetActorIndex(a1);
		  actorIndex2 = GetActorIndex(a2);

  		shapeIndex1 = GetShapeIndex(a1,s1);
			shapeIndex2 = GetShapeIndex(a2,s2);
	
			assert(actorIndex1 >= 0);	
		  assert(actorIndex2 >= 0);
			assert(shapeIndex1>=0);
			assert(shapeIndex2>=0);

		}

		// write the flag
		WriteFlag( "pairFlag", p->flags	);

		// now,	we need	pntrs to the actors	as well!
		WriteInt( "ActorIndex1", actorIndex1 );
		WriteInt( "ShapeIndex1", shapeIndex1 );
		WriteInt( "ActorIndex2", actorIndex2 );
		WriteInt( "ShapeIndex2", shapeIndex2 );

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,NxSpringDesc *spring)
{
	if ( mFph )
	{
		Print("%s",	desc );
		++mIndent;

		// indicate whether it has a spring desc or not
		char buff[128];
		sprintf( buff, "Spring Desc Present = %s", spring ? "true" : "false" );
		WriteBool( buff, spring ? true : false );

		if ( spring	)
		{
			WriteFloat(	"spring_spring", spring->spring	);
			WriteFloat(	"spring_damper", spring->damper	);
			WriteFloat(	"spring_targetValue", spring->targetValue );
		}

		--mIndent;		  
	}
}

//==================================================================================
void CoreDump::Write(const char	*descrip, NxMaterial *m,bool hardwareScene)
{
	if ( mFph )
	{
		Print("%s",	descrip);
		++mIndent;

		NxMaterialDesc desc;
		if ( m )
		{
		  m->saveToDesc(desc);
			if ( hardwareScene )
			{
				desc.dynamicFriction = 0.5f;
				desc.staticFriction  = 0.5f;
				desc.restitution     = 0.2f;
			}
		}
		else
		{
			desc.staticFriction = 0.5f;
			desc.dynamicFriction = 0.5f;
			desc.restitution = 0.2f;
		}

		// write material props
		WriteFloat(	"dynamicFriction",	desc.dynamicFriction );
		WriteFloat(	"staticFriction",	desc.staticFriction	);
		WriteFloat(	"restitution",		desc.restitution );
		WriteFloat(	"dynamicFrictionV",	desc.dynamicFrictionV );
		WriteFloat(	"staticFrictionV",	desc.staticFrictionV );

		// write combine modes
		WriteInt( "frictionCombineMode",	desc.frictionCombineMode );
		WriteInt( "restitutionCombineMode",	desc.restitutionCombineMode	);

		if ( mBinary )
		{
			WriteFloat_b( desc.dirOfAnisotropy.x );
			WriteFloat_b( desc.dirOfAnisotropy.y );
			WriteFloat_b( desc.dirOfAnisotropy.z );
		
			// write the flags
			WriteFlag_b( desc.flags	);
		}
		else
		{
			Print("%s=%s,%s,%s", "dirOfAnistotropy", 
				getFloatString(desc.dirOfAnisotropy.x),	
				getFloatString(desc.dirOfAnisotropy.y),
				getFloatString(desc.dirOfAnisotropy.z));

			if ( desc.flags	& NX_MF_ANISOTROPIC	)
				Print("NX_MF_ANISOTROPIC=true");
			else
				Print("NX_MF_ANISOTROPIC=false");

			if ( desc.flags	& NX_MF_SPRING_CONTACT )
				Print("NX_MF_SPRING_CONTACT=true");
			else
				Print("NX_MF_SPRING_CONTACT=false");
		}

		// does	it have	a spring description?
		char scratch[512];
		if ( desc.spring )
		{
			sprintf( scratch, "spring=TRUE"	);
		}
		else
		{
			sprintf( scratch, "spring=NULL"	);
		}
		Write( scratch,	desc.spring	);

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(NxJointDesc *d, NxJoint *j)
{
	if ( mFph )
	{
		Print("[NxJointDesc]");
		++mIndent;

		// write joint type
		if ( mBinary )
		{
			int	intVal = d->getType();
			WriteInt_b(	intVal );
		}
		else
		{
			Print("type=%s", getString(	d->getType() ) );
		}

		int	index;			
		 //	write actor	indexes
		index =	mBinary	? GetActorIndex(d->actor[0]) : GetActorIndex(d->actor[0])+1;
		WriteInt( "actor1 =	NxActor", index	);
		index =	mBinary	? GetActorIndex(d->actor[1]) : GetActorIndex(d->actor[1])+1;
		WriteInt( "actor2 =	NxActor", index	);
			
		// write normal, axis, anchor (both	1 and 2)
		Write("localNormal1", d->localNormal[0]	);
		Write("localAxis1",	  d->localAxis[0] );
		Write("localAnchor1", d->localAnchor[0]	);

		Write("localNormal2", d->localNormal[1]	);
		Write("localAxis2",	  d->localAxis[1] );
		Write("localAnchor2", d->localAnchor[1]	);

		// write force and torque
		WriteFloat(	"maxForce",	d->maxForce	);
		WriteFloat(	"maxTorque", d->maxTorque );

		if ( mBinary )
		{
			// write its name
			WriteString( j->getName() );

			// write its flags
			WriteFlag( "joint flags", d->jointFlags	);
		}
		else
		{
#if	0
			Print("name=%s", d->name );
#else
			Print("name=\"%s\"", j->getName() );
#endif

			PrintFlag(d->jointFlags, "NX_JF_COLLISION_ENABLED",	NX_JF_COLLISION_ENABLED	);
			PrintFlag(d->jointFlags, "NX_JF_VISUALIZATION",	NX_JF_VISUALIZATION	);
		}

		// in addition, we also have to write out its limit planes!
		j->resetLimitPlaneIterator();
		if ( j->hasMoreLimitPlanes() )
		{
			NxVec3 planeNormal;
			NxVec3 planeLimitPt;
			NxVec3 worldLimitPt;
			NxReal planeD;
			int numLimitPlanes = 0;
			char buff[128];
			bool ok = true;

			while ( ok )
			{
				j->getNextLimitPlane( planeNormal, planeD );
				++numLimitPlanes;
				ok = j->hasMoreLimitPlanes();
			}
			// k, write # of limit planes, then write them!
			WriteInt( "NumLimitPlanes", numLimitPlanes );

			// write limit point
			bool onActor2 = j->getLimitPoint( planeLimitPt );
			Write( "PlaneLimitPoint", planeLimitPt );
			WriteBool( "PlaneLimitPointOnActor2", onActor2 );

			// write the plane normals
			j->resetLimitPlaneIterator();
			for ( int iter = 0; iter < numLimitPlanes; ++iter )
			{
				j->getNextLimitPlane( planeNormal, planeD );
				sprintf( buff, "[LimitPlane%d]", iter+1);
				Print( buff );
				++mIndent;
				sprintf( buff, "planeNormal%d", iter+1 );
				Write( buff, planeNormal );
				sprintf( buff, "planeD%d", iter+1 );
				WriteFloat( buff, planeD );

				// now determine the world limit point
				// note that planeD = -(planeNormal) DOT (worldLimitPt)
				// try choosing x,y = 0 for world limit pt, which makes it
				// worldLimitPt.z = planeD / -planeNormal.z
				if ( fabs(planeNormal.z) > 0.001f )
				{
					worldLimitPt.x = planeLimitPt.x;
					worldLimitPt.y = planeLimitPt.y;
					worldLimitPt.z = -planeD / planeNormal.z;
				}
				// k, that didn't work - try x,z = 0
				else if ( fabs(planeNormal.y) > 0.001f )
				{
					worldLimitPt.x = planeLimitPt.x;
					worldLimitPt.z = planeLimitPt.z;
					worldLimitPt.y = -planeD / planeNormal.y;
				}
				else if ( fabs(planeNormal.x) > 0.001f )
				{
					worldLimitPt.y = planeLimitPt.y;
					worldLimitPt.z = planeLimitPt.z;
					worldLimitPt.x = -planeD / planeNormal.x;
				}
				else
				{
					assert( false );
				}
				sprintf( buff, "worldLimitPt%d", iter+1 );
				Write( buff, worldLimitPt );
				--mIndent;
			}
		}
		else
		{
			WriteInt( "NumLimitPlanes", 0 );
		}

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write( NxPrismaticJointDesc *desc, NxJoint *j )
{
	Print("[NxPrismaticJointDesc]");
	++mIndent;

	// always save out basic joint info	- that is ALL for this joint!
	Write( (NxJointDesc	*)desc,	j );

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxRevoluteJointDesc *desc, NxJoint *j	)
{
	Print("[NxRevoluteJointDesc]");
	++mIndent;

	// always save out basic joint info
	Write( (NxJointDesc	*)desc,	j );

	// now save	out	specific information - start with low/high limits
	WriteFloat(	"limit_low_hardness",	  desc->limit.low.hardness );
	WriteFloat(	"limit_low_restitution",  desc->limit.low.restitution );
	WriteFloat(	"limit_low_value",		  desc->limit.low.value	);
	WriteFloat(	"limit_high_hardness",	  desc->limit.high.hardness	);
	WriteFloat(	"limit_high_restitution", desc->limit.high.restitution );
	WriteFloat(	"limit_high_value",		  desc->limit.high.value );

	// save	out	motor description
	WriteBool( "motor_freeSpin",	  desc->motor.freeSpin ? true :	false );
	WriteFloat(	"motor_maxForce",	  desc->motor.maxForce );
	WriteFloat(	"motor_velTarget",	  desc->motor.velTarget	);

	// save	out	spring desc
	WriteFloat(	"spring_spring",	  desc->spring.spring );
	WriteFloat(	"spring_damper",	  desc->spring.damper );
	WriteFloat(	"spring_targetValue", desc->spring.targetValue );

	// save	out	reset
	WriteFloat(	"projectionDistance", desc->projectionDistance );
	WriteFloat(	"projectionAngle",	  desc->projectionAngle	);
	WriteFlag( "flags",				  desc->flags );

	if ( mBinary )
	{
		WriteUnsigned( "projectionMode", desc->projectionMode );
	}
	else
	{
		if ( desc->projectionMode == NX_JPM_NONE )
		{
			Print( "projectionMode = NX_JPM_NONE" );
		}
		else if	( desc->projectionMode == NX_JPM_POINT_MINDIST )
		{
			Print( "projectionMode = NX_JPM_POINT_MINDIST" );
		}
		else
		{
			Print( "projectionMode = ??Unknown??" );
		}
	}

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxCylindricalJointDesc *desc,	NxJoint	*j )
{
	Print("[NxCylindricalJointDesc]");
	++mIndent;

	// always save out basic joint info	- that is ALL for this joint!
	Write( (NxJointDesc	*)desc,	j );

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxSphericalJointDesc *desc, NxJoint *j )
{
	Print("[NxSphericalJointDesc]");
	++mIndent;

	// always save out basic joint info
	Write( (NxJointDesc	*)desc,	j );

	// save	out	spring descs
	WriteFloat(	"twistSpring_spring",	   desc->twistSpring.spring	);
	WriteFloat(	"twistSpring_damper",	   desc->twistSpring.damper	);
	WriteFloat(	"twistSpring_targetValue", desc->twistSpring.targetValue );
	WriteFloat(	"swingSpring_spring",	   desc->swingSpring.spring	);
	WriteFloat(	"swingSpring_damper",	   desc->swingSpring.damper	);
	WriteFloat(	"swingSpring_targetValue", desc->swingSpring.targetValue );
	WriteFloat(	"jointSpring_spring",	   desc->jointSpring.spring	);
	WriteFloat(	"jointSpring_damper",	   desc->jointSpring.damper	);
	WriteFloat(	"jointSpring_targetValue", desc->jointSpring.targetValue );

	// projection dist
	WriteFloat(	"projectionDistance", desc->projectionDistance );

	// other limits	(twist and swing)
	WriteFloat(	"twistLimit_low_hardness",	   desc->twistLimit.low.hardness );
	WriteFloat(	"twistLimit_low_restitution",  desc->twistLimit.low.restitution	);
	WriteFloat(	"twistLimit_low_value",		   desc->twistLimit.low.value );
	WriteFloat(	"twistLimit_high_hardness",	   desc->twistLimit.high.hardness );
	WriteFloat(	"twistLimit_high_restitution", desc->twistLimit.high.restitution );
	WriteFloat(	"twistLimit_high_value",	   desc->twistLimit.high.value );

	WriteFloat(	"swingLimit_hardness",		   desc->swingLimit.hardness );
	WriteFloat(	"swingLimit_restitution",	   desc->swingLimit.restitution	);
	WriteFloat(	"swingLimit_value",			   desc->swingLimit.value );

	// flags
	WriteFlag( "desc->flags", desc->flags );

	if ( mBinary )
	{
		// swing axis
		WriteFloat(	"swingAxis.x", desc->swingAxis.x );
		WriteFloat(	"swingAxis.y", desc->swingAxis.y );
		WriteFloat(	"swingAxis.z", desc->swingAxis.z );

		// projection mode
		WriteUnsigned( "projectionMode", desc->projectionMode );
	}
	else
	{
		// swing axis
		Print( "swingAxis =	(%f, %f, %f)", desc->swingAxis.x, desc->swingAxis.y, desc->swingAxis.z );

		// projection mode
		if ( desc->projectionMode == NX_JPM_NONE )
		{
			Print( "projectionMode = NX_JPM_NONE" );
		}
		else if	( desc->projectionMode == NX_JPM_POINT_MINDIST )
		{
			Print( "projectionMode = NX_JPM_POINT_MINDIST" );
		}
		else
		{
			Print( "projectionMode = ??Unknown??" );
		}
	}

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxPointOnLineJointDesc *desc,	NxJoint	*j )
{
	Print("[NxPointOnLineJointDesc]");
	++mIndent;

	// always save out basic joint info	- that is ALL for this joint!
	Write( (NxJointDesc	*)desc,	j );

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxPointInPlaneJointDesc *desc, NxJoint *j	)
{
	Print("[NxPointInPlaneJointDesc]");
	++mIndent;

	// always save out basic joint info	- that is ALL for this joint!
	Write( (NxJointDesc	*)desc,	j );

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxDistanceJointDesc *desc, NxJoint *j	)
{
	Print("[NxDistanceJointDesc]");
	++mIndent;

	// always save out basic joint info
	Write( (NxJointDesc	*)desc,	j );

	// min/max dist
	WriteFloat(	"minDistance", desc->minDistance );
	WriteFloat(	"maxDistance", desc->maxDistance );

	// flags
	WriteFlag( "flags",	desc->flags	);

	// spring desc
	WriteFloat(	"spring_spring",	  desc->spring.spring );
	WriteFloat(	"spring_damper",	  desc->spring.damper );
	WriteFloat(	"spring_targetValue", desc->spring.targetValue );

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxPulleyJointDesc	*desc, NxJoint *j )
{
	 Print("[NxPulleyJointDesc]");
	++mIndent;

	// always save out basic joint info
	Write( (NxJointDesc	*)desc,	j );

	// params
	WriteFloat(	"distance",	 desc->distance	);
	WriteFloat(	"stiffness", desc->stiffness );
	WriteFloat(	"ratio",	 desc->ratio );
	WriteFlag( "flags",		 desc->flags );

	// motor desc
	WriteBool( "motor_freeSpin",   desc->motor.freeSpin	? true : false );
	WriteFloat(	"motor_maxForce",  desc->motor.maxForce	);
	WriteFloat(	"motor_velTarget", desc->motor.velTarget );

	// and pulley info
	if ( mBinary )
	{
		WriteFloat(	"pulley0.x", desc->pulley[0].x );
		WriteFloat(	"pulley0.y", desc->pulley[0].y );
		WriteFloat(	"pulley0.z", desc->pulley[0].z );
		WriteFloat(	"pulley1.x", desc->pulley[1].x );
		WriteFloat(	"pulley1.y", desc->pulley[1].y );
		WriteFloat(	"pulley1.z", desc->pulley[1].z );
	}
	else
	{
		Print( "desc->pulley0 =	(%f, %f, %f)", desc->pulley[0].x, desc->pulley[0].y, desc->pulley[0].z );
		Print( "desc->pulley1 =	(%f, %f, %f)", desc->pulley[1].x, desc->pulley[1].y, desc->pulley[1].z );
	}

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxFixedJointDesc *desc, NxJoint *j )
{
	Print("[NxFixedJointDesc]");
	++mIndent;

   // always save out basic	joint info - that is ALL for this joint!
	Write( (NxJointDesc	*)desc,	j );

	--mIndent;
}

//==================================================================================
void CoreDump::Write( NxD6JointDesc	*desc, NxJoint *j )
{
	Print( "[NxD6JointDesc]" );
	++mIndent;

	// always save out basic joint info
	Write( (NxJointDesc	*)desc,	j );

	// now save	out	joint specific info
	WriteUnsigned( "xMotion",		  desc->xMotion	);
	WriteUnsigned( "yMotion",		  desc->yMotion	);
	WriteUnsigned( "zMotion",		  desc->zMotion	);
	WriteUnsigned( "swing1Motion",	  desc->swing1Motion );
	WriteUnsigned( "swing2Motion",	  desc->swing2Motion );
	WriteUnsigned( "twistMotion",	  desc->twistMotion	);

	Write( "[linearLimit]",		   desc->linearLimit );
	Write( "[swing1Limit]",		   desc->swing1Limit );
	Write( "[swing2Limit]",		   desc->swing2Limit );
	Write( "[twistLimit]",		   desc->twistLimit	);
	Write( "[xDrive]",			   desc->xDrive	);
	Write( "[yDrive]",			   desc->yDrive	);
	Write( "[zDrive]",			   desc->zDrive	);
	Write( "[swingDrive]",		   desc->swingDrive	);
	Write( "[twistDrive]",		   desc->twistDrive	);
	Write( "[slerpDrive]",		   desc->slerpDrive	);
	Write( "drivePosition",		   desc->drivePosition );
	Write( "driveOrientation",	   desc->driveOrientation );
	Write( "driveLinearVelocity",  desc->driveLinearVelocity );
	Write( "driveAngularVelocity", desc->driveAngularVelocity );

	WriteUnsigned( "projectionMode",  desc->projectionMode );
	WriteFloat(	"projectionDistance", desc->projectionDistance );
	WriteFloat(	"projectionAngle",	  desc->projectionAngle	);
	WriteFloat(	"gearRatio",		  desc->gearRatio );

	if ( mBinary )
	{
		// change to write flag
		WriteFlag_b( desc->flags );
	}
	else
	{
		PrintFlag( desc->flags,	"NX_D6JOINT_SLERP_DRIVE", NX_D6JOINT_SLERP_DRIVE );
		PrintFlag( desc->flags,	"NX_D6JOINT_GEAR_ENABLED", NX_D6JOINT_GEAR_ENABLED );
	}
	--mIndent;
}

//==================================================================================
void CoreDump::Write( const	char *desc,	const NxJointLimitSoftDesc &l )
{
	if ( mFph )
	{
		Print("%s",	desc );
		++mIndent;

		WriteFloat("values",	  l.value );
		WriteFloat("restitution", l.restitution	);
		WriteFloat("spring",	  l.spring );
		WriteFloat("damping",	  l.damping	);

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxJointDriveDesc &d)
{
	if ( mFph )
	{
		Print("%s",	desc );
		++mIndent;

		WriteFloat(	"spring", d.spring );
		WriteFloat(	"damping", d.damping );
		WriteFloat(	"forceLimit", d.forceLimit );

		if ( mBinary )
		{
			WriteFlag_b( d.driveType.bitField );
		}
		else
		{
			if ( d.driveType.getFlag(NX_D6JOINT_DRIVE_POSITION)	)
				Print("NX_D6JOINT_DRIVE_POSITION=true");
			else
				Print("NX_D6JOINT_DRIVE_POSITION=false");

			if ( d.driveType.getFlag(NX_D6JOINT_DRIVE_VELOCITY)	)
				Print("NX_D6JOINT_DRIVE_VELOCITY=true");
			else
				Print("NX_D6JOINT_DRIVE_VELOCITY=false");
		}

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write( const char *desc, NxScene &scene, NxEffector &e )
{
	if ( mFph )
	{
		Print("%s",	desc );
		++mIndent;

		// k, which scene does this belong to (uh, it better belong to the one
		// that we asked it for!)?
		NxScene &nxscene = e.getScene();
		assert( &nxscene == &scene );
		
		// now, is this a spring and damper effector?
		NxSpringAndDamperEffector *sade = e.isSpringAndDamperEffector();
		WriteBool( "isSpringAndDamperEffector", (sade != 0) );
		if ( sade )
		{
			// k, get the spring and damper effector desc
			NxSpringAndDamperEffectorDesc desc;
			desc.setToDefault();

			// get the effector description
			sade->saveToDesc( desc );

			// get the actors from the pntrs
			int actorIndex1 = -1, actorIndex2 = -1;
			if ( desc.body1 )
			{
				actorIndex1 = GetActorIndex( desc.body1 );
			}
			if ( desc.body2 )
			{
				actorIndex2 = GetActorIndex( desc.body2 );
			}

			// save out actor indexes
			WriteInt( "actorIndex1", actorIndex1 );
			WriteInt( "actorIndex2", actorIndex2 );

			// k, we currently cannot write who these things are connected
			// to, but we will write out their world matrices
			Write( "jointConnectionPos1", desc.pos1 );
			Write( "jointConnectionPos2", desc.pos2 );

			// k, now we write information about the linear spring
			Print( "LinearSpringInfo" );
			++mIndent;
			WriteFloat( "distCompessSaturate", desc.springDistCompressSaturate );
			WriteFloat( "distRelaxed",         desc.springDistRelaxed );
			WriteFloat( "distStretchSaturate", desc.springDistStretchSaturate );
			WriteFloat( "maxCompressForce",    desc.springMaxCompressForce );
			WriteFloat( "maxStretchForce",     desc.springMaxStretchForce );
			--mIndent;

			// k, now we write information about the linear damper
			Print( "LinearDamperInfo" );
			++mIndent;
			WriteFloat( "velCompressSaturate", desc.damperVelCompressSaturate );
			WriteFloat( "velStretchSaturate",  desc.damperVelStretchSaturate );
			WriteFloat( "maxCompressForce",    desc.damperMaxCompressForce );
			WriteFloat( "maxStretchForce",     desc.damperMaxStretchForce );
			--mIndent;
		}

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxJointLimitSoftPairDesc &l)
{
	if ( mFph )
	{
		Print("%s",	desc );

		++mIndent;
		Write("[low]", l.low );
		Write("[high]",	l.high );
		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc, NxJoint *j)
{
	if ( mFph && j )
	{
		Print( "%s", desc );
		++mIndent;

		NxJointType	type = j->getType();

		switch ( type )
		{
			case NX_JOINT_PRISMATIC:
			{
				NxPrismaticJoint *jt = j->isPrismaticJoint();
				assert(jt);
				NxPrismaticJointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_REVOLUTE:
			{
				NxRevoluteJoint	*jt	= j->isRevoluteJoint();
				assert(jt);
				NxRevoluteJointDesc	d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_CYLINDRICAL:
			{
				NxCylindricalJoint *jt = j->isCylindricalJoint();
				assert(jt);
				NxCylindricalJointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_SPHERICAL:
			{
				NxSphericalJoint *jt = j->isSphericalJoint();
				assert(jt);
				NxSphericalJointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_POINT_ON_LINE:
			{
				NxPointOnLineJoint *jt = j->isPointOnLineJoint();
				assert(jt);
				NxPointOnLineJointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_POINT_IN_PLANE:
			{
				NxPointInPlaneJoint	*jt	= j->isPointInPlaneJoint();
				assert(jt);
				NxPointInPlaneJointDesc	d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_DISTANCE:
			{
				NxDistanceJoint	*jt	= j->isDistanceJoint();
				assert(jt);
				NxDistanceJointDesc	d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_PULLEY:
			{
				NxPulleyJoint *jt =	j->isPulleyJoint();
				assert(jt);
				NxPulleyJointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_FIXED:
			{
				NxFixedJoint *jt = j->isFixedJoint();
				assert(jt);
				NxFixedJointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );
			}
			break;

			case NX_JOINT_D6:
			{
				NxD6Joint *jt =	j->isD6Joint();
				assert(jt);
				NxD6JointDesc d;
				jt->saveToDesc(d);
				Write( &d, j );				   
			}
			break;

			default:
				assert(	false );
			break;
		}		 

		--mIndent;
	}
}

//==================================================================================
void CoreDump::Print(const char	*fmt,...)
{
	if ( !mBinary )
	{
		char wbuff[2048];
		vsprintf(wbuff,	fmt, (char *)(&fmt+1));

		for	(int i=0; i<mIndent; i++)
			fprintf(mFph,"	");
  
		fprintf(mFph,"%s\r\n", wbuff );
	}
}

//==================================================================================
bool CoreDump::AddSkeleton(NxCCDSkeleton *skeleton)
{
	int	count =	mSkeletons.size();
	NxCCDSkeleton **list = &mSkeletons[0];
	for	(int i=0; i<count; i++)
	{
		if ( skeleton == list[i] ) return false; //	not	new	to the list
	}

	mSkeletons.push_back(skeleton);

	return true;
}

//==================================================================================
bool CoreDump::AddConvex(NxConvexMesh *mesh)
{
	int	count =	mConvexMeshes.size();
	NxConvexMesh **list	= &mConvexMeshes[0];
	for	(int i=0; i<count; i++)
	{
		if ( mesh == list[i] ) return false; //	not	new	to the list
	}

	mConvexMeshes.push_back(mesh);

	return true;
}

//==================================================================================
bool CoreDump::AddTriangleMesh(NxTriangleMesh *mesh)
{
	int	count =	mTriangleMeshes.size();
	NxTriangleMesh **list =	&mTriangleMeshes[0];
	for	(int i=0; i<count; i++)
	{
		if ( mesh == list[i] ) return false; //	not	new	to the list
	}

	mTriangleMeshes.push_back(mesh);

	return true;
}

//==================================================================================
int	CoreDump::GetSkeletonIndex(const NxCCDSkeleton *skeleton)
{
	if ( skeleton )
	{
		int	count =	mSkeletons.size();
		NxCCDSkeleton **list = &mSkeletons[0];
		for	(int i=0; i<count; i++)
		{
			if ( skeleton == list[i] ) return i;
		}

		assert(0);
	}

	return -1;
}

//==================================================================================
int	CoreDump::GetConvexIndex(const NxConvexMesh	*mesh)
{
	if ( mesh )
	{
		int	count =	mConvexMeshes.size();

		NxConvexMesh **list	= &mConvexMeshes[0];

		for	(int i=0; i<count; i++)
		{
			if ( mesh == list[i] ) return i;
		}

		assert(0);
	}

	return -1;
}

//==================================================================================
int	CoreDump::GetTriangleMeshIndex(const NxTriangleMesh	*mesh)
{
	if ( mesh )
	{
		int	count =	mTriangleMeshes.size();

		NxTriangleMesh **list =	&mTriangleMeshes[0];

		for	(int i=0; i<count; i++)
		{
			if ( mesh == list[i] ) return i;
		}

		assert(0);
	}

	return -1;
}

//==================================================================================
void CoreDump::Write(const char	*d,const NxTriangleMesh	*mesh)
{
	unsigned i;

	if ( mesh )
	{
		Print("%s",	d );
		++mIndent;

		if ( mBinary )
		{
			// write its index
			int	index =	GetTriangleMeshIndex( mesh );
			WriteInt_b(	index );
		}

		NxTriangleMeshDesc desc;
		mesh->saveToDesc( desc );

		// output its stride index
		WriteInt( "materialIndexStride = ",	desc.materialIndexStride );
		if ( desc.materialIndices )
		{
			// first write out the number of them!
			WriteInt( "NumMaterialIndices", desc.numTriangles );

			Print( "[Material Indices]" );
			++mIndent;

			char buff[32];
			if ( desc.materialIndexStride == 4 )
			{
				int *matPntr = (int *)desc.materialIndices;

				// k, actually write out the indices!!!
				for ( i = 0; i < desc.numTriangles; ++i )
				{
					// k, now we write out the indices!
					int val = *matPntr;
					++matPntr;
					sprintf( buff, "matIndex%d", i+1 );
					WriteInt( buff, val );
				}
			}
			else if ( desc.materialIndexStride == 2 )
			{
				short *matPntr = (short *)desc.materialIndices;

				// k, actually write out the indices!!!
				for ( i = 0; i < desc.numTriangles; ++i )
				{
					// k, now we write out the indices!
					short val = *matPntr;
					++matPntr;
					sprintf( buff, "matIndex%d", i+1 );
					WriteShort( buff, val );
				}
			}
			else if ( desc.materialIndexStride == 1 )
			{
				char *matPntr = (char *)desc.materialIndices;

				// k, actually write out the indices!!!
				for ( i = 0; i < desc.numTriangles; ++i )
				{
					// k, now we write out the indices!
					char val = *matPntr;
					++matPntr;
					sprintf( buff, "matIndex%d", i+1 );
					WriteChar( buff, val, true );
				}
			}
			else
			{
				// uh, what?
				assert( 0 );
			}
			--mIndent;
		}
		else
		{
			if ( mBinary )
			{
				WriteUnsigned_b( 0 );
			}
			else
			{
				Print("materialIndices=NULL" );
			}
		}

		// write its height	field vertical axis	type
		WriteInt( "heightFieldVerticalAxis",     desc.heightFieldVerticalAxis );
		WriteFloat(	"heightFieldVerticalExtent", desc.heightFieldVerticalExtent	);
		WriteFloat(	"convexEdgeThreshold",       desc.convexEdgeThreshold	);

		// write its flags
		if ( mBinary )
		{
			WriteFlag_b( desc.flags	);
		}
		else
		{
			PrintFlag(desc.flags, "NX_MF_FLIPNORMALS",    NX_MF_FLIPNORMALS );
			PrintFlag(desc.flags, "NX_MF_16_BIT_INDICES", NX_MF_16_BIT_INDICES );
		}

		// write num verts and stride bytes
		WriteInt( "numVertices = ",	  desc.numVertices );
		WriteInt( "pointStrideBytes", desc.pointStrideBytes	);

		// write the verts
		++mIndent;
		const char *vbase =	(const char	*)desc.points;
		for	( i	= 0; i < desc.numVertices; ++i )
		{
			const float	*p = (const	float *)&vbase[i * desc.pointStrideBytes];

			// write each vert (remember, xyz)
			if ( mBinary )
			{
				WriteFloat_b( p[0] );
				WriteFloat_b( p[1] );
				WriteFloat_b( p[2] );
			}
			else
			{
				Print("V%d=(%s,%s,%s)",	i+1, getFloatString(p[0]), getFloatString(p[1]), getFloatString(p[2]) );
			}
		}
		--mIndent;

		// write num triangles and stride bytes
		WriteInt( "numTriangles",		 desc.numTriangles );
		WriteInt( "triangleStrideBytes", desc.triangleStrideBytes );

		// write the triangles
		++mIndent;
		if ( mBinary )
		{
			if ( desc.triangleStrideBytes/3	== 1 )
			{
				const char *tris = (const char *)desc.triangles;
				for	( i	= 0; i < desc.numTriangles;	++i	)
				{
					WriteChar_b( *tris );
					++tris;
					WriteChar_b( *tris );
					++tris;
					WriteChar_b( *tris );
					++tris;
				}
			}
			else if	( desc.triangleStrideBytes/3 ==	2 )
			{
				const short	*tris =	(const short *)desc.triangles;
				for	( i	= 0; i < desc.numTriangles;	++i	)
				{
					WriteShort_b( *tris	);
					++tris;
					WriteShort_b( *tris	);
					++tris;
					WriteShort_b( *tris	);
					++tris;
				}		 
			}
			else if	( desc.triangleStrideBytes/3 ==	4 )
			{
				const int *tris	= (const int *)desc.triangles;
				for	( i	= 0; i < desc.numTriangles;	++i	)
				{
					WriteInt_b(	*tris );
					++tris;
					WriteInt_b(	*tris );
					++tris;
					WriteInt_b(	*tris );
					++tris;
				}		 
			}
			else
			{
				assert(	false );
			}

			// write pmap info
			unsigned size =	mesh->getPMapSize();
			if ( mesh->hasPMap() )
			{
				NxPMap pmap;
				pmap.dataSize =	size;
				pmap.data     = (void *)(new char[size]);

				bool success = mesh->getPMapData( pmap );

				if ( success )
				{
					// k, write	its	size and the data
					WriteUnsigned_b( size );
					fwrite(	pmap.data, sizeof(char), pmap.dataSize,	mFph );
				}
				else
				{
					WriteUnsigned_b( 0 );
				}

				// now deallocate the memory we allocated
				delete [] pmap.data;
			}
			else
			{
				WriteUnsigned_b( 0 );
			}
		}
		else
		{
			const char *base = (const char *) desc.triangles;
			for(NxU32 i=0; i<desc.numTriangles;	i++)
			{
				const char *t =	&base[i*desc.triangleStrideBytes];
				if ( desc.flags	& NX_MF_16_BIT_INDICES )
				{
					const NxU16	*tri = (const NxU16	*) t;
					Print("Tri%d=(%d,%d,%d)", i+1, tri[0], tri[1], tri[2] );
				}
				else
				{
					const NxU32	*tri = (const NxU32	*) t;
					Print("Tri%d=(%d,%d,%d)", i+1, tri[0], tri[1], tri[2] );
				}
			}

			// write pmap info
			if ( desc.pmap )
			{
				Print("pmap	= %08X,	size = %d",	desc.pmap->data, desc.pmap->dataSize );
			}
			else
			{
				Print("pmap=NULL");
			}
		}
		--mIndent;
		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write( const	char *d, const NxConvexMesh	*mesh )
{
	if ( mesh )
	{
		unsigned i;
		Print("%s",	d );
		++mIndent;

		if ( mBinary )
		{
			// write its index
			int	index =	GetConvexIndex(	mesh );
			WriteInt_b(	index );
		}

		// output its info
		NxConvexMeshDesc desc;
		mesh->saveToDesc(desc);

		if ( mBinary )
		{
			WriteFlag_b( desc.flags	);
		}
		else
		{
			PrintFlag(desc.flags, "NX_CF_FLIPNORMALS",		NX_CF_FLIPNORMALS );
			PrintFlag(desc.flags, "NX_CF_16_BIT_INDICES",	NX_CF_16_BIT_INDICES );
			PrintFlag(desc.flags, "NX_CF_COMPUTE_CONVEX",	NX_CF_COMPUTE_CONVEX );
//			PrintFlag(desc.flags, "NX_CF_INFLATE_CONVEX",	NX_CF_INFLATE_CONVEX );
		}

		// write num verts,	etc.
		WriteInt( "NumVertices",	  desc.numVertices	);
		WriteInt( "PointStrideBytes", desc.pointStrideBytes	);

		++mIndent;
		const char *vbase =	(const char	*)desc.points;
		for	( i	= 0; i < desc.numVertices; ++i )
		{
			// write the vertices (for now,	we will	write out the indices)
			const float	*p = (const	float *)&vbase[i * desc.pointStrideBytes];
			if ( mBinary )
			{
				WriteInt_b(	i );
				WriteFloat_b( p[0] );
				WriteFloat_b( p[1] );
				WriteFloat_b( p[2] );
			}
			else
			{
				const float	*p = (const	float *)&vbase[i*desc.pointStrideBytes];
				Print("V%d=(%s,%s,%s)",	i+1, getFloatString(p[0]), getFloatString(p[1]), getFloatString(p[2]) );
			}
		}
		--mIndent;

		WriteInt( "NumTriangles",        desc.numTriangles );
		WriteInt( "TriangleStrideBytes", desc.triangleStrideBytes );

		++mIndent;
		// k, now write	out	the	triangle info (indices)
		const char *tbase =	(const char	*) desc.triangles;
		for( i=0; i<desc.numTriangles; ++i )
		{
			const char *t =	&tbase[i*desc.triangleStrideBytes];
			if ( desc.flags	& NX_MF_16_BIT_INDICES )
			{
				const NxU16	*tri = (const NxU16	*) t;
				if ( mBinary )
				{
					WriteInt_b(	tri[0] );
					WriteInt_b(	tri[1] );
					WriteInt_b(	tri[2] );
				}
				else
				{
					Print("Tri%d=(%d,%d,%d)", i+1, tri[0], tri[1], tri[2] );
				}
			}
			else
			{
				const NxU32	*tri = (const NxU32	*) t;
				if ( mBinary )
				{
					WriteInt_b(	tri[0] );
					WriteInt_b(	tri[1] );
					WriteInt_b(	tri[2] );
				}
				else
				{
					Print("Tri%d=(%d,%d,%d)", i+1, tri[0], tri[1], tri[2] );
				}
			}
		}
		--mIndent;
		--mIndent;
	}
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxCCDSkeleton *skeleton)
{
	// TODO	: write	out	the	skeleton!
	if ( mBinary )
	{
	}
	else
	{
		Print("%s",	desc );
	}
}

//==================================================================================
int	CoreDump::GetActorIndex(const NxActor *a) const
{
	int ret = -1;

	if ( a )
	{
		const char *index = (const char *) a->userData;
		ret = (int)(index - 0);
	}
  return ret;
}

int	CoreDump::GetShapeIndex(const NxActor *a,const NxShape *s) const
{
	int ret = -1;

  assert(a);
  assert(s);
	if ( a )
	{
  	NxU32 numShapes	= a->getNbShapes();
		if ( numShapes )
		{
			NxShape	*const *shapes = a->getShapes();
			for	( NxU32	k =	0; k	< numShapes; ++k )
			{
				const NxShape *shape = shapes[k];
				if ( shape == s )
				{
  				ret = k;
  				break;
				}
			}
		}
	}
  return ret;
}

//==================================================================================
void CoreDump::Write(const char	*desc,const	NxQuat &q)
{
	if ( mFph )
	{
		NxReal quat[4];
		q.getXYZW( quat	);

		if ( mBinary )
		{
			WriteFloat(	"quat0", quat[0] );
			WriteFloat(	"quat1", quat[1] );
			WriteFloat(	"quat2", quat[2] );
			WriteFloat(	"quat3", quat[3] );
		}
		else
		{
			Print("%s=%s,%s,%s,%s",	desc,
			  getFloatString( quat[0] ),
			  getFloatString( quat[1] ),
			  getFloatString( quat[2] ),
			  getFloatString( quat[3] )	);
		}
	}
}


void CoreDump::SaveUserData(NxScene *scene)
{
	assert( mActorUserData == 0 );

  NxU32 acount = scene->getNbActors();

  if ( acount )
  {
  	mActorUserData = (void **) malloc( sizeof(void *)*acount );
		NxActor	**actors = scene->getActors();
		const char *foo = 0;

  	for (NxU32 i=0; i<acount; i++)
  	{
  		NxActor *a = actors[i];
			const char *index = foo+i;
  		mActorUserData[i] = a->userData;
  		a->userData = (void *)index;
  	}
  }

}
void CoreDump::RestoreUserData(NxScene *scene)
{
  NxU32 acount = scene->getNbActors();

  if ( acount )
  {
  	assert(mActorUserData);

		NxActor	**actors = scene->getActors();
  	for (NxU32 i=0; i<acount; i++)
  	{
  		NxActor *a = actors[i];
  		a->userData = mActorUserData[i];
  	}

  	free(mActorUserData);
  	mActorUserData = 0;

  }


}

#endif

