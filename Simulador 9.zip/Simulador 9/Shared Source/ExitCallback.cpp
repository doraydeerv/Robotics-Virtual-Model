// ===============================================================================
//						     PHYSX SDK TRAINING PROGRAMS
//							   EXIT CALLBACK ROUTINES
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#ifdef WIN32 
	#define NOMINMAX
	#include <windows.h>
#elif LINUX
#endif
#include "ExitCallback.h"

typedef void (*ExitCallback)();

static ExitCallback gExitCallback = NULL;

/*void glutExitFunc(void (GLUTCALLBACK *func)(void))
{
	gExitCallback = func;
}*/

static void Exit()
{
	if(gExitCallback)	(gExitCallback)();
}

// How can we go past glutMainLoop?
struct cleanup{~cleanup(){Exit();}}cleanup;
