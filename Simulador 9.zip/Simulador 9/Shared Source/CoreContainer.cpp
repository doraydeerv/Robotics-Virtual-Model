#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "CoreContainer.h"
#include "CoreDump.h"
#include "NxCooking.h"
#include "Stream.h"


#if SMOKETEST
#include "NxTest.h"
using namespace NxTest;
#endif

//==================================================================================
bool CoreContainer::GetBool(void)
{
	bool ret = false;
	if ( mFp )
	{
		char tmp;
		fread( &tmp, sizeof(char), 1, mFp );
		if ( tmp ==	1 )
		{
			ret	= true;
		}
	}
	return ret;
}

//==================================================================================
char CoreContainer::GetChar(void)
{
	char ret = 0;
	if ( mFp )
	{
		fread( &ret, sizeof(char), 1, mFp );
	}
	return ret;
}

//==================================================================================
int CoreContainer::GetInt(void)
{
	int	ret	= 0;
	if ( mFp )
	{
		fread( &ret, sizeof(int), 1, mFp );
	}
	return ret;
}

//==================================================================================
long CoreContainer::GetLong(void)
{
	long ret = 0;
	if ( mFp )
	{
		fread( &ret, sizeof(long), 1, mFp );
	}
	return ret;
}

//==================================================================================
short CoreContainer::GetShort(void)
{
	short ret =	0;
	if ( mFp )
	{
		fread( &ret, sizeof(short),	1, mFp );
	}
	return ret;
}

//==================================================================================
unsigned CoreContainer::GetUnsigned(void)
{
	unsigned ret = 0;
	if ( mFp )
	{
		fread( &ret, sizeof(unsigned), 1, mFp );
	}
	return ret;
}

//==================================================================================
unsigned long CoreContainer::GetUnsignedLong(void)
{
	unsigned long ret =	0;
	if ( mFp )
	{
		fread( &ret, sizeof(unsigned long),	1, mFp );
	}
	return ret;
}

//==================================================================================
unsigned short CoreContainer::GetUnsignedShort( void )
{
	unsigned short ret = 0;
	if ( mFp )
	{
		fread( &ret, sizeof(unsigned short), 1,	mFp	);
	}
	return ret;
}

//==================================================================================
float CoreContainer::GetFloat(void)
{
	float ret =	0;
	if ( mFp )
	{
		fread( &ret, sizeof(float),	1, mFp );
	}
	return ret;
}

//==================================================================================
double CoreContainer::GetDouble(void)
{
	double ret = 0;
	if ( mFp )
	{
		fread( &ret, sizeof(double), 1,	mFp	);
	}
	return ret;
}

//==================================================================================
int CoreContainer::GetString( char *buff, int buffSize )
{
	int	len	= 0;
	if ( mFp )
	{
		len	= GetInt();
		assert(	len	< buffSize );
		if ( len )
		{
			fread( buff, sizeof(char), sizeof(char)*len, mFp );
			buff[len] =	'\0';
		}
	}
	return len;
}

//==================================================================================
unsigned CoreContainer::GetFlag( void )
{
	unsigned ret = 0;
	if ( mFp )
	{
		fread( &ret, sizeof(unsigned), 1, mFp );
	}
	return ret;
}

//==================================================================================
void CoreContainer::GetMatrix( NxMat34 &matrix )
{
	NxReal m[9];
	for	( int i	= 0; i < 9;	++i	)
	{
		m[i] = GetFloat();
	}
	matrix.M.setRowMajor( m	);

	matrix.t.x = GetFloat();
	matrix.t.y = GetFloat();
	matrix.t.z = GetFloat();
}

//==================================================================================
void CoreContainer::GetVec3( NxVec3 &v )
{
	if ( mFp )
	{
		fread( &v.x, sizeof(float),	1, mFp );	 
		fread( &v.y, sizeof(float),	1, mFp );	 
		fread( &v.z, sizeof(float),	1, mFp );	 
	}
}

//==================================================================================
void CoreContainer::GetQuat( NxQuat &q )
{
	NxReal quat[4] = {0, 0,	0, 0};

	if ( mFp )
	{
		fread( &quat[0], sizeof(float),	1, mFp );
		fread( &quat[1], sizeof(float),	1, mFp );
		fread( &quat[2], sizeof(float),	1, mFp );
		fread( &quat[3], sizeof(float),	1, mFp );
	}
	q.setXYZW( quat	);
}

//==================================================================================
bool CoreContainer::GetBodyDesc( NxBodyDesc &b )
{
	bool ret = false;
	if ( mFp &&	GetBool() )
	{
		GetMatrix( b.massLocalPose	);
		GetVec3( b.massSpaceInertia );
		b.mass				   = GetFloat();
		GetVec3( b.linearVelocity );
		GetVec3( b.angularVelocity	);
		b.wakeUpCounter		   = GetFloat();
		b.linearDamping		   = GetFloat();
		b.angularDamping	   = GetFloat();
		b.maxAngularVelocity   = GetFloat();
		b.CCDMotionThreshold   = GetFloat();
		b.sleepLinearVelocity  = GetFloat();
		b.sleepAngularVelocity = GetFloat();
		b.solverIterationCount = GetUnsigned();
		b.flags	               = GetFlag();

		ret	= true;
	}
	return ret;
}

//==================================================================================
NxShapeType CoreContainer::GetShapeType( void )
{
	NxShapeType	ret	= NX_SHAPE_COUNT;

	// k, do we	even have a	shape?
	if ( GetBool() )
	{
		// k, get the type
		ret	= static_cast<NxShapeType>(	GetInt() );
	}
	return ret;
}

//==================================================================================
void CoreContainer::GetShapeDesc( NxShapeDesc &desc )
{
	// k, do we	need its name -	for	now	assuming yes?
	if ( mFp )
	{
		// Get local pose
		GetMatrix( desc.localPose );

		// get other information
		desc.group		   = GetInt();
		desc.materialIndex = GetInt();
		desc.mass		   = GetFloat();
		desc.density	   = GetFloat();
		desc.skinWidth	   = GetFloat();

		// k, here we don't	care about the description - just the flags
		desc.shapeFlags	   = GetFlag();

		// k, this is bad, as it reads a pntr data,	which is not good
		desc.ccdSkeleton   = reinterpret_cast<NxCCDSkeleton	*>(	GetInt() );

#ifdef NX_SUPPORT_NEW_FILTERING
		//!< Groups	bitmask	for	collision filtering
		desc.groupsMask.bits0 =	GetUnsigned();
		desc.groupsMask.bits1 =	GetUnsigned();
		desc.groupsMask.bits2 =	GetUnsigned();
		desc.groupsMask.bits3 =	GetUnsigned();
#endif

		char buff[128];
		desc.name	= 0;
		int	nameLen	= GetString( buff,	128	);
		if ( nameLen )
		{
			char *tmp = new	char[nameLen+1];
			assert(	tmp );
			strcpy( tmp, buff );
			desc.name = tmp;
		}
	}
}

//==================================================================================
void CoreContainer::GetSphereShapeDesc(	NxSphereShapeDesc &desc )
{
	// k, get normal shape desc
	GetShapeDesc( desc );

	// now get the rest
	desc.radius	= GetFloat();
}

//==================================================================================
void CoreContainer::GetBoxShapeDesc( NxBoxShapeDesc &desc )
{
	// k, get normal shape desc
	GetShapeDesc( desc );

	// now get the rest
	GetVec3( desc.dimensions );
}

//==================================================================================
void CoreContainer::GetCapsuleShapeDesc( NxCapsuleShapeDesc &desc )
{
	// k, get normal shape desc
	GetShapeDesc( desc	);

	// now get the rest
	desc.radius	= GetFloat(); 
	desc.height	= GetFloat();
	desc.flags	= GetFlag();
}

//==================================================================================
void CoreContainer::GetConvexShapeDesc(	NxConvexShapeDesc &desc )
{
	// k, get normal shape desc
	GetShapeDesc( desc );

	desc.meshFlags = GetInt();
#ifdef NX_SUPPORT_CONVEX_SCALE
	desc.scale	   = GetFloat();
#endif

	// k, get the index of its mesh
	unsigned index = GetInt();
	desc.meshData  = (NxConvexMesh *)index;
}

//==================================================================================
void CoreContainer::GetTriangleMeshShapeDesc( NxTriangleMeshShapeDesc &desc )
{
	// k, get normal shape desc
	GetShapeDesc( desc );

	desc.meshFlags = GetFlag();
#ifdef NX_SUPPORT_CONVEX_SCALE
	desc.scale	   = GetFloat();
#endif

	// k, get the index of its mesh
	unsigned index = GetUnsigned();
	desc.meshData  = (NxTriangleMesh *)index;
}

//==================================================================================
void CoreContainer::GetTriangleMeshDesc( NxTriangleMeshDesc *tmd, int indexToCheck )
{
	if ( mFp && tmd )
	{
		int	i;

		// write its index
		int	index					   = GetInt();
		assert(	index == indexToCheck );

		// output its stride index
		tmd->materialIndexStride	   = GetInt();
		unsigned numIndices            = GetUnsigned();
		if ( numIndices )
		{
			if ( tmd->materialIndexStride == 4 )
			{
				int *ptr = new int[numIndices];
				assert( ptr );
				if ( ptr )
				{
					memset( ptr, 0, sizeof(int)*numIndices );
				}

				for ( unsigned j = 0; j < numIndices; ++j )
				{
					int val = GetInt();
					if ( ptr )
					{
						ptr[j] = val;
					}
				}
				tmd->materialIndices = (void *)ptr;
			}
			else if ( tmd->materialIndexStride == 2 )
			{
				short *ptr = new short[numIndices];
				assert( ptr );
				if ( ptr )
				{
					memset( ptr, 0, sizeof(short)*numIndices );
				}

				for ( unsigned j = 0; j < numIndices; ++j )
				{
					short val = GetShort();
					if ( ptr )
					{
						ptr[j] = val;
					}
				}			
				tmd->materialIndices = (void *)ptr;
			}
			else if ( tmd->materialIndexStride == 1 )
			{
				char *ptr = new char[numIndices];
				assert( ptr );
				if ( ptr )
				{
					memset( ptr, 0, sizeof(char)*numIndices );
				}

				for ( unsigned j = 0; j < numIndices; ++j )
				{
					char val = GetChar();
					if ( ptr )
					{
						ptr[j] = val;
					}
				}
				tmd->materialIndices = (void *)ptr;
			}
		}
		else
		{
			tmd->materialIndices = 0;
		}

		// write its height	field vertical axis	type, etc.
		tmd->heightFieldVerticalAxis   = (NxHeightFieldAxis)GetInt();
		tmd->heightFieldVerticalExtent = GetFloat();
		tmd->convexEdgeThreshold	   = GetFloat();
		tmd->flags					   = GetFlag();

		// get num vertices and point stride bytes
		tmd->numVertices			   = GetInt();
		tmd->pointStrideBytes		   = GetInt();
		int	totalToRead				   = tmd->numVertices*3;
		float *newPts				   = new float[totalToRead];
		assert( newPts );
		if ( newPts )
		{
			memset( newPts, 0, sizeof(float)*totalToRead );
		}

		tmd->points	= (const void *)newPts;
		for	( i	= 0; i < totalToRead; ++i )
		{
			float val = GetFloat();
			if ( newPts )
			{
				newPts[i] =	val;
			}
		}

		// get num triangles and triangle stride bytes
		tmd->numTriangles			   = GetInt();
		tmd->triangleStrideBytes	   = GetInt();

		int	size = tmd->numTriangles*3;
		if ( tmd->triangleStrideBytes/3	== 1 )
		{
			tmd->triangles = (void *)( new char[size] );
			assert( tmd->triangles );
			char *tmp = (char *)tmd->triangles;
			if ( tmp )
			{
				memset( tmp, 0, sizeof(char)*size );
			}

			for	( i	= 0; i < size; ++i )
			{
				char val1 = GetChar();
				char val2 = GetChar();
				char val3 = GetChar();
				if ( tmp )
				{
					tmp[i] = val1;
					++i;
					tmp[i] = val2;
					++i;
					tmp[i] = val3;
				}
			}
		}
		else if	( tmd->triangleStrideBytes/3 ==	2 )
		{
			tmd->triangles = (void *)( new short[size] );
			assert( tmd->triangles );
			short *tmp = (short	*)tmd->triangles;
			if ( tmp )
			{
				memset( tmp, 0, sizeof(short)*size );
			}

			for	( i	= 0; i < size; ++i )
			{
				short val1 = GetShort();
				short val2 = GetShort();
				short val3 = GetShort();
				if ( tmp )
				{
					tmp[i] = val1;
					++i;
					tmp[i] = val2;
					++i;
					tmp[i] = val3;
				}
			}
		}
		else if	( tmd->triangleStrideBytes/3 ==	4 )
		{
			tmd->triangles = (void *)( new int[size] );
			assert( tmd->triangles );
			int	*tmp = (int *)tmd->triangles;
			if ( tmp )
			{
				memset( tmp, 0, sizeof(int)*size );
			}

			for	( i	= 0; i < size; ++i )
			{
				int val1 = GetInt();
				int val2 = GetInt();
				int val3 = GetInt();
				if ( tmp )
				{
					tmp[i] = val1;	
					++i;
					tmp[i] = val2;
					++i;
					tmp[i] = val3;
				}
			}
		}
		else
		{
			assert(	false );
		}

		// k, get the pmap data	(init to 0)
		unsigned pmapSize = GetUnsigned();
		if ( pmapSize )
		{
			NxPMap *pmap = new NxPMap;

			if ( pmap )
			{
				// init	info
				pmap->data	   = 0;
				pmap->dataSize = pmapSize;
			}

			char *pmapData = new char[pmapSize];
			assert( pmapData );
			if ( pmapData )
			{
				memset( pmapData, 0, sizeof(char)*pmapSize );

				// k, setup the pntr
				pmap->data = pmapData;
			}

			if ( pmap->data	)
			{
				// get the pmap data
				fread( pmap->data, sizeof(char), sizeof(char)*pmapSize,	mFp	);
			}
			else
			{
				// k, NOT good,	as we now just read	the	information	in,	but	throw it away!
				for	( unsigned i = 0; i	< pmapSize;	++i	)
				{
					GetChar();
				}

				// delete the pmap
				delete pmap;
				pmap = 0;
			}

			// assign the pmap
			tmd->pmap =	pmap;
		}
	}
}

//==================================================================================
void CoreContainer::GetConvexMeshDesc( NxConvexMeshDesc *cmd, int indexCheck	)
{
	if ( cmd )
	{
		unsigned i;

		// write its index
		int	index			  =	GetInt();
		assert(	index == indexCheck	);

		// get its info
		cmd->flags			  =	GetFlag();

		cmd->numVertices	  =	GetInt();
		cmd->pointStrideBytes =	GetInt();

		// now get all the vertices
		int	size	= cmd->pointStrideBytes	/ 3;
		char *verts	= new char[cmd->numVertices	* cmd->pointStrideBytes];
		assert( verts );
		if ( verts )
		{
			memset( verts, 0, sizeof(char)*cmd->numVertices	* cmd->pointStrideBytes );
		}

		for	( i=0; i<cmd->numVertices; ++i )
		{
			int	indexToUse = i * cmd->pointStrideBytes;

			// read	the	vertices
			int	which =	GetInt();
			assert(	which == i );

			float val1 = GetFloat();
			float val2 = GetFloat();
			float val3 = GetFloat();

			if ( verts )
			{
				float *fpntr = (float *)&verts[indexToUse];
				fpntr[0]	 = val1;
				fpntr[1]	 = val2;
				fpntr[2]	 = val3;
			}
		}
		// set pntr
		cmd->points	= verts;

		// now get number of triangles and their stride	bytes
		cmd->numTriangles		 = GetInt();
		cmd->triangleStrideBytes = GetInt();

		// only try and get triangle indices if there are any
		char *indices = 0;
		if ( cmd->numTriangles )
		{
			// k, now get the triangle indices
			size = cmd->triangleStrideBytes	/ 3;
			indices = new char[cmd->numTriangles * cmd->triangleStrideBytes];
			for( i=0; i<cmd->numTriangles; ++i )
			{
				int	indexToUse = i * cmd->triangleStrideBytes;
				int	*ipntr	   = (int *)&indices[indexToUse];
				ipntr[0]	   = GetInt();
				ipntr[1]	   = GetInt();
				ipntr[2]	   = GetInt();
			}
		}
		cmd->triangles = indices;
	}
}

//==================================================================================
void CoreContainer::GetPlaneShapeDesc( NxPlaneShapeDesc &desc )
{
	if ( mFp )
	{
		GetShapeDesc( desc );

		// now write plane shape desc specific params
		GetVec3( desc.normal );
		desc.d = GetFloat();
	}
}

//==================================================================================
void CoreContainer::GetActorDesc( NxActorDesc *nad )
{
	if ( mFp &&	nad	)
	{
		char buff[128];

		nad->setToDefault();

		// get its global pose
		GetMatrix( nad->globalPose	);

		// get body	description	if it exists (start	out	with pntr at 0)
		nad->body =	0;
		if ( GetBool() )
		{
			// k, gotta	create a body descriptor
			NxBodyDesc *bodyDesc = new NxBodyDesc;
			assert(	bodyDesc );

			NxMat34 mat;
			NxVec3 msi, lv, av;
			float mass, wake, ldamp, adamp, avel, ccd, slvel, savel;
			unsigned sic, flags;

			GetMatrix( mat );
			GetVec3( msi );
			mass = GetFloat();
			GetVec3( lv );
			GetVec3( av );
			wake  = GetFloat();
			ldamp = GetFloat();
			adamp = GetFloat();
			avel  = GetFloat();
			ccd   = GetFloat();
			slvel = GetFloat();
			savel = GetFloat();
			sic   = GetUnsigned();
			flags = GetFlag();

			if ( bodyDesc )
			{
				bodyDesc->massLocalPose				= mat;
				bodyDesc->massSpaceInertia			= msi;
				bodyDesc->mass						= mass;
				bodyDesc->linearVelocity			= lv;
				bodyDesc->angularVelocity			= av;
				bodyDesc->wakeUpCounter				= wake;
				bodyDesc->linearDamping				= ldamp;
				bodyDesc->angularDamping			= adamp;
				bodyDesc->maxAngularVelocity		= avel;
				bodyDesc->CCDMotionThreshold		= ccd;
				bodyDesc->sleepLinearVelocity		= slvel;
				bodyDesc->sleepAngularVelocity		= savel;
				bodyDesc->solverIterationCount		= sic;
				bodyDesc->flags						= flags;
			}

			// set body pntr
			nad->body =	bodyDesc;
		}
		nad->density = GetFloat();
		nad->group	 = GetInt();
		nad->flags	 = GetFlag();
		nad->name	 = 0;
		int	readLen	= GetString( buff, 128 );
		if ( readLen )
		{
			char *tmp = new char[readLen+1];
			if ( tmp )
			{
				memset( tmp, 0, sizeof(char)*(readLen+1) );
				strcpy(	tmp, buff );
			}
			nad->name =	tmp;
		}
	}
}

//==================================================================================
NxShapeDesc *CoreContainer::GetActorShape( void )
{
	NxShapeDesc	*shape = 0;
	if ( mFp )
	{
		// k, does this	actor have a shape?
		if ( GetBool() )
		{
			// k, get the shape's type
			NxShapeType	type = (NxShapeType)GetInt();

			switch(	type )
			{
				case NX_SHAPE_PLANE:
				{
					NxPlaneShapeDesc *desc = new NxPlaneShapeDesc;
					assert( desc );
					if ( desc )
					{
						GetPlaneShapeDesc( *desc );
					}
					else
					{
						NxPlaneShapeDesc tmp;
						GetPlaneShapeDesc( tmp );
					}
					shape = desc;
				}
				break;

				case NX_SHAPE_SPHERE:
				{
					NxSphereShapeDesc *desc	= new NxSphereShapeDesc;
					assert( desc );
					if ( desc )
					{
						GetSphereShapeDesc(	*desc );
					}
					else
					{
						NxSphereShapeDesc tmp;
						GetSphereShapeDesc( tmp );
					}
					shape = desc;
				}
				break;

				case NX_SHAPE_BOX:
				{
					NxBoxShapeDesc *desc = new NxBoxShapeDesc;
					assert( desc );
					if ( desc )
					{
						GetBoxShapeDesc( *desc );
					}
					else
					{
						NxBoxShapeDesc tmp;
						GetBoxShapeDesc( tmp );
					}
					shape = desc;
				}
				break;

				case NX_SHAPE_CAPSULE:
				{
					NxCapsuleShapeDesc *desc = new NxCapsuleShapeDesc;
					assert( desc );
					if ( desc )
					{
						GetCapsuleShapeDesc( *desc );
					}
					else
					{
						NxCapsuleShapeDesc tmp;
						GetCapsuleShapeDesc( tmp );
					}
					shape = desc;
				}
				break;

				case NX_SHAPE_CONVEX:
				{
					NxConvexShapeDesc *desc	= new NxConvexShapeDesc;
					assert( desc );
					if ( desc )
					{
						GetConvexShapeDesc(	*desc );
					}
					else
					{
						NxConvexShapeDesc tmp;
						GetConvexShapeDesc( tmp );
					}
					shape = desc;
				}
				break;


				case NX_SHAPE_MESH:
				{
					NxTriangleMeshShapeDesc	*desc =	new	NxTriangleMeshShapeDesc;
					assert( desc );
					if ( desc )
					{
						GetTriangleMeshShapeDesc( *desc );
					}
					else
					{
						NxTriangleMeshShapeDesc tmp;
						GetTriangleMeshShapeDesc( tmp );
					}
					shape = desc;
				}
				break;

				case NX_SHAPE_COMPOUND:
					assert(	0 );
				break;

				default:
					assert(0); //!!???
				break;
			}
		}
	}
	return shape;
}

//==================================================================================
void CoreContainer::GetJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// IMPORTANT!  At this point, the joint	type has already been read in!!
		// get actor indexes - Please note that	these are actually pointers, but we haven't
		// created them yet, so right now they are REFERENCES into the actor that will be created!!!!!!!
		d.mDesc->actor[0] = (NxActor *)GetInt();
		d.mDesc->actor[1] = (NxActor *)GetInt();
			
		// get normal, axis, anchor	(both 1	and	2)
		GetVec3( d.mDesc->localNormal[0] );
		GetVec3( d.mDesc->localAxis[0] );
		GetVec3( d.mDesc->localAnchor[0] );
		GetVec3( d.mDesc->localNormal[1] );
		GetVec3( d.mDesc->localAxis[1] );
		GetVec3( d.mDesc->localAnchor[1] );

		// write force and torque
		d.mDesc->maxForce	= GetFloat();
		d.mDesc->maxTorque	= GetFloat();

		// get joint name
		char name[128];
		int	nameLen	= GetString( name, 128 );
		if ( nameLen )
		{
			char *tmpName = new char[nameLen+1];
			assert(	tmpName );
			if ( tmpName )
			{
				memset( tmpName, 0, sizeof(char)*(nameLen+1) );
				strcpy( tmpName, name );
			}
			d.mDesc->name = tmpName;
		}

		// get flags
		d.mDesc->jointFlags = GetFlag();

		// get plane limits (if any)
		int numLimits = GetInt();
		if ( numLimits )
		{
			// get the limit point!
			GetVec3( d.mPlaneLimitPoint );
			d.mOnActor2 = GetBool();
		}
		// now, get each plane normal for limits!
		for ( int i = 0; i < numLimits; ++i )
		{
			NxVec3 planeNormal;
			GetVec3( planeNormal );
			float planeD = GetFloat();
			NxVec3 worldLimit;
			GetVec3( worldLimit );

			// allocate a joint limit plane
			PlaneInfo *ptr = new PlaneInfo;
			if ( ptr )
			{
				memset( ptr, 0, sizeof(PlaneInfo) );
				ptr->mPlaneNormal.set( planeNormal );
				ptr->mPlaneD		= planeD;
				ptr->mWorldLimitPt	= worldLimit;
				d.mPlaneInfo.push_back( ptr );
			}
		}
	}
}

//==================================================================================
void CoreContainer::GetPrismaticJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description - note	that is	all	we have	to do with this	joint type!
		GetJointDesc( d );
	}
}

//==================================================================================
void CoreContainer::GetRevoluteJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description
		GetJointDesc( d );

		NxRevoluteJointDesc *ptr = static_cast<NxRevoluteJointDesc * >( d.mDesc );

		// k, fill this	in - start with	low/high limits
		ptr->limit.low.hardness	 = GetFloat();
		ptr->limit.low.restitution	 = GetFloat();
		ptr->limit.low.value		 = GetFloat();
		ptr->limit.high.hardness	 = GetFloat();
		ptr->limit.high.restitution = GetFloat();
		ptr->limit.high.value		 = GetFloat();

		// get motor description
		ptr->motor.freeSpin  =	GetBool();
		ptr->motor.maxForce  =	GetFloat();
		ptr->motor.velTarget =	GetFloat();

		// get spring desc
		ptr->spring.spring		 = GetFloat();
		ptr->spring.damper		 = GetFloat();
		ptr->spring.targetValue = GetFloat();

		// get rest
		ptr->projectionDistance = GetFloat();
		ptr->projectionAngle	 = GetFloat();
		ptr->flags				 = GetFlag();

		ptr->projectionMode	 = (NxJointProjectionMode)GetUnsigned();
	}
}

//==================================================================================
void CoreContainer::GetCylindricalJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description - note	that is	all	we have	to do with this	joint type!
		GetJointDesc( d );
	}
}

//==================================================================================
void CoreContainer::GetSphericalJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description
		GetJointDesc( d );

		NxSphericalJointDesc *ptr = static_cast<NxSphericalJointDesc * >( d.mDesc );

		// now fill	the	rest of	it in
		// get spring descs
		ptr->twistSpring.spring	  =	GetFloat();
		ptr->twistSpring.damper	  =	GetFloat();
		ptr->twistSpring.targetValue =	GetFloat();
		ptr->swingSpring.spring	  =	GetFloat();
		ptr->swingSpring.damper	  =	GetFloat();
		ptr->swingSpring.targetValue =	GetFloat();
		ptr->jointSpring.spring	  =	GetFloat();
		ptr->jointSpring.damper	  =	GetFloat();
		ptr->jointSpring.targetValue =	GetFloat();

		// projection dist
		ptr->projectionDistance = GetFloat();

		// other limits	(twist and swing)
		ptr->twistLimit.low.hardness	  =	GetFloat();
		ptr->twistLimit.low.restitution  =	GetFloat();
		ptr->twistLimit.low.value		  =	GetFloat();
		ptr->twistLimit.high.hardness	  =	GetFloat();
		ptr->twistLimit.high.restitution =	GetFloat();
		ptr->twistLimit.high.value		  =	GetFloat();

		ptr->swingLimit.hardness		  =	GetFloat();
		ptr->swingLimit.restitution	  =	GetFloat();
		ptr->swingLimit.value			  =	GetFloat();

		// flags
		ptr->flags	= GetFlag();

		// axis
		ptr->swingAxis.x =	GetFloat();
		ptr->swingAxis.y =	GetFloat();
		ptr->swingAxis.z =	GetFloat();

		// projection mode
		ptr->projectionMode = (NxJointProjectionMode)GetUnsigned();
	}
}

//==================================================================================
void CoreContainer::GetPointOnLineJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description - note	that is	all	we have	to do with this	joint type!
		GetJointDesc( d );
	}
}

//==================================================================================
void CoreContainer::GetPointInPlaneJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description - note	that is	all	we have	to do with this	joint type!
		GetJointDesc( d );
	}
}

//==================================================================================
void CoreContainer::GetDistanceJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description
		GetJointDesc( d );

		NxDistanceJointDesc *ptr = static_cast<NxDistanceJointDesc * >( d.mDesc );

		// now fill	the	rest of	it in
		// min/max dist
		ptr->minDistance =	GetFloat();
		ptr->maxDistance =	GetFloat();

		// flags
		ptr->flags	= GetFlag();

		// spring desc
		ptr->spring.spring		 = GetFloat();
		ptr->spring.damper		 = GetFloat();
		ptr->spring.targetValue = GetFloat();
	}
}

//==================================================================================
void CoreContainer::GetPulleyJointDesc(	JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description
		GetJointDesc( d );

		NxPulleyJointDesc *ptr = static_cast<NxPulleyJointDesc * >( d.mDesc );

		// now fill	the	rest of	it in
		ptr->distance	= GetFloat();
		ptr->stiffness	= GetFloat();
		ptr->ratio		= GetFloat();
		ptr->flags		= GetFlag();

		// motor desc
		ptr->motor.freeSpin  =	GetBool();
		ptr->motor.maxForce  =	GetFloat();
		ptr->motor.velTarget =	GetFloat();

		// and pulley info
		ptr->pulley[0].x =	GetFloat();
		ptr->pulley[0].y =	GetFloat();
		ptr->pulley[0].z =	GetFloat();
		ptr->pulley[1].x =	GetFloat();
		ptr->pulley[1].y =	GetFloat();
		ptr->pulley[1].z =	GetFloat();
	}
}

//==================================================================================
void CoreContainer::GetFixedJointDesc( JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description - note	that is	all	we have	to do with this	joint type!
		GetJointDesc( d );
	}
}

//==================================================================================
void CoreContainer::GetJointLimitSoftDesc( NxJointLimitSoftDesc &l )
{
	if ( mFp )
	{
		l.value		  =	GetFloat();
		l.restitution =	GetFloat();
		l.spring	  =	GetFloat();
		l.damping	  =	GetFloat();
	}
}

//==================================================================================
void CoreContainer::GetJointDriveDesc( NxJointDriveDesc &d )
{
	if ( mFp )
	{
		d.spring			 = GetFloat();
		d.damping			 = GetFloat();
		d.forceLimit		 = GetFloat();
		d.driveType.bitField = GetFlag();
	}
}

//==================================================================================
void CoreContainer::GetD6JointDesc(	JointDescription &d )
{
	if ( mFp && d.mDesc )
	{
		// first, get normal description
		GetJointDesc( d );

		NxD6JointDesc *ptr = static_cast<NxD6JointDesc * >( d.mDesc );

		// now get joint specific info
		ptr->xMotion	   = (NxD6JointMotion)GetUnsigned();
		ptr->yMotion	   = (NxD6JointMotion)GetUnsigned();
		ptr->zMotion	   = (NxD6JointMotion)GetUnsigned();
		ptr->swing1Motion = (NxD6JointMotion)GetUnsigned();
		ptr->swing2Motion = (NxD6JointMotion)GetUnsigned();
		ptr->twistMotion  = (NxD6JointMotion)GetUnsigned();

		GetJointLimitSoftDesc( ptr->linearLimit );
		GetJointLimitSoftDesc( ptr->swing1Limit );
		GetJointLimitSoftDesc( ptr->swing2Limit );
		GetJointLimitSoftDesc( ptr->twistLimit.low );
		GetJointLimitSoftDesc( ptr->twistLimit.high );

		GetJointDriveDesc( ptr->xDrive );
		GetJointDriveDesc( ptr->yDrive );
		GetJointDriveDesc( ptr->zDrive );
		GetJointDriveDesc( ptr->swingDrive );
		GetJointDriveDesc( ptr->twistDrive );
		GetJointDriveDesc( ptr->slerpDrive );

		GetVec3( ptr->drivePosition );
		GetQuat( ptr->driveOrientation );
		GetVec3( ptr->driveLinearVelocity	);
		GetVec3( ptr->driveAngularVelocity );

		ptr->projectionMode	 = (NxJointProjectionMode)GetUnsigned();
		ptr->projectionDistance = GetFloat();
		ptr->projectionAngle	 = GetFloat();
		ptr->gearRatio			 = GetFloat();
		ptr->flags				 = GetFlag();
	}
}

//==================================================================================
JointDescription *CoreContainer::GetJoint( int whichJoint )
{
	JointDescription *retVal = 0;

	if ( mFp )
	{
		// k, get its type
		int	jointType =	GetInt();

		if ( ( jointType >= NX_JOINT_PRISMATIC ) && ( jointType < NX_JOINT_COUNT ) )
		{
			retVal = new JointDescription;
			if ( retVal )
			{
				// k, get other	info
				switch(	jointType )
				{
					case NX_JOINT_PRISMATIC:
					{				 
						NxPrismaticJointDesc *pjd = new NxPrismaticJointDesc;
						assert( pjd );
						if ( pjd )
						{
							retVal->mDesc = pjd;
							GetPrismaticJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_REVOLUTE:
					{
						NxRevoluteJointDesc	*rjd = new NxRevoluteJointDesc;
						assert( rjd );
						if ( rjd )
						{
							retVal->mDesc = rjd;
							GetRevoluteJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_CYLINDRICAL:
					{
						NxCylindricalJointDesc *cjd	= new NxCylindricalJointDesc;
						assert( cjd );
						if ( cjd )
						{
							retVal->mDesc = cjd;
							GetCylindricalJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_SPHERICAL:
					{
						NxSphericalJointDesc *sjd = new NxSphericalJointDesc;
						assert( sjd );
						if ( sjd )
						{
							retVal->mDesc = sjd;
							GetSphericalJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_POINT_ON_LINE:
					{
						NxPointOnLineJointDesc *poljd = new NxPointOnLineJointDesc;
						assert( poljd );
						if ( poljd )
						{
							retVal->mDesc = poljd;
							GetPointOnLineJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_POINT_IN_PLANE:
					{
						NxPointInPlaneJointDesc	*pipjd = new NxPointInPlaneJointDesc;
						assert( pipjd );
						if ( pipjd )
						{
							retVal->mDesc = pipjd;
							GetPointInPlaneJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_DISTANCE:
					{
						NxDistanceJointDesc	*djd = new NxDistanceJointDesc;
						assert( djd );
						if ( djd )
						{
							retVal->mDesc = djd;
							GetDistanceJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_PULLEY:
					{
						NxPulleyJointDesc *pjd = new NxPulleyJointDesc;
						assert( pjd );
						if ( pjd )
						{
							retVal->mDesc = pjd;
							GetPulleyJointDesc(	*retVal );
						}
					}
					break;

					case NX_JOINT_FIXED:
					{
						NxFixedJointDesc *fjd = new NxFixedJointDesc;
						assert( fjd );
						if ( fjd )
						{
							retVal->mDesc = fjd;
							GetFixedJointDesc( *retVal );
						}
					}
					break;

					case NX_JOINT_D6:
					{
						NxD6JointDesc *d = new NxD6JointDesc;
						assert( d );
						if ( d )
						{
							retVal->mDesc = d;
							GetD6JointDesc(	*retVal );
						}
					}
					break;
				}

				if ( !retVal->mDesc )
				{
					delete retVal;
					retVal = 0;
				}
			}
		}
	}

	return retVal;
}

//==================================================================================
void CoreContainer::GetScene( CoreScene *scene, int whichScene )
{
	if ( mFp &&	scene )
	{
		int	i ;

		// k, first	get	scene description
		scene->mDesc.collisionDetection   = GetBool();
		scene->mDesc.groundPlane          = GetBool();
		scene->mDesc.boundsPlanes         = GetBool();
		GetVec3( scene->mDesc.gravity );
		scene->mDesc.broadPhase			  =	(NxBroadPhaseType)GetInt();
		scene->mDesc.timeStepMethod		  =	(NxTimeStepMethod)GetInt();
		scene->mDesc.maxTimestep		  =	GetFloat();
		scene->mDesc.maxIter			  =	GetUnsigned();
		scene->mDesc.simType              = GetUnsigned();
		scene->mDesc.hwSceneType          = GetUnsigned();

#if NX_SDK_BRANCH != NX_BRANCH_RELEASE230
		scene->mDesc.pipelineSpec         = GetUnsigned();
#endif

		// k, did it have limits?
		scene->mDesc.limits = 0;
		if ( GetBool() )
		{
			scene->mDesc.limits = new NxSceneLimits;
			assert( scene->mDesc.limits );

			unsigned act	= GetUnsigned();
			unsigned bodies = GetUnsigned();
			unsigned stat	= GetUnsigned();
			unsigned dyn	= GetUnsigned();
			unsigned joints = GetUnsigned();

			if ( scene->mDesc.limits )
			{
				scene->mDesc.limits->maxNbActors		= act;
				scene->mDesc.limits->maxNbBodies		= bodies;
				scene->mDesc.limits->maxNbStaticShapes	= stat;
				scene->mDesc.limits->maxNbDynamicShapes	= dyn;
				scene->mDesc.limits->maxNbJoints		= joints;
			}
		}
		// did it have maxBounds?
		scene->mDesc.maxBounds = 0;
		if ( GetBool() )
		{
			scene->mDesc.maxBounds = new NxBounds3;
			assert( scene->mDesc.maxBounds );

			float minx = GetFloat();
			float miny = GetFloat();
			float minz = GetFloat();
			float maxx = GetFloat();
			float maxy = GetFloat();
			float maxz = GetFloat();

			if ( scene->mDesc.maxBounds )
			{
				scene->mDesc.maxBounds->min.x = minx;
				scene->mDesc.maxBounds->min.y = miny;
				scene->mDesc.maxBounds->min.z = minx;
				scene->mDesc.maxBounds->max.x = maxx;
				scene->mDesc.maxBounds->max.y = maxy;
				scene->mDesc.maxBounds->max.z = maxz;
			}
		}

		// k, read in number of	materials
		int	numMaterials = GetInt();
		for	( i	= 0; i < numMaterials; ++i )
		{
			NxMaterialDesc *nmd	= new NxMaterialDesc;
			assert(	nmd	);
			float dyn		= GetFloat();
			float stat		= GetFloat();
			float rest		= GetFloat();
			float dynV		= GetFloat();
			float statV		= GetFloat();
			int fcm			= GetInt();
			int rcm			= GetInt();
			float anisx		= GetFloat();
			float anisy		= GetFloat();
			float anisz		= GetFloat();
			unsigned flag	= GetFlag();

			// fill	in the material	description
			if ( nmd )
			{
				nmd->dynamicFriction  =	dyn;
				nmd->staticFriction	  =	stat;
				nmd->restitution	  =	rest;
				nmd->dynamicFrictionV =	dynV;
				nmd->staticFrictionV  =	statV;

				nmd->frictionCombineMode	= (NxCombineMode)fcm;
				nmd->restitutionCombineMode	= (NxCombineMode)rcm;

				// get rest of info
				nmd->dirOfAnisotropy.x = anisx;
				nmd->dirOfAnisotropy.y = anisy;
				nmd->dirOfAnisotropy.z = anisz;
				nmd->flags			   = flag;
			}

			// by default, consider	it as not having a spring description
			nmd->spring					= 0;

			// does	it have	a spring description?
			if ( GetBool() )
			{
				NxSpringDesc *desc = new NxSpringDesc;
				assert(	desc );
				float spring = GetFloat();
				float damper = GetFloat();
				float target = GetFloat();
				if ( desc )
				{
                    desc->spring		= spring;
					desc->damper		= damper;
					desc->targetValue	= target;
				}
			}

			// save	off	this material in this scene
			scene->mMaterials.push_back( nmd );
		}

		// now on towards actors
		int	numActors =	(int)GetUnsigned();
		for	( i	= 0; i < numActors;	++i	)
		{
			NxActorDesc	*nad = new NxActorDesc;
			assert(	nad );
			if ( nad )
			{
				// get the actor description
				GetActorDesc( nad );
			}
			else
			{
				NxActorDesc tmp;
				GetActorDesc( &tmp );
			}

			// now read	actor shapes
			int	numActorShapes = GetInt();
			for	( int j	= 0; j < numActorShapes; ++j )
			{
				NxShapeDesc	*shape = GetActorShape();
				nad->shapes.push_back( shape );
			}

			scene->mActors.push_back( nad );
		}

		scene->mPairCount =	GetInt();
		if ( scene->mPairCount )
		{
			assert(	scene->mPairFlagArray == 0 );
			scene->mPairFlagArray =	new	PairFlagCapsule[scene->mPairCount];
			assert(	scene->mPairFlagArray );
			// now get the pair	flags
			for	( i	= 0; i < scene->mPairCount;	++i	)
			{
				scene->mPairFlagArray[i].mFlag = GetInt();

				// note	that these are indices to the actors!!
				scene->mPairFlagArray[i].mActorIndex1 =	GetInt();
				scene->mPairFlagArray[i].mShapeIndex1 =	GetInt();
				scene->mPairFlagArray[i].mActorIndex2 =	GetInt();
				scene->mPairFlagArray[i].mShapeIndex2 =	GetInt();
			}
		}

		// now get # of	joints
		int	jointCount = GetInt();
		if ( jointCount	)
		{
			for	( i	= 0; i < jointCount; ++i )
			{
				scene->mJointArray.push_back( GetJoint(	i ) );
			}
		}

		int effectorCount = GetInt();
		if ( effectorCount )
		{
			// k, we have some effectors - but please note that we cannot do anything
			// with them yet, as the API for saveToDesc() for them is broken, and thus
			// we do not know what 2 actors to associate them with - but get the info anyways
			for ( i = 0; i < effectorCount; ++i )
			{
				NxSpringAndDamperEffectorDesc *desc = 0;
				if ( GetBool() )
				{
					NxVec3 pos1, pos2;
					float fVals[9];

					desc = new NxSpringAndDamperEffectorDesc;
					assert( desc );

					// get the info
					int bodyIndex1 = GetInt();
					int bodyIndex2 = GetInt();
					GetVec3( pos1 );
					GetVec3( pos2 );
					for ( int j = 0; j < 9; ++j )
					{
						fVals[j] = GetFloat();
					}

					if ( desc )
					{
						// k, this is a spring and linear damper effector - first set actor indexes
						desc->body1 = (NxActor *)bodyIndex1;
						desc->body2 = (NxActor *)bodyIndex2;

						// set position of first and second connection points
						desc->pos1 = pos1;
						desc->pos2 = pos2;

						// k, now set information about the linear spring
						desc->springDistCompressSaturate = fVals[0];  // springDistCompressSaturate
						desc->springDistRelaxed          = fVals[1];  // springDistRelaxed
						desc->springDistStretchSaturate  = fVals[2];  // springDistStretchSaturate
						desc->springMaxCompressForce     = fVals[3];  // springMaxCompressForce
						desc->springMaxStretchForce      = fVals[4];  // springMaxStretchForce

						// k, now set information about the linear damper
						desc->damperVelCompressSaturate  = fVals[5];  // damperVelCompressSaturate
						desc->damperVelStretchSaturate   = fVals[6];  // damperVelStretchSaturate
						desc->damperMaxCompressForce     = fVals[7];  // damperMaxCompressForce
						desc->damperMaxStretchForce      = fVals[8];  // damperMaxStretchForce
					}

					scene->mEffectorArray.push_back( desc );
				}
			}
		}

		if ( 0 )
		{
//#pragma message("TODO: Implement binary core dump	load for 'Fluids'")
		//count	= scene->getNbFluids();
		}

	}
}

//==================================================================================
CoreContainer::CoreContainer( void ) : 
	mPhysicsSDK( 0 ),
	mFp( 0 ),
	mCallback( 0 )

{
}

//==================================================================================
CoreContainer::~CoreContainer( void	)
{
	// now delete any items	we have	allocated
	ClearAllData();
}

//==================================================================================
void CoreContainer::ClearAllData( void )
{
	unsigned i;

	// delete triangle meshes
	for	( i	= 0; i < mTriangleMeshes.size(); ++i )
	{
		delete mTriangleMeshes[i];
	}
	mTriangleMeshes.clear();

	// delete convex meshes
	for	( i	= 0; i < mConvexMeshes.size(); ++i )
	{
		delete mConvexMeshes[i];
	}
	mConvexMeshes.clear();

	// delete core scenes
	for	( i	= 0; i < mScenes.size(); ++i )
	{
		delete mScenes[i];
	}
	mScenes.clear();

	mFp = 0;
}


bool CoreContainer::LoadCoreDump(const char	*fname)	// load	a core dump...
{
	return LoadCoreDump(0,fname);
}

//==================================================================================
bool CoreContainer::LoadCoreDump(NxPhysicsSDK *sdk,const char	*fname)	// load	a core dump...
{
	bool ret = false;

	mFp = fopen( fname, "rb" );

	if ( mFp )
	{
		int	version	= GetInt();

		unsigned int coreVersion = CoreDump::getCoreVersion(sdk);

		if ( version ==	coreVersion ) // if	the	same version of	core dump we support...
		{
			ret	= true;

			// k, so far so	good - versions	match
			// read	in the # of	parameters (better match NX_PARAMS_NUM_VALUES)
			int	numParams =	GetInt();
			assert(	numParams == NX_PARAMS_NUM_VALUES );

			// now read	in the parameters (note	this is	more for validating	here)
			int	j;
			unsigned i;
			for	( j	= 0; j < numParams;	++j	)
			{
				NxReal fileVal = GetFloat();

				mParameters[j] = fileVal;
				// here	we would compare the values...
				//NxParameter p	= (NxParameter)	j;
				//NxReal v		= sdk->getParameter( p );
			}

			// k, read triangle	mesh info
			unsigned numTriangleMeshes = GetInt();
			for	( i	= 0; i < numTriangleMeshes;	++i	)
			{
				// create a	new	triangle mesh desc
				NxTriangleMeshDesc *tmd	= new NxTriangleMeshDesc;
				assert(	tmd	);

				if ( tmd )
				{
					// get its information
					GetTriangleMeshDesc( tmd, i );
				}
				else
				{
					NxTriangleMeshDesc t;
					GetTriangleMeshDesc( &t, i );
				}

				// push	it back
				mTriangleMeshes.push_back( tmd );
			}

			// k, read the convex mesh info
			unsigned numConvexMeshes = GetInt();
			for	( i	= 0; i < numConvexMeshes; ++i )
			{
				// create a	new	convex mesh	desc
				NxConvexMeshDesc *cmd =	new	NxConvexMeshDesc;
				assert(	cmd	);

				if ( cmd )
				{
					// get its information
					GetConvexMeshDesc( cmd, i );
				}
				else
				{
					NxConvexMeshDesc c;

					// get its information
					GetConvexMeshDesc( &c, i );
				}

				// push	it back
				mConvexMeshes.push_back( cmd );
			}

			unsigned numSkeletons =	GetInt();
			/**	TODO : fill	this in	- right	now	does nothing
			for	( i	= 0; i < numSkeletons; ++i )
			{
				WriteSkeleton_b( mSkeletons[i] );
			}
			**/

			// now we need to read in the number of	scenes
			int	numScenes =	GetInt();

			// now read	in each	scene
			for	(int i = 0;	i <	numScenes; ++i )
			{
				// create a	new	scene
				CoreScene *scene = new CoreScene;
				assert(	scene );

				if ( scene )
				{
					// obtain the scene's specifics
					GetScene( scene, i );
				}
				else
				{
					CoreScene cs;
					GetScene( &cs, i );
				}

				// "save" it
				mScenes.push_back( scene );
			}
		}
		fclose( mFp );
		mFp = 0;
	}
	return ret;
}

//==================================================================================
CoreScene::CoreScene(void) : mPairFlagArray( 0 )
{
}

//==================================================================================
CoreScene::~CoreScene(void)
{
	delete [] mPairFlagArray;
	mPairCount = 0;

	/**
	unsigned i;

	// delete all of our materials,	etc.
	for	( i	= 0; i < mMaterials.size();	++i	)
	{
		delete mMaterials[i];
	}
	mMaterials.clear();

	// no delete all of	our	actors
	for	( i	= 0; i < mActors.size(); ++i )
	{
		delete mActors[i];
	}
	mActors.clear();
	**/
}



//==================================================================================
NxScene	* CoreContainer::InstantiateCoreDump( NxPhysicsSDK *sdk, CoreUserNotify	*callback,CoreUserScene *userScene,NxVec3 *offset)
{
	NxScene	*ret = 0;

	NxArray< NxTriangleMesh	* >	triMeshes;
	NxArray< NxConvexMesh *	>	conMeshes;
	NxArray< NxScene * >		scenes;

	// k, now we need to instantiate a new scene (this will	only return	the	first
	// one btw,	since we can actually load multiple	scenes)
	mCallback =	callback;
	if ( !mPhysicsSDK )
	{
		mPhysicsSDK	= sdk;
	}

	// first set params
	unsigned i;
	for	( i	= 0; i < NX_PARAMS_NUM_VALUES; ++i )
	{
		#if SMOKETEST
		NxPhysicsSDK_setParameter(sdk, (NxParameter)i, mParameters[i] );
		#else
		sdk->setParameter( (NxParameter)i, mParameters[i] );
		#endif
	}


	// now load	up any tri meshes
	unsigned triSize = mTriangleMeshes.size();
	for	( i	= 0; i < triSize; ++i )
	{
		NxTriangleMeshDesc *tmd	= mTriangleMeshes[i];
		if ( tmd )
		{
			// SRM : if	this tmd has a pmap, we	need to	zero it	out	here, then put it back
			NxPMap *pmap = tmd->pmap;
			tmd->pmap =	0;

			bool status	= true;
			NxInitCooking();
			UserStream us( "c:\\tri.bin", true );
			//if ( us.fp ==	NULL )
			{
				//file does	not	exist ==> We need to Cook on
				//STANDARD_TRY_BEGIN
				status = NxCookTriangleMesh( *tmd, UserStream( "c:\\tri.bin", false	) );
				//STANDARD_TRY_END(	"TriMesh Cooking to	file",__FILE__,__LINE__	)
			}
			tmd->pmap =	pmap;

			NxTriangleMesh *tm = 0;
			if ( status	)
			{
				#if SMOKETEST
				tm = NxPhysicsSDK_createTriangleMesh(sdk, UserStream( "c:\\tri.bin", true )	);
				#else
				tm = sdk->createTriangleMesh( UserStream( "c:\\tri.bin", true )	);
				#endif

				if ( tmd->pmap )
				{
				   bool	ok = tm->loadPMap( *tmd->pmap );
				   if (	ok )
				   {
						// k, do anything?
					   int s = 0;
				   }
				}
			}
			triMeshes.push_back( tm	);
		}
	}

	// now load	up any convex meshes
	unsigned conSize = mConvexMeshes.size();
	for	( i	= 0; i < conSize; ++i )
	{
		NxConvexMeshDesc *cmd =	mConvexMeshes[i];
		if ( cmd )
		{
			bool status	= true;
			NxInitCooking();
			UserStream us( "c:\\goog.bin", true	);
			//if ( us.fp ==	NULL )
			{
				//file does	not	exist ==> We need to Cook on
				//STANDARD_TRY_BEGIN
				status = NxCookConvexMesh( *cmd, UserStream( "c:\\goog.bin", false ) );
				//STANDARD_TRY_END(	"ConvexMesh	Cooking	to file",__FILE__,__LINE__ )
			}

			NxConvexMesh *cm = 0;
			if ( status	)
			{
				#if SMOKETEST
				cm = NxPhysicsSDK_createConvexMesh(sdk, UserStream( "c:\\goog.bin", true ) );
				#else
				cm = sdk->createConvexMesh( UserStream( "c:\\goog.bin", true ) );
				#endif
			}
			conMeshes.push_back( cm	);
		}
	}

	for (unsigned int sno=0; sno<mScenes.size(); sno++)
	{


		// k, get the first	core scene
		CoreScene *coreScene = mScenes[sno];

		// try to create the scene
		NxScene *newScene = 0;
		if ( userScene )
		{
			newScene = userScene->CoreCreateScene(sdk,coreScene->mDesc);
		}
		else
		{
  		#if SMOKETEST
  		newScene =	NxPhysicsSDK_createScene(sdk, coreScene->mDesc );
  		#else
  		newScene =	sdk->createScene( coreScene->mDesc );
  		#endif
  	}

		assert(	newScene );

		if ( newScene )
		{
			if ( mCallback )
			{
				mCallback->CoreNotifyScene(newScene);
			}


			// fill	in the mesh	data for all actors	now	that we	have our convex	meshes!
			for	(i = 0;	i <	coreScene->mActors.size(); ++i )
			{
				NxActorDesc	*ad	= coreScene->mActors[i];
				int	shapeSize	= ad->shapes.size();
				for	( int j	= 0; j < shapeSize;	++j	)
				{
					NxShapeDesc	*shaped	= ad->shapes[j];
					if ( shaped	)
					{
						if ( shaped->getType() == NX_SHAPE_CONVEX )
						{
							NxConvexShapeDesc *altDesc = (NxConvexShapeDesc	*)shaped;
							altDesc->meshData =	conMeshes[(unsigned)altDesc->meshData];
						}
						else if	( shaped->getType()	== NX_SHAPE_MESH )
						{
							NxTriangleMeshShapeDesc	*altDesc = (NxTriangleMeshShapeDesc	*)shaped;
							altDesc->meshData =	triMeshes[(unsigned)altDesc->meshData];
						}
					}
				}
			}

			// k, we created (or rather	we cooked) all the tri meshes and convex meshes, so
			// now let us fill in the scene	- start	with materials
			for	( i	= 0; i < coreScene->mMaterials.size(); ++i )
			{
				NxMaterialDesc *md = coreScene->mMaterials[i];

				// k, if we	are	material 0,	then we	need to	set	information, as	we always
				// have	a default material present (which is material 0)
				if ( i == 0	)
				{
					#if SMOKETEST
					NxMaterial *mat = NxScene_getMaterialFromIndex(newScene,0);
					#else
					NxMaterial *mat	= newScene->getMaterialFromIndex( 0	);
					#endif
					assert(	mat	);
					mat->loadFromDesc( *md );
				}
				else
				{
					#if SMOKETEST
					NxScene_createMaterial( newScene, *md );
					#else
					newScene->createMaterial( *md );
					#endif
				}
			}

			// now handle creation of all actors
			NxArray< NxActor * > actors;

			for	( i	= 0; i < coreScene->mActors.size();	++i	)
			{
				NxActorDesc	*ad = coreScene->mActors[i];

				if ( offset )
				{
					ad->globalPose.t += *offset;
				}

				bool valid = ad->isValid();
				assert(	valid );
				#if SMOKETEST
				NxActor	*act = NxScene_createActor(newScene, *ad );
				#else
				NxActor	*act = newScene->createActor( *ad );
				#endif
				assert(	act	);
				if ( act && mCallback )
				{
					mCallback->CoreNotifyActor(act);
				}
				actors.push_back( act );
			}

			// now create pair flags
			int	actorSize  = (int)actors.size();
			for	( i	= 0; i < (unsigned)coreScene->mPairCount; ++i )
			{
				int	actorIndex1	= coreScene->mPairFlagArray[i].mActorIndex1;
				int	actorIndex2	= coreScene->mPairFlagArray[i].mActorIndex2;
				int	shapeIndex1	= coreScene->mPairFlagArray[i].mShapeIndex1;
				int	shapeIndex2	= coreScene->mPairFlagArray[i].mShapeIndex2;

				if ( ( actorIndex1 >= 0	) && ( actorIndex1 < actorSize ) &&
						( actorIndex2 >= 0 ) &&	( actorIndex2 <	actorSize )	)
				{
					NxActor	*actor1	= actors[actorIndex1];
					NxActor	*actor2	= actors[actorIndex2];					  

					if ( ( shapeIndex1 == -1 ) && (	shapeIndex2	== -1 )	)
					{
						#if SMOKETEST
						NxScene_setActorPairFlags(newScene, *actor1, *actor2, coreScene->mPairFlagArray[i].mFlag );
						#else
						newScene->setActorPairFlags( *actor1, *actor2, coreScene->mPairFlagArray[i].mFlag );
						#endif
					}
					else
					{
						NxShape	*shape1	= 0;
						NxShape	*shape2	= 0;

						// k, get shape	pntrs
						NxShape	*const *s1 = actor1->getShapes();
						NxShape	*const *s2 = actor2->getShapes();
						int	num1 = actor1->getNbShapes();
						int	num2 = actor2->getNbShapes();
						if ( ( shapeIndex1 < num1 )	&& ( shapeIndex2 < num2	) )
						{
							shape1 = s1[shapeIndex1];
							shape2 = s2[shapeIndex2];
						}

						if ( shape1	&& shape2 )
						{
							#if SMOKETEST
							NxScene_setShapePairFlags(newScene, *shape1, *shape2, coreScene->mPairFlagArray[i].mFlag );
							#else
							newScene->setShapePairFlags( *shape1, *shape2, coreScene->mPairFlagArray[i].mFlag );
							#endif
						}
					}
				}
			}

			// now create the joints
			unsigned jointSize = coreScene->mJointArray.size();
			for	( i	= 0; i < jointSize;	++i	)
			{
				JointDescription *d = coreScene->mJointArray[i];
				if ( d && d->mDesc )
				{
					// k, we have a	joint description -	does it	have valid actor refs (when
					// we get the actor	info, it saves out indexes as to what actor
					// they	belong to, so here we convert the index	into the actual	actor)?
					int	actorRef1 =	(int)d->mDesc->actor[0];
					int	actorRef2 =	(int)d->mDesc->actor[1];

					if ( ( actorRef1 ==	-1 ) ||
							( (unsigned int)actorRef1 >= actors.size()	) )
					{
						// I do	believe	this means that	joint is connected to the world
						d->mDesc->actor[0]	= (NxActor *)0;
					}
					else
					{
						d->mDesc->actor[0]	= actors[actorRef1];						
					}

					if ( ( actorRef2 ==	-1 ) ||
							( (unsigned int)actorRef2 >= actors.size()	) )
					{
						// I do	believe	this means that	joint is connected to the world
						d->mDesc->actor[1]	= (NxActor *)0;
					}
					else
					{
						d->mDesc->actor[1]	= actors[actorRef2];
					}

					// k, now try to create	the	joint
					#if SMOKETEST
					NxJoint	*newJoint =	NxScene_createJoint(newScene, *d->mDesc );
					#else
					NxJoint	*newJoint =	newScene->createJoint( *d->mDesc );
					#endif

					if ( newJoint )
					{
						if ( d->mPlaneInfo.size() )
						{
							newJoint->setLimitPoint( d->mPlaneLimitPoint, d->mOnActor2 );
						}

						// do we want to do	anything with it - yes, if it has limits!
						for ( unsigned z = 0; z < d->mPlaneInfo.size(); ++z )
						{
							PlaneInfo *info = d->mPlaneInfo[z];
							if ( info )
							{
								NxVec3 ptOnPlane;
								ptOnPlane.x = info->mPlaneNormal.x * info->mPlaneD;
								ptOnPlane.y = info->mPlaneNormal.y * info->mPlaneD;
								ptOnPlane.z = info->mPlaneNormal.z * info->mPlaneD;
								newJoint->addLimitPlane( info->mPlaneNormal, info->mWorldLimitPt );
							}
						}
					}
				}
			}

			// and now create the effectors
			unsigned effSize = coreScene->mEffectorArray.size();
			for ( i = 0; i < effSize; ++i )
			{
				NxSpringAndDamperEffectorDesc *d = coreScene->mEffectorArray[i];
				if ( d )
				{
					// k, got a spring and damper effector desc - get the actor ref's
					int actorRef1 = (int)d->body1;
					int actorRef2 = (int)d->body2;
					if ( ( actorRef1 == -1 ) ||
							( (unsigned int)actorRef1 >= actors.size() ) )
					{
						d->body1 = (NxActor *)0;
					}
					else
					{
						d->body1 = actors[actorRef1];
					}

					if ( ( actorRef2 == -1 ) ||
							( (unsigned int)actorRef2 >= actors.size() ) )
					{
						d->body2 = (NxActor *)0;
					}
					else
					{
						d->body2 = actors[actorRef2];
					}

					// now, try to create the effector
					#if SMOKETEST
					NxSpringAndDamperEffector *eff = NxScene_createSpringAndDamperEffector(newScene, *d );
					#else
					NxSpringAndDamperEffector *eff = newScene->createSpringAndDamperEffector( *d );
					#endif

					if ( eff )
					{
						// do we want to do anything with it?
					}
				}
			}
		}

		// return the first	scene (if it exists)
		if ( sno == 0 )
		{
  		ret	= newScene;
  	}

	}

	mCallback =	0;

	// return the correct scene	(may not exist btw)
	return ret;
}

//==================================================================================
bool CoreContainer::Compare( const CoreContainer &diff,	CoreCompareNotify *callback	)
{
	int	diffcount =	0;

	//*****************
	// 1) k, first	go through the parameters and see if they are different
	unsigned i;
	for	( i=0; i<NX_PARAMS_NUM_VALUES; ++i)
	{
		// for floating	point values, we do	a difference check,	as sometimes
		// floating	point direct comparisons fail
		if ( FloatDiff( mParameters[i], diff.mParameters[i] ) )
		{
			// do what we got to do
			++diffcount;
			if ( callback->CoreDiff( (NxParameter) i, mParameters[i], diff.mParameters[i] ) )
			{
				return false;
			}
		}
	}

	//*****************
	// 2) now do triangle meshes
	if ( mTriangleMeshes.size() != diff.mTriangleMeshes.size() )
	{
		// do what we got to do
		++diffcount;
		if ( callback->CoreDiff( CD_NUM_TRIANGLE_MESHES, mTriangleMeshes.size(), diff.mTriangleMeshes.size() ) )
		{
			return false;
		}
	}
	else
	{
		// check the triangle meshes
		unsigned triSize = mTriangleMeshes.size();
		for ( i = 0; i < triSize; ++i )
		{
			// k, get each triangle mesh desc
			NxTriangleMeshDesc *t1 = mTriangleMeshes[i];
			NxTriangleMeshDesc *t2 = diff.mTriangleMeshes[i];

			if ( CompareTriMeshDescriptions( t1, t2, callback, diffcount ) )
			{
				return false;
			}
		}
	}

	//*****************
	// 3) now do convex meshes
	if ( mConvexMeshes.size() != diff.mConvexMeshes.size() )
	{
		// do what we got to do
		++diffcount;
		if ( callback->CoreDiff( CD_NUM_CONVEX_MESHES, mConvexMeshes.size(), diff.mConvexMeshes.size() ) )
		{
			return false;	
		}
	}
	else
	{
		unsigned conSize = mConvexMeshes.size();
		for ( i = 0; i < conSize; ++i )
		{
			NxConvexMeshDesc *c1 = mConvexMeshes[i];
			NxConvexMeshDesc *c2 = diff.mConvexMeshes[i];

			if ( CompareConvexMeshDescriptions( c1, c2, callback, diffcount ) )
			{
				return false;
			}
		}
	}

	//*****************
	// 4) now do core scenes
	if ( mScenes.size() != diff.mScenes.size() )
	{
		// increment the difference	counter
		++diffcount;

		// check if	we should continue or not
		if ( callback->CoreDiff( CD_NUM_CORE_SCENES, mScenes.size(), diff.mScenes.size() ) )
		{
			return false;
		}
	}
	else
	{
		// k, we got the same number of scenes, so see if they differ in any way
		unsigned sceneSize = mScenes.size();

		for ( i = 0; i < sceneSize; ++i )
		{
			// k, check if they differ or not
			CoreScene *c1 = mScenes[i];
			CoreScene *c2 = diff.mScenes[i];
			if ( CompareSceneDescriptions( c1, c2, callback, diffcount ) )
			{
				return false;
			}
		}
	}

	return true;
}

//==================================================================================
bool CoreContainer::CompareTriMeshDescriptions( NxTriangleMeshDesc *t1, 
											    NxTriangleMeshDesc *t2, 
											    CoreCompareNotify *callback,
												int &diffcount )
{
	bool bail = false;

	// k, I hate to do returns in the middle of a func, but will make it cleaner!
	if ( t1 && t2 && callback )
	{
		// should we check material indices?
		/**
		if ( t1->materialIndices != t2->materialIndices )
		{
			++numDiffs;
		}
		**/

		// does convex edge threshold differ?
		if ( FloatDiff( t1->convexEdgeThreshold, t2->convexEdgeThreshold ) )
		{
			++diffcount;
			bail = callback->CoreDiff( TMD_CET, *t1, *t2 );
		}

		// do flags differ?
		if ( !bail && ( t1->flags != t2->flags ) )
		{
			++diffcount;
			bail = callback->CoreDiff( TMD_FLAGS, *t1, *t2 );
		}

		// does height field vertical axis differ?
		if ( !bail && ( t1->heightFieldVerticalAxis != t2->heightFieldVerticalAxis ) )
		{
			++diffcount;
			bail = callback->CoreDiff( TMD_HFVA, *t1, *t2 );
		}

		// does height field extent differ
		if ( !bail && FloatDiff( t1->heightFieldVerticalExtent, t2->heightFieldVerticalExtent ) )
		{
			++diffcount;
			bail = callback->CoreDiff( TMD_HFVE, *t1, *t2 );
		}

		// does material index stride differ
		if ( !bail && ( t1->materialIndexStride != t2->materialIndexStride ) )
		{
			++diffcount;
			bail = callback->CoreDiff( TMD_MIS, *t1, *t2 );
		}

		// does pmap info differ?
		if ( !bail )
		{
			TriangleMeshDifferences type;
			bool different = false;

			if ( ( t1->pmap && !t2->pmap ) || ( !t1->pmap && t2->pmap ) )
			{
				different = true;
				++diffcount;
				type = TMD_PMAP_MISSING;
			}
			else if ( t1->pmap && t2->pmap && ( t1->pmap->dataSize != t2->pmap->dataSize ) )
			{
				different = true;
				++diffcount;
				type = TMD_PMAP_NUMVERTS;			
			}

			if ( different && callback->CoreDiff( type, *t1, *t2 ) )
			{
				bail = true;
			}
		}

		// k, does any of the vert info differ?
		if ( !bail )
		{
			TriangleMeshDifferences type;
			bool different = false;

			if ( t1->numVertices != t2->numVertices )
			{
				++diffcount;
				type = TMD_VERT_NUM;
				different = true;
			}
			else if ( t1->pointStrideBytes != t2->pointStrideBytes )
			{
				++diffcount;
				type = TMD_VERT_STRIDE;
				different = true;
			}
			else if ( memcmp( t1->points, t2->points, t1->numVertices*t1->pointStrideBytes/3 ) != 0 )
			{
				++diffcount;
				type = TMD_VERT_PTS;
				different = true;
			}

			if ( different && callback->CoreDiff( type, *t1, *t2 ) )
			{
				bail = true;
			}			
		}

		// k, does any of the tri info differ?
		if ( !bail )
		{
			TriangleMeshDifferences type;
			bool different = false;
			int triSize = t1->numTriangles*t1->triangleStrideBytes;

			if ( t1->numTriangles != t2->numTriangles )
			{
				++diffcount;
				type = TMD_TRI_NUMVERTS;
				different = true;
			}
			else if ( t1->triangleStrideBytes != t2->triangleStrideBytes )
			{
				++diffcount;
				type = TMD_TRI_STRIDE;
				different = true;
			}
			else if ( memcmp( t1->triangles, t2->triangles, triSize ) != 0 )
			{
				++diffcount;
				type = TMD_TRI_TRIS;
				different = true;
			}

			if ( different && callback->CoreDiff( type, *t1, *t2 ) )
			{
				bail = true;
			}			
		}
	}

	return bail;
}

//==================================================================================
bool CoreContainer::CompareConvexMeshDescriptions( NxConvexMeshDesc *c1, 
												   NxConvexMeshDesc *c2, 
												   CoreCompareNotify *callback,
												   int &diffcount )
{
	bool bail = false;

	if ( c1 && c2 && callback )
	{
		// do flags differ?
		if ( c1->flags != c2->flags )
		{
			++diffcount;
			bail = callback->CoreDiff( CMD_FLAGS, *c1, *c2 );
		}

		// k, does any of the vert info differ?
		if ( !bail )
		{
			ConvexMeshDifferences type;
			bool different = false;

			if ( c1->numVertices != c2->numVertices )
			{
				++diffcount;
				type = CMD_VERT_NUM;
				different = true;
			}
			else if ( c1->pointStrideBytes != c2->pointStrideBytes )
			{
				++diffcount;
				type = CMD_VERT_STRIDE;
				different = true;
			}
			else if ( memcmp( c1->points, c2->points, c1->numVertices*c1->pointStrideBytes/3 ) != 0 )
			{
				++diffcount;
				type = CMD_VERT_PTS;
				different = true;
			}

			if ( different && callback->CoreDiff( type, *c1, *c2 ) )
			{
				bail = true;
			}			
		}

		// k, does any of the tri info differ?
		if ( !bail )
		{
			bool different = false;
			ConvexMeshDifferences type;
			int triSize = c1->numTriangles*c1->triangleStrideBytes;

			if ( c1->numTriangles != c2->numTriangles )
			{
				++diffcount;
				type = CMD_TRI_NUMVERTS;
				different = true;
			}
			else if ( c1->triangleStrideBytes != c2->triangleStrideBytes )
			{
				++diffcount;
				type = CMD_TRI_STRIDE;
				different = true;
			}
			else if ( c1->triangles && c2->triangles && 
				    ( memcmp( c1->triangles, c2->triangles, triSize ) != 0 ) )
			{
				++diffcount;
				type = CMD_TRI_TRIS;
				different = true;
			}

			if ( different && callback->CoreDiff( type, *c1, *c2 ) )
			{
				bail = true;
			}			
		}
	}

	return bail;
}

//==================================================================================
bool CoreContainer::CompareSceneDescriptions( CoreScene *c1, CoreScene *c2, CoreCompareNotify *callback, int &diffcount )
{
	bool bail = false;

	if ( c1 && c2 && callback )
	{
		// k, now go through materials
		if ( c1->mMaterials.size() != c2->mMaterials.size() )
		{
			++diffcount;
			bail = callback->CoreDiff( CD_NUM_MATERIALS, c1->mMaterials.size(), c2->mMaterials.size() );
		}
		else
		{
			// k, should we go through each material - sure what the hell.  But, we do NOT
			// want to make up a core difference type for each material - if we find a difference,
			// it is just a CD_MATERIAL_TYPE diff
			unsigned matSize = c1->mMaterials.size();
			for ( unsigned i = 0; !bail && (i < matSize); ++i )
			{
				NxMaterialDesc *m1 = c1->mMaterials[i];
				NxMaterialDesc *m2 = c2->mMaterials[i];

				if ( m1 && m2 )
				{
					if ( Vec3Diff( m1->dirOfAnisotropy, m2->dirOfAnisotropy ) ||
						 FloatDiff( m1->dynamicFriction,m2->dynamicFriction ) || 
						 FloatDiff( m1->dynamicFrictionV, m2->dynamicFrictionV ) ||
						 FloatDiff( m1->restitution, m2->restitution ) ||
						 FloatDiff( m1->staticFriction, m2->staticFriction ) ||
						 FloatDiff( m1->staticFrictionV, m2->staticFrictionV ) ||
						 ( m1->frictionCombineMode != m2->frictionCombineMode ) ||
						 ( m1->flags != m2->flags ) ||
						 ( m1->restitutionCombineMode != m2->restitutionCombineMode )
					  )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_MATERIAL_DESC, i, *m1, *m2 );
					}
					else if ( ( m1->spring && !m2->spring ) || ( !m1->spring && m2->spring ) )
					{
						bail = callback->CoreDiff( CD_MATERIAL_DESC, i, *m1, *m2 );				
					}
					else if ( m1->spring && m2->spring && 
							( FloatDiff( m1->spring->damper, m2->spring->damper ) || 
							  FloatDiff( m1->spring->spring, m2->spring->spring ) ||
							  FloatDiff( m1->spring->targetValue, m2->spring->targetValue ) ) )
					{
						bail = callback->CoreDiff( CD_MATERIAL_DESC, i, *m1, *m2 );
					}
				}
				else
				{
					++diffcount;
				}
			}
		}

		// do scene descriptions
		int numDiffs = ( !bail ? SceneDescDiff( c1->mDesc, c2->mDesc ) : 0 );
		if ( numDiffs )
		{
			diffcount += numDiffs;
			bail = callback->CoreDiff( c1->mDesc, c2->mDesc );
		}

		// now do actors
		if ( !bail && ( c1->mActors.size() != c2->mActors.size() ) )
		{
			++diffcount;
			bail = callback->CoreDiff( CD_NUM_ACTORS, c1->mActors.size(), c2->mActors.size() );
		}
		else
		{
			// check each actor
			unsigned actorSize = c1->mActors.size();
			for ( unsigned i = 0; !bail && (i < actorSize); ++i )
			{
				NxActorDesc *a1 = c1->mActors[i];
				NxActorDesc *a2 = c2->mActors[i];

				if ( a1 && a2 )
				{
					// check individual items
					if ( FloatDiff( a1->density, a2->density ) ||
						 ( a1->flags != a2->flags ) ||
						 ( a1->group != a2->group ) ||
						 ( a1->name && !a2->name ) ||
						 ( !a1->name && a2->name ) ||
						 ( a1->name && a2->name && strcmp( a1->name, a2->name ) ) )
					{
						// actor diff occurred
						++diffcount;
						bail = callback->CoreDiff( CD_ACTOR_DESC, i, *a1, *a2 );
					}
					// now check actor shape sizes
					else if ( a1->shapes.size() != a2->shapes.size() )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_NUM_ACTOR_SCENES, a1->shapes.size(), a2->shapes.size() );
					}
					// are both body desc's present/missing?
					else if ( ( a1->body && !a2->body ) || ( !a1->body && a2->body ) )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_ACTOR_BODY_DESC_DIFF, *a1, *a2 );
					}
					// check rotation, position, etc.
					else if ( memcmp( &a1->globalPose, &a2->globalPose, sizeof(NxMat34) ) != 0 )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_ACTOR_STATE_POSROT_INFO, a1->globalPose, a2->globalPose );						
					}
					else if ( a1->body && a2->body && 
						    ( Vec3Diff( a1->body->linearVelocity, a2->body->linearVelocity ) ||
							  Vec3Diff( a1->body->angularVelocity, a2->body->angularVelocity ) ) )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_ACTOR_STATE_VEL_INFO, *a1->body, *a2->body );
					}
					// now check other individual NxBodyDesc member variables
					else if ( a1->body && a2->body && 
						    ( FloatDiff( a1->body->angularDamping, a2->body->angularDamping ) ||
							  FloatDiff( a1->body->linearDamping, a2->body->linearDamping ) ||
							  FloatDiff( a1->body->mass, a2->body->mass ) ||
							  FloatDiff( a1->body->CCDMotionThreshold, a2->body->CCDMotionThreshold ) ||
							  FloatDiff( a1->body->wakeUpCounter, a2->body->wakeUpCounter ) ||
							  FloatDiff( a1->body->maxAngularVelocity, a2->body->maxAngularVelocity ) ||
							  FloatDiff( a1->body->sleepAngularVelocity, a2->body->sleepAngularVelocity ) ||
							  FloatDiff( a1->body->sleepLinearVelocity, a2->body->sleepLinearVelocity ) ||
							  ( a1->body->solverIterationCount != a2->body->solverIterationCount ) ||
							  ( a1->body->flags != a2->body->flags ) ||
							  ( Vec3Diff( a1->body->massSpaceInertia, a2->body->massSpaceInertia ) ) ||
							  ( memcmp( &a1->body->massSpaceInertia, &a2->body->massSpaceInertia, sizeof(NxMat34) ) ) ) ) 
					{
						++diffcount;
						bail = callback->CoreDiff( CD_ACTOR_BODY_DESC_MEMBER_INFO, *a1->body, *a2->body );					
					}
					else
					{
						// k, # of shapes are same - compare them
						int	shapeSize = a1->shapes.size();
						for	( int j	= 0; !bail && (j < shapeSize); ++j )
						{
							NxShapeDesc	*s1= a1->shapes[j];
							NxShapeDesc	*s2	= a2->shapes[j];

							// validate they both exist
							if ( s1 && s2 )
							{
								// k, check the shape desc items
								if ( ( s1->shapeFlags != s2->shapeFlags ) ||
									 ( s1->group != s2->group ) ||
									 ( s1->materialIndex != s2->materialIndex ) ||
#ifdef NX_SUPPORT_NEW_FILTERING
									 ( s1->groupsMask.bits0 != s2->groupsMask.bits0 ) ||
									 ( s1->groupsMask.bits1 != s2->groupsMask.bits1 ) ||
									 ( s1->groupsMask.bits2 != s2->groupsMask.bits2 ) ||
									 ( s1->groupsMask.bits3 != s2->groupsMask.bits3 ) ||
#endif
									 FloatDiff( s1->mass, s2->mass ) ||
									 FloatDiff( s1->density, s2->density ) ||
									 FloatDiff( s1->skinWidth, s2->skinWidth ) )
								{
									++diffcount;
									bail = callback->CoreDiff( CD_ACTOR_SHAPE_DESC, *s1, *s2 );
								}
								// check the names
								else if ( ( s1->name && !s2->name ) || 
									      ( !s1->name && s2->name ) ||
									      ( s1->name && s2->name && strcmp( s1->name, s2->name ) ) )
								{
									++diffcount;
									bail = callback->CoreDiff( CD_ACTOR_SHAPE_NAME_DESC, *s1, *s2 );								
								}
								else
								{
									// should I do anything about the ccd skeleton?
								}
							}
							else 
							{
								// shape desc is missing
								++diffcount;
								bail = callback->CoreDiff( CD_ACTOR_SHAPE_DESC_MISSING, j, *a1, *a2 );
							}
						}
					}
				}
				else
				{
					++diffcount;
				}
			}
		}

		// do pair counts
		if ( !bail && ( c1->mPairCount != c2->mPairCount ) )
		{
			++diffcount;
			bail = callback->CoreDiff( CD_NUM_PAIR_COUNTS, c1->mPairCount, c2->mPairCount );
		}
		else
		{
			// now check the pair flags
			for	( int i = 0; !bail && (i < c1->mPairCount); ++i )
			{
				const PairFlagCapsule &p1 = c1->mPairFlagArray[i];
				const PairFlagCapsule &p2 = c2->mPairFlagArray[i];

				// check if anything differs
				if ( ( p1.mFlag != p2.mFlag ) ||
					 ( p1.mShapeIndex1 != p2.mShapeIndex1 ) ||
					 ( p1.mShapeIndex2 != p2.mShapeIndex2 ) ||
					 ( p1.mActorIndex1 != p2.mActorIndex1 ) ||
					 ( p1.mActorIndex2 != p2.mActorIndex2 ) )
				{
					// k, pair capsule's differ
					++diffcount;
					bail = callback->CoreDiff( CD_PAIR_FLAG_DESC, p1, p2 );
				}
			}
		}

		// now do joints
		if ( !bail && ( c1->mJointArray.size() != c2->mJointArray.size() ) )
		{
			++diffcount;
			bail = callback->CoreDiff( CD_NUM_JOINTS, c1->mJointArray.size(), c2->mJointArray.size() );
		}
		else
		{
			// check the joints
			unsigned jointSize = c1->mJointArray.size();
			for ( unsigned i = 0; !bail && (i < jointSize); ++i )
			{
				JointDescription *jd1 = c1->mJointArray[i];
				JointDescription *jd2 = c2->mJointArray[i];

				if ( jd1 && jd2 && jd1->mDesc && jd2->mDesc )
				{
					NxJointDesc *j1 = jd1->mDesc;
					NxJointDesc *j2 = jd2->mDesc;

					if ( j1 && j2 )
					{
						if ( ( j1->getType() != j2->getType() ) ||
							( j1->actor[0] != j2->actor[0] ) ||
							( j1->actor[1] != j2->actor[1] ) ||
							( j1->jointFlags != j2->jointFlags ) ||
							FloatDiff( j1->maxForce, j2->maxForce ) ||
							FloatDiff( j1->maxTorque, j2->maxTorque ) )
						{
							++diffcount;
							bail = callback->CoreDiff( CD_JOINT_DESC_DIFF, *j1, *j2 );
						}
						else if ( ( j1->name && !j2->name ) ||
								( !j1->name && j2->name ) ||
								( j1->name && j2->name && strcmp( j1->name, j2->name ) ) )
						{
							++diffcount;
							bail = callback->CoreDiff( CD_JOINT_DESC_NAME_DIFF, *j1, *j2 );					
						}
						else if ( Vec3Diff( j1->localNormal[0], j2->localNormal[0] ) ||
								Vec3Diff( j1->localNormal[1], j2->localNormal[1] ) ||
								Vec3Diff( j1->localAxis[0], j2->localAxis[0] ) ||
								Vec3Diff( j1->localAxis[1], j2->localAxis[1] ) ||
								Vec3Diff( j1->localAnchor[0], j2->localAnchor[0] ) ||
								Vec3Diff( j1->localAnchor[1], j2->localAnchor[1] ) )
						{
							++diffcount;
							bail = callback->CoreDiff( CD_JOINT_DESC_VECTOR_DIFF, *j1, *j2 );										
						}
						else
						{
							NxJointType type = j1->getType();

							// k, do joint type specific comparison, except for NxPrismaticJointDesc,
							// NxCylindricalJointDesc, NxPointOnLineJointDesc, NxPointInPlaneJointDesc,
							// and NxFixedJointDesc, as they are basic and don't have any extra params!
							switch(	type )
							{
								case NX_JOINT_REVOLUTE:
								{
									NxRevoluteJointDesc *p1 = static_cast<NxRevoluteJointDesc *>( j1 );
									NxRevoluteJointDesc *p2 = static_cast<NxRevoluteJointDesc *>( j2 );
									if ( ( p1->flags != p2->flags ) ||
										( p1->projectionMode != p2->projectionMode ) ||
										FloatDiff( p1->projectionAngle, p2->projectionAngle ) ||
										FloatDiff( p1->projectionDistance, p2->projectionDistance ) )
									{
										// "normal" rev joint diff
										++diffcount;
										bail = callback->CoreDiff( CD_REV_JOINT_DESC_DIFF, *j1, *j2 );
									}
									else if ( JointLimitDescDiff( p1->limit.low, p2->limit.low ) )
									{
										// low limit diff
										++diffcount;
										bail = callback->CoreDiff( CD_REV_JOINT_DESC_LOW_LIMIT_DIFF, *j1, *j2 );
									}
									else if ( JointLimitDescDiff( p1->limit.high, p2->limit.high ) )
									{
										// high limit diff
										++diffcount;
										bail = callback->CoreDiff( CD_REV_JOINT_DESC_HIGH_LIMIT_DIFF, *j1, *j2 );
									}
									else if ( MotorDescDiff( p1->motor, p2->motor ) )
									{
										// motor diff
										++diffcount;
										bail = callback->CoreDiff( CD_REV_JOINT_DESC_MOTOR_DIFF, *j1, *j2 );
									}
									else if ( SpringDescDiff( p1->spring, p2->spring ) )
									{
										// spring diff
										++diffcount;
										bail = callback->CoreDiff( CD_REV_JOINT_DESC_SPRING_DIFF, *j1, *j2 );
									}
								}
								break;

								case NX_JOINT_SPHERICAL:
								{
									NxSphericalJointDesc *p1 = static_cast<NxSphericalJointDesc *>( j1 );
									NxSphericalJointDesc *p2 = static_cast<NxSphericalJointDesc *>( j2 );
									
									if ( SpringDescDiff( p1->twistSpring, p2->twistSpring ) ||
										SpringDescDiff( p1->swingSpring, p2->swingSpring ) ||
										SpringDescDiff( p1->jointSpring, p2->jointSpring ) )
									{
										// spring diff
										++diffcount;
										bail = callback->CoreDiff( CD_SPHERE_JOINT_DESC_SPRING_DIFF, *j1, *j2 );
									}
									else if ( JointLimitDescDiff( p1->twistLimit.low, p2->twistLimit.low ) ||
											JointLimitDescDiff( p1->twistLimit.high, p2->twistLimit.high ) ||
											JointLimitDescDiff( p1->swingLimit, p2->swingLimit ) )
									{
										// LIMIT diff
										++diffcount;
										bail = callback->CoreDiff( CD_SPHERE_JOINT_DESC_LIMIT_DIFF, *j1, *j2 );
									}
									else if ( Vec3Diff( p1->swingAxis, p2->swingAxis ) )
									{
										// axis diff
										++diffcount;
										bail = callback->CoreDiff( CD_SPHERE_JOINT_DESC_SWINGAXIS_DIFF, *j1, *j2 );								
									}
									else if ( FloatDiff( p1->projectionDistance, p2->projectionDistance ) ||
											( p1->flags != p2->flags ) ||
											( p1->projectionMode != p2->projectionMode ) )
									{
										// "normal" diff
										++diffcount;
										bail = callback->CoreDiff( CD_SPHERE_JOINT_DESC_DIFF, *j1, *j2 );								
									}
								}
								break;

								case NX_JOINT_DISTANCE:
								{
									NxDistanceJointDesc *p1 = static_cast<NxDistanceJointDesc *>( j1 );
									NxDistanceJointDesc *p2 = static_cast<NxDistanceJointDesc *>( j2 );

									if ( FloatDiff( p1->minDistance, p2->minDistance ) ||
										FloatDiff( p1->maxDistance, p2->maxDistance ) ||
										( p1->flags != p2->flags ) )
									{
										++diffcount;
										bail = callback->CoreDiff( CD_DIST_JOINT_DESC_DIFF, *j1, *j2 );								
									}
									else if ( SpringDescDiff( p1->spring, p2->spring ) )
									{
										// spring diff
										++diffcount;
										bail = callback->CoreDiff( CD_DIST_JOINT_DESC_SPRING_DIFF, *j1, *j2 );								
									}
								}
								break;

								case NX_JOINT_PULLEY:
								{
									NxPulleyJointDesc *p1 = static_cast<NxPulleyJointDesc *>( j1 );
									NxPulleyJointDesc *p2 = static_cast<NxPulleyJointDesc *>( j2 );

									if ( FloatDiff( p1->distance, p2->distance ) ||
										FloatDiff( p1->stiffness, p2->stiffness ) ||
										FloatDiff( p1->ratio, p2->ratio ) ||
										( p1->flags != p2->flags ) )
									{
										// normal pully diff
										++diffcount;
										bail = callback->CoreDiff( CD_PULLEY_JOINT_DESC_DIFF, *j1, *j2 );								

									}
									else if ( MotorDescDiff( p1->motor, p2->motor ) )
									{
										// motor diff
										++diffcount;
										bail = callback->CoreDiff( CD_PULLEY_JOINT_DESC_MOTOR_DIFF, *j1, *j2 );								

									}
									else if ( Vec3Diff( p1->pulley[0], p2->pulley[0] ) ||
											Vec3Diff( p1->pulley[1], p2->pulley[1] ) )
									{
										// pulley diff
										++diffcount;
										bail = callback->CoreDiff( CD_PULLEY_JOINT_DESC_PULLEY_DIFF, *j1, *j2 );
									}
								}
								break;

								case NX_JOINT_D6:
								{
									NxD6JointDesc *p1 = static_cast<NxD6JointDesc *>( j1 );
									NxD6JointDesc *p2 = static_cast<NxD6JointDesc *>( j2 );

									if ( ( p1->xMotion != p2->xMotion ) ||
										( p1->yMotion != p2->yMotion ) ||
										( p1->zMotion != p2->zMotion ) ||
										( p1->swing1Motion != p2->swing1Motion ) ||
										( p1->swing2Motion != p2->swing2Motion ) ||
										( p1->twistMotion != p2->twistMotion ) )
									{
										// motion diff
										++diffcount;
										bail = callback->CoreDiff( CD_D6_JOINT_DESC_MOTION_DIFF, *j1, *j2 );								
									}
									else if ( ( p1->projectionMode != p2->projectionMode ) ||
											( p1->flags != p2->flags ) ||
											FloatDiff( p1->projectionAngle, p2->projectionAngle ) ||
											FloatDiff( p1->projectionDistance, p2->projectionDistance ) ||
											FloatDiff( p1->gearRatio, p2->gearRatio ) )
									{
										// "normal" diff
										++diffcount;
										bail = callback->CoreDiff( CD_D6_JOINT_DESC_DIFF, *j1, *j2 );								
									}
									else if ( JointLimitSoftDescDiff( p1->linearLimit, p2->linearLimit ) ||
											JointLimitSoftDescDiff( p1->swing1Limit, p2->swing1Limit ) ||
											JointLimitSoftDescDiff( p1->swing2Limit, p2->swing2Limit ) ||
											JointLimitSoftDescDiff( p1->twistLimit.low, p2->twistLimit.low ) ||
											JointLimitSoftDescDiff( p1->twistLimit.high, p2->twistLimit.high ) )
									{
										// soft limit diff
										++diffcount;
										bail = callback->CoreDiff( CD_D6_JOINT_SOFT_DESC_DIFF, *j1, *j2 );								
									}
									else if ( JointDriveDescDiff( p1->xDrive, p2->xDrive ) ||
											JointDriveDescDiff( p1->yDrive, p2->yDrive ) ||
											JointDriveDescDiff( p1->zDrive, p2->zDrive ) ||
											JointDriveDescDiff( p1->swingDrive, p2->swingDrive ) ||
											JointDriveDescDiff( p1->twistDrive, p2->twistDrive ) ||
											JointDriveDescDiff( p1->slerpDrive, p2->slerpDrive ) )
									{
										// joint drive diff
										++diffcount;
										bail = callback->CoreDiff( CD_D6_JOINT_DRIVE_DESC_DIFF, *j1, *j2 );								
									}
									else if ( Vec3Diff( p1->drivePosition, p2->drivePosition ) ||
											Vec3Diff( p1->driveLinearVelocity, p2->driveLinearVelocity ) ||
											Vec3Diff( p1->driveAngularVelocity, p2->driveAngularVelocity ) )
									{
										// vec diff
										++diffcount;
										bail = callback->CoreDiff( CD_D6_JOINT_VEC_DESC_DIFF, *j1, *j2 );
									}
									else if ( QuatDiff( p1->driveOrientation, p2->driveOrientation ) )
									{
										// quat diff
										++diffcount;
										bail = callback->CoreDiff( CD_D6_JOINT_QUAT_DESC_DIFF, *j1, *j2 );
									}
								}
								break;
							}

						}
					}
					else
					{
						++diffcount;
					}
				}
				else
				{
					++diffcount;
				}

				if ( jd1 && jd2 )
				{
					if ( jd1->mPlaneInfo.size() != jd2->mPlaneInfo.size() )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_NUM_JOINT_LIMIT_INFO, jd1->mPlaneInfo.size(), jd2->mPlaneInfo.size() ); 
					}
					// only check plane limit pts if plane information exists!
					else if ( jd1->mPlaneInfo.size() )
					{
						if ( Vec3Diff( jd1->mPlaneLimitPoint, jd2->mPlaneLimitPoint ) )
						{
							++diffcount;
							bail = callback->CoreDiff( CD_JOINT_LIMIT_PLANE_POINT, jd1->mPlaneLimitPoint, jd2->mPlaneLimitPoint );
						}
						else
						{
							for ( unsigned j = 0; !bail && (i < jd1->mPlaneInfo.size()); ++j )
							{
								PlaneInfo *p1 = jd1->mPlaneInfo[j];
								PlaneInfo *p2 = jd2->mPlaneInfo[j];

								if ( p1 && p2 )
								{
									if ( Vec3Diff( p1->mPlaneNormal, p2->mPlaneNormal ) )
									{
										++diffcount;
										bail = callback->CoreDiff( CD_JOINT_LIMIT_PLANE_NORMAL, *p1, *p2 );
									}
									else if ( FloatDiff( p1->mPlaneD, p2->mPlaneD ) )
									{
										++diffcount;
										bail = callback->CoreDiff( CD_JOINT_LIMIT_PLANE_D, *p1, *p2 );
									}
									else if ( Vec3Diff( p1->mWorldLimitPt, p2->mWorldLimitPt ) )
									{
										++diffcount;
										bail = callback->CoreDiff( CD_JOINT_LIMIT_PLANE_WORLD_PT, *p1, *p2 );
									}
								}
								else
								{
									++diffcount;
								}
							}
						}
					}
				}
			}
		}

		// now we do the effectors
		if ( !bail && ( c1->mEffectorArray.size() != c2->mEffectorArray.size() ) )
		{
			++diffcount;
			bail = callback->CoreDiff( CD_NUM_SADE, c1->mEffectorArray.size(), c2->mEffectorArray.size() );
		}
		else
		{
			// k, compare the spring and damper effectors
			unsigned effSize = c1->mEffectorArray.size();
			for ( unsigned i = 0; !bail && (i < effSize); ++i )
			{
				NxSpringAndDamperEffectorDesc *s1 = c1->mEffectorArray[i];
				NxSpringAndDamperEffectorDesc *s2 = c2->mEffectorArray[i];

				if ( s1 && s2 )
				{
					if ( ( s1->body1 != s2->body1 ) || ( s2->body2 != s2->body2 ) )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_SADE_BODY_DIFF, *s1, *s2 );					
					}
					else if ( FloatDiff( s1->damperMaxCompressForce, s2->damperMaxCompressForce ) ||
						      FloatDiff( s1->damperMaxStretchForce, s2->damperMaxStretchForce ) ||
							  FloatDiff( s1->damperVelCompressSaturate, s2->damperVelCompressSaturate ) ||
							  FloatDiff( s1->damperVelStretchSaturate, s2->damperVelStretchSaturate ) )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_SADE_DAMPER_PARAM, *s1, *s2 );
					}
					else if ( FloatDiff( s1->springDistCompressSaturate, s2->springDistCompressSaturate ) ||
						      FloatDiff( s1->springDistRelaxed, s2->springDistRelaxed ) ||
							  FloatDiff( s1->springDistStretchSaturate, s2->springDistStretchSaturate ) ||
							  FloatDiff( s1->springMaxCompressForce, s2->springMaxCompressForce ) ||
							  FloatDiff( s1->springMaxStretchForce, s2->springMaxStretchForce ) )
					{
						++diffcount;
						bail = callback->CoreDiff( CD_SADE_SPRING_PARAM, *s1, *s2 );	
					}
				}
			}
		}
	}

	return bail;
}

//==================================================================================
bool CoreContainer::FloatDiff( const float &a, const float &b, float tolerance ) const
{
	return ( fabs( a - b ) > tolerance );
}

//==================================================================================
bool CoreContainer::Vec3Diff( const NxVec3 &a, const NxVec3 &b, float tolerance ) const
{
	return ( ( fabs( a.x - b.x ) > tolerance ) ||
		     ( fabs( a.y - b.y ) > tolerance ) ||
			 ( fabs( a.z - b.z ) > tolerance ) );
}

//==================================================================================
bool CoreContainer::QuatDiff( const NxQuat &a, const NxQuat &b, float tolerance ) const
{
	return ( ( fabs( a.x - b.x ) > tolerance ) ||
		     ( fabs( a.y - b.y ) > tolerance ) ||
			 ( fabs( a.z - b.z ) > tolerance ) ||
			 ( fabs( a.w - b.w ) > tolerance ) );
}

//==================================================================================
bool CoreContainer::JointLimitSoftDescDiff( const NxJointLimitSoftDesc &a, 
										    const NxJointLimitSoftDesc &b,
											float tolerance ) const
{
	return ( ( fabs( a.value - b.value ) > tolerance ) ||
		     ( fabs( a.restitution - b.restitution ) > tolerance ) ||
			 ( fabs( a.spring - b.spring ) > tolerance ) ||
			 ( fabs( a.damping - b.damping ) > tolerance ) );
}

//==================================================================================
bool CoreContainer::JointDriveDescDiff( const NxJointDriveDesc &a, const NxJointDriveDesc &b,
									    float tolerance ) const
{
	return ( ( a.driveType.bitField != b.driveType.bitField ) |\
		     ( fabs( a.spring - b.spring ) > tolerance ) ||
		     ( fabs( a.damping - b.damping ) > tolerance ) ||
		     ( fabs( a.forceLimit - b.forceLimit ) > tolerance ) );
}

//==================================================================================
bool CoreContainer::SpringDescDiff( const NxSpringDesc &a, const NxSpringDesc &b, float tolerance ) const
{
	return ( ( fabs( a.damper - b.damper ) > tolerance ) ||
		     ( fabs( a.spring - b.spring ) > tolerance ) ||
			 ( fabs( a.targetValue - b.targetValue ) > tolerance ) );
}

//==================================================================================
bool CoreContainer::MotorDescDiff( const NxMotorDesc &a, const NxMotorDesc &b, float tolerance ) const
{
	return ( ( a.freeSpin != b.freeSpin ) ||
		     ( fabs( a.maxForce - b.maxForce ) > tolerance ) ||
			 ( fabs( a.velTarget - b.velTarget ) > tolerance ) );
}

//==================================================================================
bool CoreContainer::JointLimitDescDiff( const NxJointLimitDesc &a, const NxJointLimitDesc &b, float tolerance ) const
{
	return ( ( fabs( a.hardness - b.hardness ) > tolerance ) ||
		     ( fabs( a.restitution - b.restitution ) > tolerance ) ||
			 ( fabs( a.value - b.value ) > tolerance ) );
		    
}

//==================================================================================
int CoreContainer::SceneDescDiff( const NxSceneDesc &d1, const NxSceneDesc &d2 ) const
{
	int numDiffs = 0;
	if ( d1.broadPhase != d2.broadPhase )
	{
		++numDiffs;
	}
	
	if ( d1.groundPlane != d2.groundPlane )
	{
		++numDiffs;
	}
	
	if ( d1.boundsPlanes != d2.boundsPlanes )
	{
		++numDiffs;
	}
	
	if ( d1.collisionDetection != d2.collisionDetection )
	{
		++numDiffs;
	}
	
	if ( d1.simType != d2.simType )
	{
		++numDiffs;
	}
	
	if ( d1.hwSceneType != d2.hwSceneType )
	{
		++numDiffs;
	}
	
#if NX_SDK_BRANCH != NX_BRANCH_RELEASE230
	if ( d1.pipelineSpec != d2.pipelineSpec )
	{
		++numDiffs;
	}
#endif	

	if ( d1.maxIter != d2.maxIter )
	{
		++numDiffs;
	}
	
	if ( d1.timeStepMethod != d2.timeStepMethod )
	{
		++numDiffs;
	}
	
	if ( Vec3Diff( d1.gravity, d2.gravity ) )
	{
		++numDiffs;
	}
	
	if ( FloatDiff( d1.maxTimestep, d2.maxTimestep ) )
	{
		++numDiffs;		
	}
	
	// these are user pointers, so we can only test if they are present on one, and not
	// present on the other
	if ( ( d1.userNotify && !d2.userNotify ) || ( !d1.userNotify && d2.userNotify ) )
	{
		++numDiffs;			
	}

	if ( ( d1.userTriggerReport && !d2.userTriggerReport ) || ( !d1.userTriggerReport && d2.userTriggerReport ) )
	{
		++numDiffs;			
	}

	if ( ( d1.userContactReport && !d2.userContactReport ) || ( !d1.userContactReport && d2.userContactReport ) )
	{
		++numDiffs;			
	}

	if ( ( d1.maxBounds && !d2.maxBounds ) || ( !d1.maxBounds && d2.maxBounds ) )
	{
		++numDiffs;	
	}
	else if ( d1.maxBounds && d2.maxBounds &&
		    ( Vec3Diff( d1.maxBounds->min, d2.maxBounds->min ) ||
		      Vec3Diff( d1.maxBounds->max, d2.maxBounds->max ) ) )
	{
		++numDiffs;
	}
	
	if ( ( d1.limits && !d2.limits ) || ( !d1.limits && d2.limits ) )
	{
		++numDiffs;
	}
	else if ( d1.limits && d2.limits &&
		    ( ( d1.limits->maxNbActors        != d2.limits->maxNbActors ) ||
		      ( d1.limits->maxNbBodies        != d2.limits->maxNbBodies ) ||
			  ( d1.limits->maxNbDynamicShapes != d2.limits->maxNbDynamicShapes ) ||
			  ( d1.limits->maxNbJoints        != d2.limits->maxNbJoints ) ||
			  ( d1.limits->maxNbStaticShapes  != d2.limits->maxNbStaticShapes ) ) )
	{
		++numDiffs;
	}

	if ( ( d1.userData && !d2.userData ) || ( !d1.userData && d2.userData ) )
	{
		++numDiffs;
	}

	return numDiffs;
}

//==================================================================================
const char * CoreCompareNotify::GetCoreDifferenceTypeString( const CoreDifference type )
{
	// k, get it
	const char *ret = 0;

	switch( type )
	{
		case CD_NUM_ACTORS:						// # of 'NxActorDesc's differ
			ret = "CD_NUM_ACTOR";
		break;

		case CD_NUM_JOINTS:						// # of 'NxJointDesc's differ
			ret = "CD_NUM_JOINTS";
		break;

		case CD_NUM_CORE_SCENES:					// # of 'CoreScene's differ
			ret = "CD_NUM_CORE_SCENES";
		break;

		case CD_NUM_TRIANGLE_MESHES:				// # of 'NxTriangleMeshDesc's differ
			ret = "CD_NUM_TRIANGLE_MESHES";
		break;

		case CD_NUM_CONVEX_MESHES:				// # of 'NxConvexMeshDesc's differ
			ret = "CD_NUM_CONVEX_MESHES";
		break;

		case CD_NUM_MATERIALS:					// # of 'NxMaterialDesc's differ
			ret = "CD_NUM_MATERIALS";
		break;

		case CD_NUM_PAIR_COUNTS:					// # of 'PairFlagCapsule's differ
			ret = "CD_NUM_PAIR_COUNTS";
		break;

		case CD_NUM_SADE:						// # of NxSpringAndDamperEffectorDesc's differ
			ret = "CD_NUM_SADE";
		break;

		case CD_NUM_JOINT_LIMIT_INFO:			// # of a joint's Limit plane info's differ
			ret = "CD_NUM_JOINT_LIMIT_INFO";
		break;

		case CD_MATERIAL_DESC:					// an item in an NxMaterialDesc differs
			ret = "CD_MATERIAL_DESC";
		break;

		case CD_ACTOR_DESC:						// an item in an NxActorDesc differs
			ret = "CD_ACTOR_DESC";
		break;

		case CD_ACTOR_SHAPE_DESC_MISSING:		// an NxActorShapeDesc is missing
			ret = "CD_ACTOR_SHAPE_DESC_MISSING";
		break;

		case CD_ACTOR_SHAPE_DESC:				// an item in an 'NxActorDesc's NxShapeDesc differs 
			ret = "CD_ACTOR_SHAPE_DESC";
		break;

		case CD_ACTOR_BODY_DESC_DIFF:            // an NxBodyDesc is missing or is now present for an NxActorDesc
			ret = "CD_ACTOR_BODY_DESC_DIFF";
		break;

		case CD_ACTOR_SHAPE_NAME_DESC:			// an NxActorDesc name item is missing or differs
			ret = "CD_ACTOR_SHAPE_NAME_DESC";
		break;

		case CD_ACTOR_STATE_POSROT_INFO:         // an NxActor's position or rotation differs
			ret = "CD_ACTOR_STATE_POSROT_INFO";
		break;

		case CD_ACTOR_STATE_VEL_INFO:            // an NxActor's linear or angular velocity differs
			ret = "CD_ACTOR_STATE_VEL_INFO";
		break;

		case CD_ACTOR_BODY_DESC_MEMBER_INFO:     // an NxActor's NxBodyDesc has a difference
			ret = "CD_ACTOR_BODY_DESC_MEMBER_INFO";
		break;

		case CD_NUM_ACTOR_SCENES:				// # of 'NxSceneDesc's for an NxActor differs
			ret = "CD_NUM_ACTOR_SCENES";
		break;

		case CD_PAIR_FLAG_DESC:					// an item in a 'PairFlagCapsule' differs
			ret = "CD_PAIR_FLAG_DESC";
		break;
	
		case CD_JOINT_DESC_DIFF:					// an item in an NxJointDesc differs
			ret = "CD_JOINT_DESC_DIFF";
		break;

		case CD_JOINT_DESC_VECTOR_DIFF:			// one of the NxVec3 items in an NxJointDesc differs
			ret = "CD_JOINT_DESC_VECTOR_DIFF";
		break;

		case CD_JOINT_DESC_NAME_DIFF:			// an NxJointDesc name item is missing or differs
			ret = "CD_JOINT_DESC_NAME_DIFF";
		break;

		case CD_REV_JOINT_DESC_DIFF:				// a "normal" revolution joint diff
			ret = "CD_REV_JOINT_DESC_DIFF";
		break;

		case CD_REV_JOINT_DESC_LOW_LIMIT_DIFF:	// a NxJointLimitDesc (low limit) revolution joint diff
			ret = "CD_REV_JOINT_DESC_LOW_LIMIT_DIFF";
		break;

		case CD_REV_JOINT_DESC_HIGH_LIMIT_DIFF:	// a NxJointLimitDesc (high limit) revolution joint diff
			ret = "CD_REV_JOINT_DESC_HIGH_LIMIT_DIFF";
		break;

		case CD_REV_JOINT_DESC_MOTOR_DIFF:		// a NxMotorDesc revolution joint diff
			ret = "CD_REV_JOINT_DESC_MOTOR_DIFF";
		break;

		case CD_REV_JOINT_DESC_SPRING_DIFF:		// a NxSpringDesc revolution joint diff
			ret = "CD_REV_JOINT_DESC_SPRING_DIFF";
		break;

		case CD_PULLEY_JOINT_DESC_DIFF:			// a "normal" pully joint diff
			ret = "CD_PULLEY_JOINT_DESC_DIFF";
		break;

		case CD_PULLEY_JOINT_DESC_MOTOR_DIFF:	// a pully's NxMotorDesc diff
			ret = "CD_PULLEY_JOINT_DESC_MOTOR_DIFF";
		break;

		case CD_PULLEY_JOINT_DESC_PULLEY_DIFF:	// a NxVec3 of pully's pully joint has a diff
			ret = "CD_PULLEY_JOINT_DESC_PULLEY_DIFF";
		break;

		case CD_SPHERE_JOINT_DESC_DIFF:			// a "normal" spherical joint diff
			ret = "CD_SPHERE_JOINT_DESC_DIFF";
		break;

		case CD_SPHERE_JOINT_DESC_SWINGAXIS_DIFF:// a swing-axis (NxVec3) joint diff for a spherical joint
			ret = "CD_SPHERE_JOINT_DESC_SWINGAXIS_DIFF";
		break;

		case CD_SPHERE_JOINT_DESC_LIMIT_DIFF:	// a NxJointLimitDesc diff for a spherical joint
			ret = "CD_SPHERE_JOINT_DESC_LIMIT_DIFF";
		break;

		case CD_SPHERE_JOINT_DESC_SPRING_DIFF:	// a NxSpringDesc diff for a spherical joint
			ret = "CD_SPHERE_JOINT_DESC_SPRING_DIFF";
		break;

		case CD_DIST_JOINT_DESC_DIFF:			// a "normal" distance joint desc diff
			ret = "CD_DIST_JOINT_DESC_DIFF";
		break;

		case CD_DIST_JOINT_DESC_SPRING_DIFF:		// a NxSpringDesc diff for a distance joint
			ret = "CD_DIST_JOINT_DESC_SPRING_DIFF";
		break;

		case CD_D6_JOINT_DESC_DIFF:				// a "normal" D6 joint desc diff
			ret = "CD_D6_JOINT_DESC_DIFF";
		break;

		case CD_D6_JOINT_DESC_MOTION_DIFF:		// a motion item of the D6 joint has a diff
			ret = "CD_D6_JOINT_DESC_MOTION_DIFF";
		break;

		case CD_D6_JOINT_SOFT_DESC_DIFF:			// a NxJointLimitSoftDesc diff for a D6 joint desc
			ret = "CD_D6_JOINT_SOFT_DESC_DIFF";
		break;

		case CD_D6_JOINT_DRIVE_DESC_DIFF:		// a NxJointDriveDesc diff for a D6 joint desc
			ret = "CD_D6_JOINT_DRIVE_DESC_DIFF";
		break;

		case CD_D6_JOINT_VEC_DESC_DIFF:			// one of the NxVec3 has a diff for a D6 joint desc
			ret = "CD_D6_JOINT_VEC_DESC_DIFF";
		break;

		case CD_D6_JOINT_QUAT_DESC_DIFF:			// the NxQuat has a diff for a D6 joint desc
			ret = "CD_D6_JOINT_QUAT_DESC_DIFF";
		break;

		case CD_SADE_BODY_DIFF:					// the body indexes do not match for an NxSpringAndDamperEffectorDesc
			ret = "CD_SADE_BODY_DIFF";
		break;

		case CD_SADE_SPRING_PARAM:               // one of the spring parameters do not match for an NxSpringAndDamperEffectorDesc
			ret = "CD_SADE_SPRING_PARAM";
		break;

		case CD_SADE_DAMPER_PARAM:				// one of the damper parameters do not match for an NxSpringAndDamperEffectorDesc
			ret = "CD_SADE_DAMPER_PARAM";
		break;

		case CD_JOINT_LIMIT_PLANE_NORMAL:        // a joint's limit plane's normal differs in either x,y, and/or z
			ret = "CD_JOINT_LIMIT_PLANE_NORMAL";
		break;

		case CD_JOINT_LIMIT_PLANE_POINT:			// a joint's limit plane's point differs
			ret = "CD_JOINT_LIMIT_PLANE_POINT";
		break;

		case CD_JOINT_LIMIT_PLANE_D:  			// a joint's limit plane's planeD differs
			ret = "CD_JOINT_LIMIT_PLANE_D";
		break;

		case CD_JOINT_LIMIT_PLANE_WORLD_PT:		// a joint's limit plane's world pt differs
			ret = "CD_JOINT_LIMIT_PLANE_WORLD_PT";
		break;

		default:
			ret = "Error";
		break;
	}

	return ret;
}

//==================================================================================
const char * CoreCompareNotify::GetCoreDifferenceDescriptionString( const CoreDifference type )
{
	// k, get it
	const char *ret = 0;

	switch( type )
	{
		case CD_NUM_ACTORS:
			ret = "Number of 'NxActorDesc's differ";
		break;

		case CD_NUM_JOINTS:
			ret = "Number of 'NxJointDesc's differ";
		break;

		case CD_NUM_CORE_SCENES:
			ret = "Number of 'CoreScene's differ";
		break;

		case CD_NUM_TRIANGLE_MESHES:
			ret = "Number of 'NxTriangleMeshDesc's differ";
		break;

		case CD_NUM_CONVEX_MESHES:
			ret = "Number of 'NxConvexMeshDesc's differ";
		break;

		case CD_NUM_MATERIALS:
			ret = "Number of 'NxMaterialDesc's differ";
		break;

		case CD_NUM_PAIR_COUNTS:
			ret = "Number of 'PairFlagCapsule's differ";
		break;

		case CD_NUM_SADE:
			ret = "Number of 'SpringAndDamperEffectorDesc's differ";
		break;

		case CD_NUM_JOINT_LIMIT_INFO:
			ret = "Number of a joint's Limit plane info's differ";
		break;

		case CD_MATERIAL_DESC:
			ret = "An item in an NxMaterialDesc differs";
		break;

		case CD_ACTOR_DESC:
			ret = "An item in an NxActorDesc differs";
		break;

		case CD_ACTOR_SHAPE_DESC_MISSING:
			ret = "An NxActorShapeDesc is missing";
		break;

		case CD_ACTOR_SHAPE_DESC:
			ret = "An item in an 'NxActorDesc's NxShapeDesc differs ";
		break;

		case CD_ACTOR_BODY_DESC_DIFF:
			ret = "An NxBodyDesc is missing or is now present for an NxActorDesc";
		break;

		case CD_ACTOR_SHAPE_NAME_DESC:
			ret = "An NxActorDesc name item is missing or differs";
		break;

		case CD_ACTOR_STATE_POSROT_INFO:
			ret = "An NxActor's position or rotation differs";
		break;

		case CD_ACTOR_STATE_VEL_INFO:
			ret = "An NxActor's linear or angular velocity differs";
		break;

		case CD_ACTOR_BODY_DESC_MEMBER_INFO:
			ret = "An NxActor's NxBodyDesc has a difference";
		break;

		case CD_NUM_ACTOR_SCENES:
			ret = "Number of 'NxSceneDesc's for an NxActor differs";
		break;

		case CD_PAIR_FLAG_DESC:
			ret = "An item in a 'PairFlagCapsule' differs";
		break;
	
		case CD_JOINT_DESC_DIFF:
			ret = "An item in an NxJointDesc differs";
		break;

		case CD_JOINT_DESC_VECTOR_DIFF:
			ret = "One of the NxVec3 items in an NxJointDesc differs";
		break;

		case CD_JOINT_DESC_NAME_DIFF:
			ret = "An NxJointDesc name item is missing or differs";
		break;

		case CD_REV_JOINT_DESC_DIFF:
			ret = "A 'normal' revolution joint diff";
		break;

		case CD_REV_JOINT_DESC_LOW_LIMIT_DIFF:
			ret = "A NxJointLimitDesc (low limit) revolution joint diff";
		break;

		case CD_REV_JOINT_DESC_HIGH_LIMIT_DIFF:
			ret = "A NxJointLimitDesc (high limit) revolution joint diff";
		break;

		case CD_REV_JOINT_DESC_MOTOR_DIFF:
			ret = "A NxMotorDesc revolution joint diff";
		break;

		case CD_REV_JOINT_DESC_SPRING_DIFF:
			ret = "A NxSpringDesc revolution joint diff";
		break;

		case CD_PULLEY_JOINT_DESC_DIFF:
			ret = "A 'normal' pully joint diff";
		break;

		case CD_PULLEY_JOINT_DESC_MOTOR_DIFF:
			ret = "A pully's NxMotorDesc diff";
		break;

		case CD_PULLEY_JOINT_DESC_PULLEY_DIFF:
			ret = "A NxVec3 of pully's pully joint has a diff";
		break;

		case CD_SPHERE_JOINT_DESC_DIFF:
			ret = "A 'normal' spherical joint diff";
		break;

		case CD_SPHERE_JOINT_DESC_SWINGAXIS_DIFF:
			ret = "A swing-axis (NxVec3) joint difference for a spherical joint";
		break;

		case CD_SPHERE_JOINT_DESC_LIMIT_DIFF:
			ret = "A NxJointLimitDesc difference for a spherical joint";
		break;

		case CD_SPHERE_JOINT_DESC_SPRING_DIFF:
			ret = "A NxSpringDesc difference for a spherical joint";
		break;

		case CD_DIST_JOINT_DESC_DIFF:
			ret = "A 'normal' distance joint desc diff";
		break;

		case CD_DIST_JOINT_DESC_SPRING_DIFF:
			ret = "A NxSpringDesc difference for a distance joint";
		break;

		case CD_D6_JOINT_DESC_DIFF:
			ret = "A 'normal' D6 joint desc diff";
		break;

		case CD_D6_JOINT_DESC_MOTION_DIFF:
			ret = "A motion item of the D6 joint has a diff";
		break;

		case CD_D6_JOINT_SOFT_DESC_DIFF:
			ret = "A NxJointLimitSoftDesc difference for a D6 joint desc";
		break;

		case CD_D6_JOINT_DRIVE_DESC_DIFF:
			ret = "A NxJointDriveDesc difference for a D6 joint desc";
		break;

		case CD_D6_JOINT_VEC_DESC_DIFF:
			ret = "One of the NxVec3 has a difference for a D6 joint desc";
		break;

		case CD_D6_JOINT_QUAT_DESC_DIFF:
			ret = "The NxQuat has a difference for a D6 joint desc";
		break;

		case CD_SADE_BODY_DIFF:
			ret = "The body indexes do not match for an NxSpringAndDamperEffectorDesc";
		break;

		case CD_SADE_SPRING_PARAM:
			ret = "One or more of the spring parameters do not match for an NxSpringAndDamperEffectorDesc";
		break;

		case CD_SADE_DAMPER_PARAM:
			ret = "One or more of the damper parameters do not match for an NxSpringAndDamperEffectorDesc";
		break;

		case CD_JOINT_LIMIT_PLANE_NORMAL:
			ret = "A joint's limit plane's normal differs in either x,y, and/or z";
		break;

		case CD_JOINT_LIMIT_PLANE_POINT:		
			ret = "A joint's limit plane's point differs";
		break;

		case CD_JOINT_LIMIT_PLANE_D: 
			ret = "A joint's limit plane's planeD differs";
		break;

		case CD_JOINT_LIMIT_PLANE_WORLD_PT:
			ret = "A joint's limit plane's world pt differs";
		break;

		default:
			ret = "Error";
		break;
	}

	return ret;
}

//==================================================================================
const char * CoreCompareNotify::GetTriangleMeshDifferenceTypeString( const TriangleMeshDifferences &type )
{
	const char *ret = 0;

	switch( type )
	{
		case TMD_CET:
			ret = "TMD_CET";
		break;

		case TMD_FLAGS:
			ret = "TMD_FLAGS";
		break;

		case TMD_HFVA:
			ret = "TMD_HFVA";
		break;

		case TMD_HFVE:
			ret = "TMD_HFVE";
		break;
	
		case TMD_MIS:
			ret = "TMD_MIS";
		break;

		case TMD_PMAP_MISSING:
			ret = "TMD_PMAP_MISSING";
		break;

		case TMD_PMAP_NUMVERTS:
			ret = "TMD_PMAP_NUMVERTS";
		break;

		case TMD_VERT_NUM:
			ret = "TMD_VERT_NUM";
		break;

		case TMD_VERT_STRIDE:
			ret = "TMD_VERT_STRIDE";
		break;

		case TMD_VERT_PTS:
			ret = "TMD_VERT_PTS";
		break;

		case TMD_TRI_NUMVERTS:
			ret = "TMD_TRI_NUMVERTS";
		break;

		case TMD_TRI_STRIDE:
			ret = "TMD_TRI_STRIDE";
		break;

		case TMD_TRI_TRIS:
			ret = "TMD_TRI_TRIS";
		break;

		default:
			ret = "Error";
		break;
	}

	return ret;
}

//==================================================================================
const char * CoreCompareNotify::GetTriangleMeshDifferenceDescriptionString( const TriangleMeshDifferences &type )
{
	const char *ret = 0;

	switch( type )
	{
		case TMD_CET:
			ret = "The convex edge threshold for the triangle mesh has a difference";
		break;

		case TMD_FLAGS:
			ret = "The flags for the triangle meshes differ";
		break;

		case TMD_HFVA:
			ret = "The height field vertical axis has a difference in the triangle meshes";
		break;

		case TMD_HFVE:
			ret = "The height field vertical extents differ in the triangle meshes";
		break;
	
		case TMD_MIS:
			ret = "The material index stride has a difference in the triangle meshes";
		break;

		case TMD_PMAP_MISSING:
			ret = "One of the triangle meshes is missing a pmap";
		break;

		case TMD_PMAP_NUMVERTS:
			ret = "The number of vertex information's (actual pmap data size) is different between the 2 triangle meshes";
		break;

		case TMD_VERT_NUM:
			ret = "The number of vertices in the two triangle meshes differ";
		break;

		case TMD_VERT_STRIDE:
			ret = "The vertex stride length ('length' of one set of vertex (x,y,z) information) is different)";
		break;

		case TMD_VERT_PTS:
			ret = "A memory comparison of the vertex position information is different";
		break;

		case TMD_TRI_NUMVERTS:
			ret = "The number of triangles in the two triangle meshes differ";
		break;

		case TMD_TRI_STRIDE:
			ret = "The triangle stride length ('length' of one set of triangle (v1Index,v2Index,v3Index) information) is different)";
		break;

		case TMD_TRI_TRIS:
			ret = "A memory comparison of the triangle index information is different";
		break;

		default:
			ret = "Error";
		break;
	}

	return ret;
}

//==================================================================================
const char * CoreCompareNotify::GetConvexMeshDifferenceTypeString( const ConvexMeshDifferences &type )
{
	const char *ret = 0;

	switch( type )
	{
		case CMD_FLAGS:
			ret = "CMD_FLAGS";
		break;

		case CMD_VERT_NUM:
			ret = "CMD_VERT_NUM";
		break;

		case CMD_VERT_STRIDE:
			ret = "CMD_VERT_STRIDE";
		break;

		case CMD_VERT_PTS:
			ret = "CMD_VERT_PTS";
		break;

		case CMD_TRI_NUMVERTS:
			ret = "CMD_TRI_NUMVERTS";
		break;

		case CMD_TRI_STRIDE:
			ret = "CMD_TRI_STRIDE";
		break;

		case CMD_TRI_TRIS:
			ret = "CMD_TRI_TRIS";
		break;

		default:
			ret = "Error";
		break;
	}

	return ret;
}

//==================================================================================
const char * CoreCompareNotify::GetConvexMeshDifferenceDescriptionString( const ConvexMeshDifferences &type )
{
	const char *ret = 0;

	switch( type )
	{
		case CMD_FLAGS:
			ret = "The flags for a convex mesh description differs";
		break;

		case CMD_VERT_NUM:
			ret = "The number of vertices for a convex mesh differs";
		break;

		case CMD_VERT_STRIDE:
			ret = "The vertex stride length ('length' of one set of vertex (x,y,z) information) is different)";
		break;

		case CMD_VERT_PTS:
			ret = "A memory comparison of vertex positions does not match for the convex mesh";
		break;

		case CMD_TRI_NUMVERTS:
			ret = "The number of triangles for the convex mesh differs";
		break;

		case CMD_TRI_STRIDE:
			ret = "The triangle stride length ('length' of one set of triangle (v1Index,v2Index,v3Index) information) is different)";
		break;

		case CMD_TRI_TRIS:
			ret = "A memory comparison of triangle indices does not match for the convex mesh";
		break;

		default:
			ret = "Error";
		break;
	}

	return ret;
}

bool CoreContainer::ValidateEnergy(float maxVel,float maxAngularVelocity,int &lowEnergy,int &highEnergy) const
{
	bool ret = true;

	lowEnergy = 0;
	highEnergy = 0;

	int scount = mScenes.size();
	for (int i=0; i<scount; i++)
	{
		CoreScene *cs = mScenes[i];
		if ( !cs->ValidateEnergy(maxVel,maxAngularVelocity,lowEnergy,highEnergy) )
		{
			ret = false;
		}
	}

	return ret;
}

bool CoreContainer::ValidateSleep(int &awake,int &asleep) const
{
	bool ret = true;

	awake = 0;
	asleep = 0;

	int scount = mScenes.size();
	for (int i=0; i<scount; i++)
	{
		CoreScene *cs = mScenes[i];
		if ( ! cs->ValidateSleep(awake,asleep) )
		{
			ret = false;
		}
	}

	return ret;
}

bool CoreScene::ValidateSleep(int &awake,int &asleep) const
{
	bool ret = true;

  int count = mActors.size();
  for (int i=0; i<count; i++)
  {
  	NxActorDesc *d = mActors[i];
  	if ( d->body )
  	{
  		if ( d->body->wakeUpCounter <= 0 )
  			asleep++;
  		else
  		{
  			awake++;
  			ret = false;
  		}
  	}
  	else
  	{
  		asleep++;
  	}
  }
  return ret;
}


bool CoreScene::ValidateEnergy(float maxVel,float maxAngularVelocity,int &lowEnergy,int &highEnergy) const
{
	bool ret = true;

  int count = mActors.size();
  for (int i=0; i<count; i++)
  {
  	NxActorDesc *d = mActors[i];
  	if ( d->body )
  	{
  		if ( d->body->linearVelocity.x > maxVel ||
  			   d->body->linearVelocity.y > maxVel ||
  			   d->body->linearVelocity.z > maxVel ||
  			   d->body->angularVelocity.x > maxAngularVelocity ||
  			   d->body->angularVelocity.y > maxAngularVelocity ||
  			   d->body->angularVelocity.z > maxAngularVelocity )
  		{
  			highEnergy++;
  			ret = false;
  		}
  		else
  		{
  			lowEnergy++;
  		}
  	}
  	else
  	{
  		lowEnergy++;
  	}
  }
  return ret;
}
