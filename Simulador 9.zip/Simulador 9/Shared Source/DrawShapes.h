// ===============================================================================
//						    NOVODEX SDK TRAINING PROGRAMS
//							   SHAPE DRAWING ROUTINES
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#ifndef DRAWSHAPES_H
#define DRAWSHAPES_H

class NxShape;

void InitShapeDisplayLists();
void ReleaseShapeDisplayLists();
void SetupGLMatrix(const NxVec3& pos, const NxMat33& orient);
void DrawLine(const NxVec3& p0, const NxVec3& p1, const NxVec3& color);
void DrawCircle(NxU32 nbSegments, const NxMat34& matrix, const NxVec3& color, const NxF32 radius, const bool semicircle = false);
void DrawArrow(const NxVec3& posA, const NxVec3& posB, const NxVec3& color);
void DrawContactPoint(const NxVec3& pos, const NxReal radius, const NxVec3& color);
void DrawWirePlane(NxShape* plane, const NxVec3& color);
void DrawPlane(NxShape* plane);
void DrawWireBox(NxBox* obb, const NxVec3& color);
void DrawWireBox(NxShape* box, const NxVec3& color);
void DrawBox(NxShape* box);
void DrawWireSphere(NxSphere* sphere, const NxVec3& color);
void DrawWireSphere(NxShape* sphere, const NxVec3& color);
void DrawSphere(NxShape* sphere);
void DrawWireCapsule(NxCapsule* capsule, const NxVec3& color);
void DrawWireCapsule(NxShape* capsule, const NxVec3& color);
void DrawCapsule(NxShape* capsule);
void DrawWireConvex(NxShape* mesh, const NxVec3& color);
void DrawConvex(NxShape* mesh);
void DrawWireMesh(NxShape* mesh, const NxVec3& color);
void DrawMesh(NxShape* mesh);
void DrawWireShape(NxShape* shape, const NxVec3& color);
void DrawShape(NxShape* shape);
void DrawActor(NxActor* actor);
void DrawActorBlueSleep(NxActor* actor);
void DrawActorShapeSelect(NxActor* actor, NxShape* shape, const bool shapeSelectMode);
void DrawIntersectedActor(NxActor* actor);
void DrawActorShadow(NxActor* actor);


#endif  // DRAWSHAPES_H