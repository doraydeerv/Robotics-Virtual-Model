#ifndef	CORE_DUMP_H

#define	CORE_DUMP_H

#include "NxPhysics.h"

#ifdef WIN32
#define	CORE_DUMP_ENABLE 1
#else
#define	CORE_DUMP_ENABLE 0
#endif

#if	CORE_DUMP_ENABLE
#include <stdio.h>
#endif



class CoreDump
{
public:
  CoreDump(void)
  {
  	mActorUserData = 0;
  	mFph = 0;
  	mBinary = true;
  	mIndent = 0;
  	mNbActors = 0;
  	mActors = 0;
  }

	bool coreDump(NxPhysicsSDK *sdk,const char *fname,bool binary);	// save	the	contents of	the	state of the physics SDK in	text or	binary.

	static unsigned int getCoreVersion(NxPhysicsSDK *sdk); // return the munged core dump version relative to this SDK

private:

#if	CORE_DUMP_ENABLE
	void Print(const char *fmt,...);
	void WriteBool(	const char *desc, bool yesNo );
	void WriteChar( const char *desc, char c, bool descAsInt = false );
	void WriteInt( const char *desc, int n );
	void WriteLong(	const char *desc, long l );
	void WriteShort( const char	*desc, short s );
	void WriteUnsigned(	const char *desc, unsigned u );
	void WriteUnsignedLong(	const char *desc, unsigned long	ul );
	void WriteUnsignedShort( const char	*desc, unsigned	short us );
	void WriteFloat( const char	*desc, float f );
	void WriteFlag(	const char *desc, unsigned f );
	void WriteString( const	char *info );
	void WriteParam( NxParameter p,	NxReal v );
	void Write(	const char *desc, NxU32	v );
	void Write(	const char *desc, NxScene *scene );
	void WriteSceneDesc( NxScene *scene	);
	void Write(	const char *desc, NxActor *a );
	void Write(	const char *desc, NxPairFlag *a	);
	void Write(	const char *desc, NxMaterial *a,bool hardwareScene	);
	void Write(	const char *desc, NxJoint *j );
	void Write(	const char *desc, NxSpringDesc *spring );
	void Write(	const char *desc, const	NxMat34	&p );
	void Write(	const char *desc, const	NxBodyDesc *b );
	void PrintFlag(	unsigned int state,	const char *desc, unsigned int flag	);
	void Write(	const char *desc, const	NxVec3 &v );
	void Write(	const char *desc, const	NxQuat &q );
	void Write(	const char *desc, const	NxShape	*shape );
	void Write(	const char *desc, const	NxShapeDesc	&d,const NxShape *s	);
	void Write(	const char *desc, const	NxTriangleMesh *mesh );
	void Write(	const char *desc, const	NxConvexMesh *mesh );
	void Write(	const char *desc, const	NxCCDSkeleton *skeleton	);
	void Write(	const char *desc, const	NxJointLimitSoftDesc &l	);
	void Write(	const char *desc, const	NxJointLimitSoftPairDesc &l	);
	void Write(	const char *desc, const	NxJointDriveDesc &d	);
	void Write(	const char *desc, NxScene &scene, NxEffector &e );
	void Write(	NxJointDesc	*d,	NxJoint	*j );
	void Write(	NxPrismaticJointDesc *desc,	NxJoint	*j );
	void Write(	NxRevoluteJointDesc	*desc, NxJoint *j );
	void Write(	NxCylindricalJointDesc *desc, NxJoint *j );
	void Write(	NxSphericalJointDesc *desc,	NxJoint	*j );
	void Write(	NxPointOnLineJointDesc *desc, NxJoint *j );
	void Write(	NxPointInPlaneJointDesc	*desc, NxJoint *j );
	void Write(	NxDistanceJointDesc	*desc, NxJoint *j );
	void Write(	NxPulleyJointDesc *desc, NxJoint *j	);
	void Write(	NxFixedJointDesc *desc,	NxJoint	*j );
	void Write(	NxD6JointDesc *desc, NxJoint *j	);

	bool AddSkeleton(NxCCDSkeleton *skeleton);
	bool AddConvex(NxConvexMesh	*mesh);
	bool AddTriangleMesh(NxTriangleMesh	*mesh);

	int	GetSkeletonIndex(const NxCCDSkeleton *skeleton); //	look it	up
	int	GetConvexIndex(const NxConvexMesh *mesh);
	int	GetTriangleMeshIndex(const NxTriangleMesh *mesh);
	int	GetActorIndex(const	NxActor	*a)	const;
  int	GetShapeIndex(const NxActor *a,const NxShape *s) const;

  // binary	writing
	void WriteChar_b( char val );
	void WriteInt_b( int val );
	void WriteLong_b( long val );
	void WriteShort_b( short val );
	void WriteUnsigned_b( unsigned val );
	void WriteUnsignedLong_b( unsigned long	val	);
	void WriteUnsignedShort_b( unsigned	short val );
	void WriteFloat_b( float val );
	void WriteDouble_b(	double val );
	void WriteString_b(	const char *val	);
	void WriteFlag_b( unsigned flag	);
	void WriteMatrix_b(	const NxMat34 &matrix );
	void WriteVec3_b( const	NxVec3 &v );
	void WriteBodyDesc_b( const	NxBodyDesc *b );

	void SaveUserData(NxScene *scene);
	void RestoreUserData(NxScene *scene);

	FILE *mFph;
	bool  mBinary;
	int	  mIndent;
	NxArray< NxTriangleMesh	* >	mTriangleMeshes;
	NxArray< NxConvexMesh	* >	mConvexMeshes;
	NxArray< NxCCDSkeleton	* >	mSkeletons;

	NxU32						mNbActors;
	NxActor					 ** mActors;

	void             ** mActorUserData; // preserves the original actor user data field.

#endif
};


#endif
