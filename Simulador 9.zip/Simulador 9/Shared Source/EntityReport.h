
#ifndef ENTITYREPORT_H
#define ENTITYREPORT_H

class ShapeReport : public NxUserEntityReport<NxShape*>
{
public:
	virtual bool onEvent(NxU32 nbShapes, NxShape** shapes)
	{
		while (nbShapes--)
		{
			NxActor* actor = &shapes[nbShapes]->getActor();
			actor->userData = (void*)-1;
		}

		return true;
	}

} gShapeReport;

#endif  // ENTITYREPORT_H

