// ===============================================================================
//						    NOVODEX SDK TRAINING PROGRAMS
//						    HEIGHTFIELD CREATION METHODS
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#ifndef HEIGHTFIELD_H
#define HEIGHTFIELD_H

NxActor* CreateHeightfield(int index, NxReal step,  NxTriangleMeshDesc& tmd);
void RenderHeightfield();

#endif  // HEIGHTFIELD_H