// ===============================================================================
//						     PHYSX SDK TRAINING PROGRAMS
//							   EXIT CALLBACK ROUTINES
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#ifndef EXITCALLBACK_H
#define EXITCALLBACK_H

#include <GL/gl.h>
#include <GL/glut.h>

//void glutExitFunc(void (GLUTCALLBACK *func)(void));

#endif