// ===============================================================================
//						     PHYSX SDK TRAINING PROGRAMS
//						 	   ACTOR CREATION METHODS
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#ifndef ACTORS_H
#define ACTORS_H

#include "NxPhysics.h"

#include <stdio.h>
#include "Stream.h"
#include "NxCooking.h"

NxActor* CreateGroundPlane();

NxActor* CreateBox(const NxVec3& pos, const NxVec3& boxDim, const NxReal density);
NxActor* CreateSphere(const NxVec3& pos, const NxReal radius, const NxReal density);
NxActor* CreateCapsule(const NxVec3& pos, const NxReal height, const NxReal radius, const NxReal density);

NxActor* CreateHalfPyramid(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreatePyramid(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreateDownWedge(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);

NxActor* CreateFlatSurface(const NxVec3& pos, const NxU32 length, const NxU32 width, const NxReal stride, NxTriangleMeshDesc& tmd);
NxActor* CreateFlatHeightfield(const NxVec3& pos, const NxU32 length, const NxU32 width, const NxReal stride, NxTriangleMeshDesc& tmd);

NxActor* CreateConvexObjectComputeHull(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreateConvexObjectSupplyHull(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreateConcaveObject(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);

NxActor* Createobj(const NxVec3& pos, NxTriangleMesh* triangleMesh, const NxReal density, NxTriangleMeshDesc& cmd);
//NxActor* Createmano(const NxVec3& pos, NxTriangleMesh* triangleMesh, const NxReal density, NxTriangleMeshDesc& cmd);

NxActor** CreateStack(const NxVec3& pos, const NxVec3& stackDim, const NxVec3& boxDim, NxReal density);
NxActor** CreateTower(const NxVec3& pos, const NxU32 heightBoxes, const NxVec3& boxDim, NxReal density);

NxQuat AnglesToQuat(const NxVec3& angles);
NxActor* CreateBoxGear(const NxVec3& pos, const NxReal minRadius, const NxReal maxRadius, const NxReal height, const NxU32 numTeeth, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreateWheel(const NxVec3& pos, const NxReal minRadius, const NxReal maxRadius, const NxReal height, const NxU32 numTeeth, const NxReal density, NxConvexMeshDesc& cmd1, NxConvexMeshDesc& cmd2, NxConvexMeshDesc& cmd3);
NxActor* CreateFrame(const NxVec3& pos, const NxReal density);
NxActor* CreateStep(const NxVec3& pos, const NxVec3& boxDim, const NxReal density);

NxActor* CreateChassis(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreateTurret(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);
NxActor* CreateCannon(const NxVec3& pos, const NxVec3& boxDim, const NxReal density, NxConvexMeshDesc& cmd);

NxActor* CreateBlade(const NxVec3& pos, const NxVec3& boxDim, const NxReal mass);
NxActor* CreateBall(const NxVec3& pos, const NxReal radius, const NxReal mass);

void SetActorCollisionGroup(NxActor *actor, NxCollisionGroup group);
void SetActorMaterial(NxActor *actor, NxMaterialIndex index);

#endif  // ACTORS_H
