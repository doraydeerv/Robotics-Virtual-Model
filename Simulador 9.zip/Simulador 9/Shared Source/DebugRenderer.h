// ===============================================================================
//						     PHYSX SDK TRAINING PROGRAMS
//			                       DEBUG RENDERER
//
//						   Written by Bob Schade, 10-15-05
// ===============================================================================

#ifndef DEBUGRENDER_H
#define DEBUGRENDER_H

class NxDebugRenderable;

class DebugRenderer
{
public:
	void renderData(const NxDebugRenderable& data) const;
};

#endif  // DEBUGRENDER_H